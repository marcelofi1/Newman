const report = require('multiple-cucumber-html-reporter');
const projectName = "account-tests-automation";
const projectVersion = process.env.npm_package_version;
const reportGenerationTime = new Date().toISOString();
report.generate({
  reportName: 'TestCafé Report',
  jsonDir: 'reports/cucumber-json-reports',
  reportPath: 'reports/cucumber_report',
  openReportInBrowser: true,
  disableLog: false,
  displayDuration: true,
  displayReportTime: true,
  durationInMS: true,
  customData: {
    title: 'Run info',
    data: [
      { label: 'Project', value: `${projectName}` },
      { label: 'Release', value: `${projectVersion}` },
      { label: 'Report Generation Time', value: `${reportGenerationTime}` },
    ],
  },
});