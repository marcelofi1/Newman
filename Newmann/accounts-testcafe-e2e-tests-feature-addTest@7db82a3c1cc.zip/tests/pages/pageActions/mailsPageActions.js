"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const actions_1 = __importDefault(require("../../utils/actions"));
const helper_1 = require("../../utils/helper");
const brandsModels_1 = require("../models/brandsModels");
const mailsPageObjects_1 = require("../pageObjects/mailsPageObjects");
let elements;
const brand = (0, helper_1.getBrand)();
class MailsPageActions {
    constructor() {
        this.urlBrandName = brand.siteUrl || '';
    }
    getElements() {
        switch (brand.name) {
            case brandsModels_1.BrandNames.tg:
                elements = mailsPageObjects_1.mailsPageObject.elementsTg;
                break;
            case brandsModels_1.BrandNames.wc:
                elements = mailsPageObjects_1.mailsPageObject.elementsWc;
                break;
            case brandsModels_1.BrandNames.lv:
                elements = mailsPageObjects_1.mailsPageObject.elementsLv;
                break;
            case brandsModels_1.BrandNames.cbol:
                elements = mailsPageObjects_1.mailsPageObject.elementsCbol;
                break;
            case brandsModels_1.BrandNames.csb:
                elements = mailsPageObjects_1.mailsPageObject.elementsCsb;
                break;
            default:
                console.log("Brand not declarated");
                return {};
        }
        return elements;
    }
    completeMail(mail) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).in_mailYop) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.isVisible(element);
                yield actions_1.default.sendKeys(element, mail);
            }
            else {
                console.log('Error: Elemento no encontrado');
            }
        });
    }
    clickBtnGoToMail() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).btn_mail) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.isVisible(element);
                yield actions_1.default.click(element);
            }
            else {
                console.log('Error: Elemento no encontrado');
            }
        });
    }
    getLinkRaf() {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            const iframeElement = (_b = (_a = this.getElements()).iframe_Mail) === null || _b === void 0 ? void 0 : _b.call(_a);
            const linkElement = (_d = (_c = this.getElements()).link_Raf) === null || _d === void 0 ? void 0 : _d.call(_c);
            if (iframeElement && linkElement) {
                yield actions_1.default.switchIFrame(iframeElement);
                return yield actions_1.default.getAtributte(linkElement, 'href');
            }
            else {
                console.log('Error: Elementos no encontrados');
                return null;
            }
        });
    }
}
exports.default = new MailsPageActions();
