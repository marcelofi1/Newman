"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const actions_1 = __importDefault(require("../../utils/actions"));
const helper_1 = require("../../utils/helper");
const brandsModels_1 = require("../models/brandsModels");
const rafPageObjects_1 = require("../pageObjects/rafPageObjects");
let elements;
const brand = (0, helper_1.getBrand)();
class LoginPageActions {
    constructor() {
        this.urlBrandName = brand.siteUrl || '';
    }
    getElements() {
        switch (brand.name) {
            case brandsModels_1.BrandNames.tg:
                elements = rafPageObjects_1.rafPageObject.elementsTg;
                break;
            case brandsModels_1.BrandNames.wc:
                elements = rafPageObjects_1.rafPageObject.elementsWc;
                break;
            case brandsModels_1.BrandNames.lv:
                elements = rafPageObjects_1.rafPageObject.elementsLv;
                break;
            case brandsModels_1.BrandNames.cbol:
                elements = rafPageObjects_1.rafPageObject.elementsCbol;
                break;
            case brandsModels_1.BrandNames.csb:
                elements = rafPageObjects_1.rafPageObject.elementsCsb;
                break;
            default:
                console.log("Brand not declarated");
                return {};
        }
        return elements;
    }
    clickBtnMyAccount() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).btn_MyAccount) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.isVisible(element);
                yield actions_1.default.click(element);
            }
            else {
                console.log('Error: Elemento no encontrado');
            }
        });
    }
    clickBtnViewRaf() {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            const collapseElement = (_b = (_a = this.getElements()).collapse_Raf) === null || _b === void 0 ? void 0 : _b.call(_a);
            const btnViewRafElement = (_d = (_c = this.getElements()).btn_ViewRaf) === null || _d === void 0 ? void 0 : _d.call(_c);
            if (collapseElement && btnViewRafElement) {
                yield actions_1.default.isVisible(collapseElement);
                yield actions_1.default.click(collapseElement);
                yield actions_1.default.isVisible(btnViewRafElement);
                yield actions_1.default.click(btnViewRafElement);
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    getValueRaf() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).lbl_QuantityRaf) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.isVisible(element);
                return yield actions_1.default.getValue(element);
            }
            else {
                console.log('Error: Elemento no encontrado');
                return null;
            }
        });
    }
    clickBtnSports() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).btn_Sports) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.isVisible(element);
                yield actions_1.default.click(element);
            }
            else {
                console.log('Error: Elemento no encontrado');
            }
        });
    }
    closeModalRaf() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).btn_ModalRaf) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.isVisible(element);
                yield actions_1.default.click(element);
            }
            else {
                console.log('Error: Elemento no encontrado');
            }
        });
    }
    clickBtnLogout() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).btn_logout) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.isVisible(element);
                yield actions_1.default.click(element);
            }
            else {
                console.log('Error: Elemento no encontrado');
            }
        });
    }
    clickBtnHome() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).btn_home) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.isVisible(element);
                yield actions_1.default.click(element);
            }
            else {
                console.log('Error: Elemento no encontrado');
            }
        });
    }
    getValueLinkRaf() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).lbl_RafLink) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.isVisible(element);
                return yield actions_1.default.getValue(element);
            }
            else {
                console.log('Error: Elemento no encontrado');
                return null;
            }
        });
    }
    clickBtnRaf() {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            const collapseElement = (_b = (_a = this.getElements()).collapse_Raf) === null || _b === void 0 ? void 0 : _b.call(_a);
            const btnRafElement = (_d = (_c = this.getElements()).btn_Raf) === null || _d === void 0 ? void 0 : _d.call(_c);
            if (collapseElement && btnRafElement) {
                yield actions_1.default.isVisible(collapseElement);
                yield actions_1.default.click(collapseElement);
                yield actions_1.default.isVisible(btnRafElement);
                yield actions_1.default.click(btnRafElement);
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    validateURLRaf(url) {
        return __awaiter(this, void 0, void 0, function* () {
            yield actions_1.default.urlIsDisplayed(url);
        });
    }
}
exports.default = new LoginPageActions();
