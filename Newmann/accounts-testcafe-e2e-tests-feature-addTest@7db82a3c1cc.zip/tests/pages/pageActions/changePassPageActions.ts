import actions from '../../utils/actions';
import { getBrand } from '../../utils/helper';
import { BrandNames } from '../models/brandsModels';
import { changePassPageModels } from '../models/changePassPageModels';
import { changePassPageObjects } from '../pageObjects/changePassPageObjects';

let elements: typeof changePassPageModels | undefined;
const brand = getBrand();

class ChangePassPageActions {

  urlBrandName: string = brand.siteUrl || '';
  password: string | undefined;

  getElements(): typeof changePassPageModels {
    switch (brand.name) {
      case BrandNames.tg:
        elements = changePassPageObjects.elementsTg;
        break;
      case BrandNames.wc:
        elements = changePassPageObjects.elementsWc;
        break;
      case BrandNames.lv:
        elements = changePassPageObjects.elementsLv;
        break;
      case BrandNames.cbol:
        elements = changePassPageObjects.elementsCbol;
        break;
      case BrandNames.csb:
        elements = changePassPageObjects.elementsCsb;
        break;
      default: 
        console.log("Brand not declarated");
        return {} as typeof changePassPageModels;
    }
    return elements;
  }

  async elementsAreVisibles() {
    const elements = this.getElements(); // Obtener los elementos
    if (elements) {
      await actions.isVisible(elements.lbl_changePassword?.());
      await actions.isVisible(elements.lbl_instructions?.());
      await actions.isVisible(elements.in_newPassord?.());
      await actions.isVisible(elements.in_reEnterPass?.());
      await actions.isVisible(elements.btn_proceed?.());
      await this.setPassword();
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }

  async completeNewPass(newPass: string | Promise<string>) {
    const elements = this.getElements();
    if (elements) {
      await actions.sendKeys(elements.in_newPassord?.(), await newPass);
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async completeReEnterPass(reEnterPass: string | Promise<string>) {
    const elements = this.getElements();
    if (elements) {
      await actions.sendKeys(elements.in_reEnterPass?.(), await reEnterPass);
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async clickProceedBtn() {
    const elements = this.getElements();
    if (elements) {
      await actions.click(elements.btn_proceed?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async validErrorPass() {
    const elements = this.getElements();
    if (elements) {
      await actions.isVisible(elements.lbl_invalid?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async validEmptyNewPass() {
    const elements = this.getElements();
    if (elements) {
      await actions.isVisible(elements.lbl_invalid?.());
      await this.elementsAreVisibles();
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async validEmptyReEnterPass() {
    const elements = this.getElements();
    if (elements) {
      await actions.isElementNotDisplayed(elements.lbl_invalid?.());
      await this.elementsAreVisibles();
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async validChangePass() {
    const elements = this.getElements();
    if (elements) {
      await actions.isVisible(elements.lbl_userIdLogin?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async validNotMatchPasswords() {
    const elements = this.getElements();
    if (elements) {
      await actions.isVisible(elements.lbl_notMatchPasswords?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async validOldPassword() {
    const elements = this.getElements();
    if (elements) {
      await actions.isVisible(elements.lbl_oldPassword?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }

  async setPassword(){
    this.password = "ValidPass" + Math.floor(Math.random() * 10000) +"!";
  }

  async getPassword(){
    return this.password;
  }
}

export default new ChangePassPageActions();