
/* tslint:disable no-var-requires */
import actions from '../../utils/actions';
import { getBrand } from '../../utils/helper';
import { BrandNames } from '../models/brandsModels';
import { homePageModel } from '../models/homePageModels';
import { homePageObject } from '../pageObjects/homePageObjects';


let elements: typeof homePageModel | undefined;
const brand = getBrand();

class HomePageActions {

  urlBrandName: string = brand.siteUrl || '';

  getElements(): typeof homePageModel {
    switch (brand.name) {
      case BrandNames.tg:
        elements = homePageObject.elementsTg;
        break;
      case BrandNames.wc:
        elements = homePageObject.elementsWc;
        break;
      case BrandNames.lv:
        elements = homePageObject.elementsLv;
        break;
      case BrandNames.cbol:
        elements = homePageObject.elementsCbol;
        break;
      case BrandNames.csb:
        elements = homePageObject.elementsCsb;
        break;
      default: 
        console.log("Brand not declarated");
        return {} as typeof homePageModel;
    }
    return elements;
  }

  async urlIsDisplayed() {
    await actions.urlIsDisplayed(this.urlBrandName);
  }

  async headerIsVisible() {
    const elements = this.getElements();
    if (elements) {
      await actions.isVisible(elements.img_log?.());
      await actions.isVisible(elements.img_badBet?.());
      await actions.isVisible(elements.btn_login?.());
      await actions.isVisible(elements.btn_register?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async menuIsVisible() {
    const elements = this.getElements();
    if (elements) {
      await actions.isVisible(elements.btn_sports?.());
      await actions.isVisible(elements.btn_liveBetting?.());
      await actions.isVisible(elements.btn_poker?.());
      await actions.isVisible(elements.btn_casino?.());
      await actions.isVisible(elements.btn_liveCasino?.());
      await actions.isVisible(elements.btn_promotions?.());
      await actions.isVisible(elements.btn_cashier?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async footerIsVisible() {
    const elements = this.getElements();
    if (elements) {
      await actions.isVisible(elements.lbl_aboutUs?.());
      await actions.isVisible(elements.img_safeSecure?.());
      await actions.isVisible(elements.lbl_copyRights?.());
      await actions.isVisible(elements.img_gammingTrust?.());
      await actions.isVisible(elements.btn_rules?.());
      await actions.isVisible(elements.btn_affiliates?.());
      await actions.isVisible(elements.btn_contactUs?.());
      await actions.isVisible(elements.btn_privacyPolicy?.());
      await actions.isVisible(elements.btn_responsibleGaming?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async clickLoginBtn() {
    const elements = this.getElements();
    if (elements) {
      await actions.click(elements.btn_login?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async clickJoinBtn() {
    const elements = this.getElements();
    if (elements) {
      await actions.click(elements.btn_register?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
}
export default new HomePageActions();
