"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable no-var-requires */
const actions_1 = __importDefault(require("../../utils/actions"));
const helper_1 = require("../../utils/helper");
const brandsModels_1 = require("../models/brandsModels");
const homePageObjects_1 = require("../pageObjects/homePageObjects");
let elements;
const brand = (0, helper_1.getBrand)();
class HomePageActions {
    constructor() {
        this.urlBrandName = brand.siteUrl || '';
    }
    getElements() {
        switch (brand.name) {
            case brandsModels_1.BrandNames.tg:
                elements = homePageObjects_1.homePageObject.elementsTg;
                break;
            case brandsModels_1.BrandNames.wc:
                elements = homePageObjects_1.homePageObject.elementsWc;
                break;
            case brandsModels_1.BrandNames.lv:
                elements = homePageObjects_1.homePageObject.elementsLv;
                break;
            case brandsModels_1.BrandNames.cbol:
                elements = homePageObjects_1.homePageObject.elementsCbol;
                break;
            case brandsModels_1.BrandNames.csb:
                elements = homePageObjects_1.homePageObject.elementsCsb;
                break;
            default:
                console.log("Brand not declarated");
                return {};
        }
        return elements;
    }
    urlIsDisplayed() {
        return __awaiter(this, void 0, void 0, function* () {
            yield actions_1.default.urlIsDisplayed(this.urlBrandName);
        });
    }
    headerIsVisible() {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.isVisible((_a = elements.img_log) === null || _a === void 0 ? void 0 : _a.call(elements));
                yield actions_1.default.isVisible((_b = elements.img_badBet) === null || _b === void 0 ? void 0 : _b.call(elements));
                yield actions_1.default.isVisible((_c = elements.btn_login) === null || _c === void 0 ? void 0 : _c.call(elements));
                yield actions_1.default.isVisible((_d = elements.btn_register) === null || _d === void 0 ? void 0 : _d.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    menuIsVisible() {
        var _a, _b, _c, _d, _e, _f, _g;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.isVisible((_a = elements.btn_sports) === null || _a === void 0 ? void 0 : _a.call(elements));
                yield actions_1.default.isVisible((_b = elements.btn_liveBetting) === null || _b === void 0 ? void 0 : _b.call(elements));
                yield actions_1.default.isVisible((_c = elements.btn_poker) === null || _c === void 0 ? void 0 : _c.call(elements));
                yield actions_1.default.isVisible((_d = elements.btn_casino) === null || _d === void 0 ? void 0 : _d.call(elements));
                yield actions_1.default.isVisible((_e = elements.btn_liveCasino) === null || _e === void 0 ? void 0 : _e.call(elements));
                yield actions_1.default.isVisible((_f = elements.btn_promotions) === null || _f === void 0 ? void 0 : _f.call(elements));
                yield actions_1.default.isVisible((_g = elements.btn_cashier) === null || _g === void 0 ? void 0 : _g.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    footerIsVisible() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.isVisible((_a = elements.lbl_aboutUs) === null || _a === void 0 ? void 0 : _a.call(elements));
                yield actions_1.default.isVisible((_b = elements.img_safeSecure) === null || _b === void 0 ? void 0 : _b.call(elements));
                yield actions_1.default.isVisible((_c = elements.lbl_copyRights) === null || _c === void 0 ? void 0 : _c.call(elements));
                yield actions_1.default.isVisible((_d = elements.img_gammingTrust) === null || _d === void 0 ? void 0 : _d.call(elements));
                yield actions_1.default.isVisible((_e = elements.btn_rules) === null || _e === void 0 ? void 0 : _e.call(elements));
                yield actions_1.default.isVisible((_f = elements.btn_affiliates) === null || _f === void 0 ? void 0 : _f.call(elements));
                yield actions_1.default.isVisible((_g = elements.btn_contactUs) === null || _g === void 0 ? void 0 : _g.call(elements));
                yield actions_1.default.isVisible((_h = elements.btn_privacyPolicy) === null || _h === void 0 ? void 0 : _h.call(elements));
                yield actions_1.default.isVisible((_j = elements.btn_responsibleGaming) === null || _j === void 0 ? void 0 : _j.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    clickLoginBtn() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.click((_a = elements.btn_login) === null || _a === void 0 ? void 0 : _a.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    clickJoinBtn() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.click((_a = elements.btn_register) === null || _a === void 0 ? void 0 : _a.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
}
exports.default = new HomePageActions();
