import actions from '../../utils/actions';
import { getBrand } from '../../utils/helper';
import { BrandNames } from '../models/brandsModels';
import { joinPageModel } from '../models/joinPageModels';
import { joinPageObject } from '../pageObjects/joinPageObjects';

let elements: typeof joinPageModel;
const brand = getBrand();

class JoinPageActions {

  urlBrandName: string = brand.siteUrl || '';

  getElements(): typeof joinPageModel {
    switch (brand.name) {
      case BrandNames.tg:
        elements = joinPageObject.elementsTg;
        break;
      case BrandNames.wc:
        elements = joinPageObject.elementsWc;
        break;
      case BrandNames.lv:
        elements = joinPageObject.elementsLv;
        break;
      case BrandNames.cbol:
        elements = joinPageObject.elementsCbol;
        break;
      case BrandNames.csb:
        elements = joinPageObject.elementsCsb;
        break;
      default:
        console.log("Brand not declarated")
        return {} as typeof joinPageModel;
    }
    return elements;
  }

  async elementsAreVisible() {
    const elements = this.getElements();
    if (elements) {
      await actions.isVisible(elements.img_brand?.());
      await actions.isVisible(elements.lbl_title?.());
      await actions.isVisible(elements.in_firstName?.());
      await actions.isVisible(elements.in_lastName?.());
      await actions.isVisible(elements.in_email?.());
      await actions.isVisible(elements.in_password?.());
      await actions.isVisible(elements.sel_country?.());
      await actions.isVisible(elements.in_zip?.());
      await actions.isVisible(elements.sel_codePhone?.());
      await actions.isVisible(elements.in_phone?.());
      await actions.isVisible(elements.in_birthDate?.());
      await actions.isVisible(elements.btn_createAccount_disabled?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }

  async completeFirstName(firstName: string) {
    const element = this.getElements().in_firstName?.();
    if (element && !firstName.includes('NULL')) {
      await actions.click(element);
      await actions.sendKeys(element, firstName);
    }
  }

  async completeLastName(lastName: string) {
    const element = this.getElements().in_lastName?.();
    if (element && !lastName.includes('NULL')) {
      await actions.click(element);
      await actions.sendKeys(element, lastName);
    }
  }

  async completeEmail(email: string) {
    const element = this.getElements().in_email?.();
    if (element && !email.includes('NULL')) {
      await actions.click(element);
      await actions.sendKeys(element, email);
    }
  }

  async completePassword(password: string) {
    const element = this.getElements().in_password?.();
    if (element && !password.includes('NULL')) {
      await actions.click(element);
      await actions.sendKeys(element, password);
    }
  }

  async completeZip(zip: string) {
    const element = this.getElements().in_zip?.();
    if (element && !zip.includes('NULL')) {
      await actions.click(element);
      await actions.sendKeys(element, zip);
    }
  }

  async completePhone(phone: string) {
    const element = this.getElements().in_phone?.();
    if (element && !phone.includes('NULL')) {
      await actions.click(element);
      await actions.sendKeys(element, phone);
    }
  }

  async completeBirth(birth: string) {
    const element = this.getElements().in_birthDate?.();
    if (element && !birth.includes('NULL')) {
      await actions.click(element);
      await actions.sendKeys(element, birth);
    }
  }

  async completeCountry(country: string) {
    const element = this.getElements().sel_country?.();
    if (element && !country.includes('NULL')) {
      await actions.select(element, country);
    }
  }

  async clickBtnCreateAccounut() {
    const element = this.getElements().btn_createAccount_enabled?.();
    if (element) {
      await actions.click(element);
    }
  }

  async checkValidation(validation: string) {
    const elements = this.getElements();
    if (elements) {
      if (validation.includes('firstName'))
        await actions.isVisible(elements.err_firstName?.());

      if (validation.includes('lastName'))
        await actions.isVisible(elements.err_lastName?.())

      if (validation.includes('email'))
        await actions.isVisible(elements.err_email?.())

      if (validation.includes('emailInvalid'))
        await actions.isVisible(elements.err_email_invalid?.())

      if (validation.includes('password'))
        await actions.isVisible(elements.err_password?.())

      if (validation.includes('zip'))
        await actions.isVisible(elements.err_zip?.())

      if (validation.includes('phone'))
        await actions.isVisible(elements.err_phone?.())

      if (validation.includes('birth'))
        await actions.isVisible(elements.err_birth?.())

      if (validation.includes('younger'))
        await actions.isVisible(elements.err_birthYoung?.())

      await actions.isVisible(elements.btn_createAccount_disabled?.())
    }
  }
}

export default new JoinPageActions();