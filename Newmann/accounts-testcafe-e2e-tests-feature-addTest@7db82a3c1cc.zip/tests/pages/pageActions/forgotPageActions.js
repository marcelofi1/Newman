"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const actions_1 = __importDefault(require("../../utils/actions"));
const helper_1 = require("../../utils/helper");
const brandsModels_1 = require("../models/brandsModels");
const forgotPageObjects_1 = require("../pageObjects/forgotPageObjects");
let elements;
const brand = (0, helper_1.getBrand)();
class LoginPageActions {
    constructor() {
        this.urlBrandName = brand.siteUrl || '';
    }
    getElements() {
        switch (brand.name) {
            case brandsModels_1.BrandNames.tg:
                elements = forgotPageObjects_1.forgotPageObjects.elementsTg;
                break;
            case brandsModels_1.BrandNames.wc:
                elements = forgotPageObjects_1.forgotPageObjects.elementsWc;
                break;
            case brandsModels_1.BrandNames.lv:
                elements = forgotPageObjects_1.forgotPageObjects.elementsLv;
                break;
            case brandsModels_1.BrandNames.cbol:
                elements = forgotPageObjects_1.forgotPageObjects.elementsCbol;
                break;
            case brandsModels_1.BrandNames.csb:
                elements = forgotPageObjects_1.forgotPageObjects.elementsCsb;
                break;
            default:
                console.log("Brand not declarated");
                return {};
        }
        return elements;
    }
    elementsAreVisibles() {
        var _a, _b, _c, _d, _e, _f;
        return __awaiter(this, void 0, void 0, function* () {
            const element = this.getElements();
            if (element) {
                yield actions_1.default.isVisible((_a = element.img_tiggerGamming) === null || _a === void 0 ? void 0 : _a.call(element));
                yield actions_1.default.isVisible((_b = element.lbl_resetPassword) === null || _b === void 0 ? void 0 : _b.call(element));
                yield actions_1.default.isVisible((_c = element.lbl_instructions) === null || _c === void 0 ? void 0 : _c.call(element));
                yield actions_1.default.isVisible((_d = element.in_username) === null || _d === void 0 ? void 0 : _d.call(element));
                yield actions_1.default.isVisible((_e = element.btn_proceed) === null || _e === void 0 ? void 0 : _e.call(element));
                yield actions_1.default.isVisible((_f = element.lbl_needHelp) === null || _f === void 0 ? void 0 : _f.call(element));
            }
        });
    }
    errorElementsAreVisibles() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = this.getElements();
            if (element) {
                yield actions_1.default.isVisible((_a = element.lbl_attempts) === null || _a === void 0 ? void 0 : _a.call(element));
                yield actions_1.default.isVisible((_b = element.lbl_errorDetails) === null || _b === void 0 ? void 0 : _b.call(element));
            }
        });
    }
    attemptsElementsAreVisibles() {
        var _a, _b, _c, _d, _e;
        return __awaiter(this, void 0, void 0, function* () {
            const element = this.getElements();
            if (element) {
                yield actions_1.default.isVisible((_a = element.lbl_passwordHelp) === null || _a === void 0 ? void 0 : _a.call(element));
                yield actions_1.default.isVisible((_b = element.lbl_exceeded) === null || _b === void 0 ? void 0 : _b.call(element));
                yield actions_1.default.isVisible((_c = element.lbl_havingDifficulties) === null || _c === void 0 ? void 0 : _c.call(element));
                yield actions_1.default.isVisible((_d = element.btn_contactUs) === null || _d === void 0 ? void 0 : _d.call(element));
                yield actions_1.default.isVisible((_e = element.btn_forgot) === null || _e === void 0 ? void 0 : _e.call(element));
            }
        });
    }
    linkElementsAreVisibles() {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            const element = this.getElements();
            if (element) {
                yield actions_1.default.isVisible((_a = element.lbl_titleResetPassword) === null || _a === void 0 ? void 0 : _a.call(element));
                yield actions_1.default.isVisible((_b = element.lbl_linkMail) === null || _b === void 0 ? void 0 : _b.call(element));
                yield actions_1.default.isVisible((_c = element.btn_contactUsOk) === null || _c === void 0 ? void 0 : _c.call(element));
            }
        });
    }
    completeUsername(username) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const element = this.getElements();
            if (element) {
                yield actions_1.default.sendKeys((_a = element.in_username) === null || _a === void 0 ? void 0 : _a.call(element), username);
            }
        });
    }
    clickBtnProceed() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const element = this.getElements();
            if (element) {
                yield actions_1.default.click((_a = element.btn_proceed) === null || _a === void 0 ? void 0 : _a.call(element));
            }
        });
    }
    clickBtnForgot() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const element = this.getElements();
            if (element) {
                yield actions_1.default.click((_a = element.btn_forgot) === null || _a === void 0 ? void 0 : _a.call(element));
            }
        });
    }
}
exports.default = new LoginPageActions();
