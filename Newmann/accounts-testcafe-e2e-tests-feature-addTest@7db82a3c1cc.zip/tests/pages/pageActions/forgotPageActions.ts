import actions from '../../utils/actions';
import { getBrand } from '../../utils/helper';
import { BrandNames } from '../models/brandsModels';
import { forgotPageModel } from '../models/forgotPageModels';
import { forgotPageObjects } from '../pageObjects/forgotPageObjects';

let elements: typeof forgotPageModel | undefined;
const brand = getBrand();

class LoginPageActions {

  urlBrandName: string = brand.siteUrl || '';

  getElements(): typeof forgotPageModel {
    switch (brand.name) {
      case BrandNames.tg:
        elements = forgotPageObjects.elementsTg;
        break;
      case BrandNames.wc:
        elements = forgotPageObjects.elementsWc;
        break;
      case BrandNames.lv:
        elements = forgotPageObjects.elementsLv;
        break;
      case BrandNames.cbol:
        elements = forgotPageObjects.elementsCbol;
        break;
      case BrandNames.csb:
        elements = forgotPageObjects.elementsCsb;
        break;
      default:
        console.log("Brand not declarated");
        return {} as typeof forgotPageModel;
    }
    return elements;
  }

  async elementsAreVisibles() {
    const element = this.getElements();
    if (element) {
      await actions.isVisible(element.img_tiggerGamming?.());
      await actions.isVisible(element.lbl_resetPassword?.());
      await actions.isVisible(element.lbl_instructions?.());
      await actions.isVisible(element.in_username?.());
      await actions.isVisible(element.btn_proceed?.());
      await actions.isVisible(element.lbl_needHelp?.());
    }
  }

  async errorElementsAreVisibles() {
    const element = this.getElements();
    if (element) {
      await actions.isVisible(element.lbl_attempts?.());
      await actions.isVisible(element.lbl_errorDetails?.());
    }
  }

  async attemptsElementsAreVisibles() {
    const element = this.getElements();
    if (element) {
      await actions.isVisible(element.lbl_passwordHelp?.());
      await actions.isVisible(element.lbl_exceeded?.());
      await actions.isVisible(element.lbl_havingDifficulties?.());
      await actions.isVisible(element.btn_contactUs?.());
      await actions.isVisible(element.btn_forgot?.());
    }
  }

  async linkElementsAreVisibles() {
    const element = this.getElements();
    if (element) {
      await actions.isVisible(element.lbl_titleResetPassword?.());
      await actions.isVisible(element.lbl_linkMail?.());
      await actions.isVisible(element.btn_contactUsOk?.());
    }
  }

  async completeUsername(username: string) {
    const element = this.getElements();
    if (element) {
      await actions.sendKeys(element.in_username?.(), username);
    }
  }

  async clickBtnProceed() {
    const element = this.getElements();
    if (element) {
      await actions.click(element.btn_proceed?.());
    }
  }

  async clickBtnForgot() {
    const element = this.getElements();
    if (element) {
      await actions.click(element.btn_forgot?.());
    }
  }
}

export default new LoginPageActions();