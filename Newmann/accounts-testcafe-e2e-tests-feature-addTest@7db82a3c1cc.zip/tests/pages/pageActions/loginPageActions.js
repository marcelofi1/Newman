"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const actions_1 = __importDefault(require("../../utils/actions"));
const helper_1 = require("../../utils/helper");
const brandsModels_1 = require("../models/brandsModels");
const loginPageObjects_1 = require("../pageObjects/loginPageObjects");
let elements;
const brand = (0, helper_1.getBrand)();
class LoginPageActions {
    constructor() {
        this.urlBrandName = brand.siteUrl || '';
    }
    ;
    getElements() {
        switch (brand.name) {
            case brandsModels_1.BrandNames.tg:
                elements = loginPageObjects_1.loginPageObject.elementsTg;
                break;
            case brandsModels_1.BrandNames.wc:
                elements = loginPageObjects_1.loginPageObject.elementsWc;
                break;
            case brandsModels_1.BrandNames.lv:
                elements = loginPageObjects_1.loginPageObject.elementsLv;
                break;
            case brandsModels_1.BrandNames.cbol:
                elements = loginPageObjects_1.loginPageObject.elementsCbol;
                break;
            case brandsModels_1.BrandNames.csb:
                elements = loginPageObjects_1.loginPageObject.elementsCsb;
                break;
            default:
                console.log("Brand not declarated");
                return {};
        }
        return elements;
    }
    elementsAreVisible() {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.isVisible((_a = elements.in_username) === null || _a === void 0 ? void 0 : _a.call(elements));
                yield actions_1.default.isVisible((_b = elements.in_password) === null || _b === void 0 ? void 0 : _b.call(elements));
                yield actions_1.default.isVisible((_c = elements.btn_login) === null || _c === void 0 ? void 0 : _c.call(elements));
                yield actions_1.default.isVisible((_d = elements.btn_forgot) === null || _d === void 0 ? void 0 : _d.call(elements));
                yield actions_1.default.isVisible((_e = elements.btn_register) === null || _e === void 0 ? void 0 : _e.call(elements));
                yield actions_1.default.isVisible((_f = elements.lbl_dontHaveAccount) === null || _f === void 0 ? void 0 : _f.call(elements));
                yield actions_1.default.isVisible((_g = elements.lbl_login) === null || _g === void 0 ? void 0 : _g.call(elements));
                yield actions_1.default.isVisible((_h = elements.lbl_signIn) === null || _h === void 0 ? void 0 : _h.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    completeUsername(username) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).in_username) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.sendKeys(element, username);
            }
        });
    }
    completePassword(password) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).in_password) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.sendKeys(element, password);
            }
        });
    }
    clickBtnLogin() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).btn_login) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.click(element);
            }
        });
    }
    clickBtnLoginRaf() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).btn_loginRaf) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.click(element);
            }
        });
    }
    clickBtnForgot() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).btn_forgot) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.click(element);
            }
        });
    }
}
exports.default = new LoginPageActions();
