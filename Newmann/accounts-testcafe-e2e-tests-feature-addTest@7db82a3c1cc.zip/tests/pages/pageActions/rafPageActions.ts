import actions from '../../utils/actions';
import { getBrand } from '../../utils/helper';
import { BrandNames } from '../models/brandsModels';
import { rafPageModels } from '../models/rafPageModels';
import { rafPageObject } from '../pageObjects/rafPageObjects';

let elements: typeof rafPageModels | undefined;
const brand = getBrand();

class LoginPageActions {

  urlBrandName: string = brand.siteUrl || '';

  getElements(): typeof rafPageModels {
    switch (brand.name) {
      case BrandNames.tg:
        elements = rafPageObject.elementsTg;
        break;
      case BrandNames.wc:
        elements = rafPageObject.elementsWc;
        break;
      case BrandNames.lv:
        elements = rafPageObject.elementsLv;
        break;
      case BrandNames.cbol:
        elements = rafPageObject.elementsCbol;
        break;
      case BrandNames.csb:
        elements = rafPageObject.elementsCsb;
        break;
        default: 
        console.log("Brand not declarated");
        return {} as typeof rafPageModels;
    }
    return elements;
  }

  async clickBtnMyAccount() {
    const element = this.getElements().btn_MyAccount?.();
    if (element) {
      await actions.isVisible(element);
      await actions.click(element);
    } else {
      console.log('Error: Elemento no encontrado');
    }
  }
  
  async clickBtnViewRaf() {
    const collapseElement = this.getElements().collapse_Raf?.();
    const btnViewRafElement = this.getElements().btn_ViewRaf?.();
    if (collapseElement && btnViewRafElement) {
      await actions.isVisible(collapseElement);
      await actions.click(collapseElement);
      await actions.isVisible(btnViewRafElement);
      await actions.click(btnViewRafElement);
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async getValueRaf() {
    const element = this.getElements().lbl_QuantityRaf?.();
    if (element) {
      await actions.isVisible(element);
      return await actions.getValue(element);
    } else {
      console.log('Error: Elemento no encontrado');
      return null;
    }
  }
  
  async clickBtnSports() {
    const element = this.getElements().btn_Sports?.();
    if (element) {
      await actions.isVisible(element);
      await actions.click(element);
    } else {
      console.log('Error: Elemento no encontrado');
    }
  }
  
  async closeModalRaf() {
    const element = this.getElements().btn_ModalRaf?.();
    if (element) {
      await actions.isVisible(element);
      await actions.click(element);
    } else {
      console.log('Error: Elemento no encontrado');
    }
  }
  
  async clickBtnLogout() {
    const element = this.getElements().btn_logout?.();
    if (element) {
      await actions.isVisible(element);
      await actions.click(element);
    } else {
      console.log('Error: Elemento no encontrado');
    }
  }
  
  async clickBtnHome() {
    const element = this.getElements().btn_home?.();
    if (element) {
      await actions.isVisible(element);
      await actions.click(element);
    } else {
      console.log('Error: Elemento no encontrado');
    }
  }
  
  async getValueLinkRaf() {
    const element = this.getElements().lbl_RafLink?.();
    if (element) {
      await actions.isVisible(element);
      return await actions.getValue(element);
    } else {
      console.log('Error: Elemento no encontrado');
      return null;
    }
  }
  
  async clickBtnRaf() {
    const collapseElement = this.getElements().collapse_Raf?.();
    const btnRafElement = this.getElements().btn_Raf?.();
    if (collapseElement && btnRafElement) {
      await actions.isVisible(collapseElement);
      await actions.click(collapseElement);
      await actions.isVisible(btnRafElement);
      await actions.click(btnRafElement);
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async validateURLRaf(url: string) {
    await actions.urlIsDisplayed(url);
  }

}

export default new LoginPageActions();