import actions from '../../utils/actions';
import { getBrand } from '../../utils/helper';
import { BrandNames } from '../models/brandsModels';
import { mailsPageModels } from '../models/mailsPageModels';
import { mailsPageObject } from '../pageObjects/mailsPageObjects';

let elements: typeof mailsPageModels | undefined;
const brand = getBrand();

class MailsPageActions {

  urlBrandName: string = brand.siteUrl || '';

  getElements(): typeof mailsPageModels {
    switch (brand.name) {
      case BrandNames.tg:
        elements = mailsPageObject.elementsTg;
        break;
      case BrandNames.wc:
        elements = mailsPageObject.elementsWc;
        break;
      case BrandNames.lv:
        elements = mailsPageObject.elementsLv;
        break;
      case BrandNames.cbol:
        elements = mailsPageObject.elementsCbol;
        break;
      case BrandNames.csb:
        elements = mailsPageObject.elementsCsb;
        break;
        default: 
        console.log("Brand not declarated");
        return {} as typeof mailsPageModels;
    }
    return elements;
  }

  async completeMail(mail: string) {
    const element = this.getElements().in_mailYop?.();
    if (element) {
      await actions.isVisible(element);
      await actions.sendKeys(element, mail);
    } else {
      console.log('Error: Elemento no encontrado');
    }
  }
  
  async clickBtnGoToMail() {
    const element = this.getElements().btn_mail?.();
    if (element) {
      await actions.isVisible(element);
      await actions.click(element);
    } else {
      console.log('Error: Elemento no encontrado');
    }
  }
  
  async getLinkRaf() {
    const iframeElement = this.getElements().iframe_Mail?.();
    const linkElement = this.getElements().link_Raf?.();
    if (iframeElement && linkElement) {
      await actions.switchIFrame(iframeElement);
      return await actions.getAtributte(linkElement, 'href');
    } else {
      console.log('Error: Elementos no encontrados');
      return null;
    }
  }
}

export default new MailsPageActions();