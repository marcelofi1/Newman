"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const actions_1 = __importDefault(require("../../utils/actions"));
const helper_1 = require("../../utils/helper");
const brandsModels_1 = require("../models/brandsModels");
const changePassPageObjects_1 = require("../pageObjects/changePassPageObjects");
let elements;
const brand = (0, helper_1.getBrand)();
class ChangePassPageActions {
    constructor() {
        this.urlBrandName = brand.siteUrl || '';
    }
    getElements() {
        switch (brand.name) {
            case brandsModels_1.BrandNames.tg:
                elements = changePassPageObjects_1.changePassPageObjects.elementsTg;
                break;
            case brandsModels_1.BrandNames.wc:
                elements = changePassPageObjects_1.changePassPageObjects.elementsWc;
                break;
            case brandsModels_1.BrandNames.lv:
                elements = changePassPageObjects_1.changePassPageObjects.elementsLv;
                break;
            case brandsModels_1.BrandNames.cbol:
                elements = changePassPageObjects_1.changePassPageObjects.elementsCbol;
                break;
            case brandsModels_1.BrandNames.csb:
                elements = changePassPageObjects_1.changePassPageObjects.elementsCsb;
                break;
            default:
                console.log("Brand not declarated");
                return {};
        }
        return elements;
    }
    elementsAreVisibles() {
        var _a, _b, _c, _d, _e;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements(); // Obtener los elementos
            if (elements) {
                yield actions_1.default.isVisible((_a = elements.lbl_changePassword) === null || _a === void 0 ? void 0 : _a.call(elements));
                yield actions_1.default.isVisible((_b = elements.lbl_instructions) === null || _b === void 0 ? void 0 : _b.call(elements));
                yield actions_1.default.isVisible((_c = elements.in_newPassord) === null || _c === void 0 ? void 0 : _c.call(elements));
                yield actions_1.default.isVisible((_d = elements.in_reEnterPass) === null || _d === void 0 ? void 0 : _d.call(elements));
                yield actions_1.default.isVisible((_e = elements.btn_proceed) === null || _e === void 0 ? void 0 : _e.call(elements));
                yield this.setPassword();
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    completeNewPass(newPass) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.sendKeys((_a = elements.in_newPassord) === null || _a === void 0 ? void 0 : _a.call(elements), yield newPass);
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    completeReEnterPass(reEnterPass) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.sendKeys((_a = elements.in_reEnterPass) === null || _a === void 0 ? void 0 : _a.call(elements), yield reEnterPass);
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    clickProceedBtn() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.click((_a = elements.btn_proceed) === null || _a === void 0 ? void 0 : _a.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    validErrorPass() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.isVisible((_a = elements.lbl_invalid) === null || _a === void 0 ? void 0 : _a.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    validEmptyNewPass() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.isVisible((_a = elements.lbl_invalid) === null || _a === void 0 ? void 0 : _a.call(elements));
                yield this.elementsAreVisibles();
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    validEmptyReEnterPass() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.isElementNotDisplayed((_a = elements.lbl_invalid) === null || _a === void 0 ? void 0 : _a.call(elements));
                yield this.elementsAreVisibles();
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    validChangePass() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.isVisible((_a = elements.lbl_userIdLogin) === null || _a === void 0 ? void 0 : _a.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    validNotMatchPasswords() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.isVisible((_a = elements.lbl_notMatchPasswords) === null || _a === void 0 ? void 0 : _a.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    validOldPassword() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.isVisible((_a = elements.lbl_oldPassword) === null || _a === void 0 ? void 0 : _a.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    setPassword() {
        return __awaiter(this, void 0, void 0, function* () {
            this.password = "ValidPass" + Math.floor(Math.random() * 10000) + "!";
        });
    }
    getPassword() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.password;
        });
    }
}
exports.default = new ChangePassPageActions();
