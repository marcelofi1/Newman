import actions from '../../utils/actions';
import { getBrand } from '../../utils/helper';
import { BrandNames } from '../models/brandsModels';
import { loginPageModel } from '../models/loginPageModels';
import { loginPageObject } from '../pageObjects/loginPageObjects';

let elements: typeof loginPageModel | undefined;
const brand = getBrand();

class LoginPageActions {

  urlBrandName: string = brand.siteUrl || '';;

  getElements(): typeof loginPageModel {
    switch (brand.name) {
      case BrandNames.tg:
        elements = loginPageObject.elementsTg;
        break;
      case BrandNames.wc:
        elements = loginPageObject.elementsWc;
        break;
      case BrandNames.lv:
        elements = loginPageObject.elementsLv;
        break;
      case BrandNames.cbol:
        elements = loginPageObject.elementsCbol;
        break;
      case BrandNames.csb:
        elements = loginPageObject.elementsCsb;
        break;
      default: 
        console.log("Brand not declarated");
        return {} as typeof loginPageModel;
    }
    return elements;
  }

  async elementsAreVisible() {
    const elements = this.getElements();
    if (elements) {
      await actions.isVisible(elements.in_username?.());
      await actions.isVisible(elements.in_password?.());
      await actions.isVisible(elements.btn_login?.());
      await actions.isVisible(elements.btn_forgot?.());
      await actions.isVisible(elements.btn_register?.());
      await actions.isVisible(elements.lbl_dontHaveAccount?.());
      await actions.isVisible(elements.lbl_login?.());
      await actions.isVisible(elements.lbl_signIn?.());
    } else {
      console.log('Error: Elementos no encontrados');
    }
  }
  
  async completeUsername(username: string) {
    const element = this.getElements().in_username?.();
    if (element) {
      await actions.sendKeys(element, username);
    }
  }
  
  async completePassword(password: string) {
    const element = this.getElements().in_password?.();
    if (element) {
      await actions.sendKeys(element, password);
    }
  }
  
  async clickBtnLogin() {
    const element = this.getElements().btn_login?.();
    if (element) {
      await actions.click(element);
    }
  }
  
  async clickBtnLoginRaf() {
    const element = this.getElements().btn_loginRaf?.();
    if (element) {
      await actions.click(element);
    }
  }
  
  async clickBtnForgot() {
    const element = this.getElements().btn_forgot?.();
    if (element) {
      await actions.click(element);
    }
  }
}

export default new LoginPageActions();