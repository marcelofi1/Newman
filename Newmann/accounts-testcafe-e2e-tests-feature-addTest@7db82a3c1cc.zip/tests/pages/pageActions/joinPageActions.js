"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const actions_1 = __importDefault(require("../../utils/actions"));
const helper_1 = require("../../utils/helper");
const brandsModels_1 = require("../models/brandsModels");
const joinPageObjects_1 = require("../pageObjects/joinPageObjects");
let elements;
const brand = (0, helper_1.getBrand)();
class JoinPageActions {
    constructor() {
        this.urlBrandName = brand.siteUrl || '';
    }
    getElements() {
        switch (brand.name) {
            case brandsModels_1.BrandNames.tg:
                elements = joinPageObjects_1.joinPageObject.elementsTg;
                break;
            case brandsModels_1.BrandNames.wc:
                elements = joinPageObjects_1.joinPageObject.elementsWc;
                break;
            case brandsModels_1.BrandNames.lv:
                elements = joinPageObjects_1.joinPageObject.elementsLv;
                break;
            case brandsModels_1.BrandNames.cbol:
                elements = joinPageObjects_1.joinPageObject.elementsCbol;
                break;
            case brandsModels_1.BrandNames.csb:
                elements = joinPageObjects_1.joinPageObject.elementsCsb;
                break;
            default:
                console.log("Brand not declarated");
                return {};
        }
        return elements;
    }
    elementsAreVisible() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                yield actions_1.default.isVisible((_a = elements.img_brand) === null || _a === void 0 ? void 0 : _a.call(elements));
                yield actions_1.default.isVisible((_b = elements.lbl_title) === null || _b === void 0 ? void 0 : _b.call(elements));
                yield actions_1.default.isVisible((_c = elements.in_firstName) === null || _c === void 0 ? void 0 : _c.call(elements));
                yield actions_1.default.isVisible((_d = elements.in_lastName) === null || _d === void 0 ? void 0 : _d.call(elements));
                yield actions_1.default.isVisible((_e = elements.in_email) === null || _e === void 0 ? void 0 : _e.call(elements));
                yield actions_1.default.isVisible((_f = elements.in_password) === null || _f === void 0 ? void 0 : _f.call(elements));
                yield actions_1.default.isVisible((_g = elements.sel_country) === null || _g === void 0 ? void 0 : _g.call(elements));
                yield actions_1.default.isVisible((_h = elements.in_zip) === null || _h === void 0 ? void 0 : _h.call(elements));
                yield actions_1.default.isVisible((_j = elements.sel_codePhone) === null || _j === void 0 ? void 0 : _j.call(elements));
                yield actions_1.default.isVisible((_k = elements.in_phone) === null || _k === void 0 ? void 0 : _k.call(elements));
                yield actions_1.default.isVisible((_l = elements.in_birthDate) === null || _l === void 0 ? void 0 : _l.call(elements));
                yield actions_1.default.isVisible((_m = elements.btn_createAccount_disabled) === null || _m === void 0 ? void 0 : _m.call(elements));
            }
            else {
                console.log('Error: Elementos no encontrados');
            }
        });
    }
    completeFirstName(firstName) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).in_firstName) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element && !firstName.includes('NULL')) {
                yield actions_1.default.click(element);
                yield actions_1.default.sendKeys(element, firstName);
            }
        });
    }
    completeLastName(lastName) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).in_lastName) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element && !lastName.includes('NULL')) {
                yield actions_1.default.click(element);
                yield actions_1.default.sendKeys(element, lastName);
            }
        });
    }
    completeEmail(email) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).in_email) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element && !email.includes('NULL')) {
                yield actions_1.default.click(element);
                yield actions_1.default.sendKeys(element, email);
            }
        });
    }
    completePassword(password) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).in_password) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element && !password.includes('NULL')) {
                yield actions_1.default.click(element);
                yield actions_1.default.sendKeys(element, password);
            }
        });
    }
    completeZip(zip) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).in_zip) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element && !zip.includes('NULL')) {
                yield actions_1.default.click(element);
                yield actions_1.default.sendKeys(element, zip);
            }
        });
    }
    completePhone(phone) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).in_phone) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element && !phone.includes('NULL')) {
                yield actions_1.default.click(element);
                yield actions_1.default.sendKeys(element, phone);
            }
        });
    }
    completeBirth(birth) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).in_birthDate) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element && !birth.includes('NULL')) {
                yield actions_1.default.click(element);
                yield actions_1.default.sendKeys(element, birth);
            }
        });
    }
    completeCountry(country) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).sel_country) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element && !country.includes('NULL')) {
                yield actions_1.default.select(element, country);
            }
        });
    }
    clickBtnCreateAccounut() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const element = (_b = (_a = this.getElements()).btn_createAccount_enabled) === null || _b === void 0 ? void 0 : _b.call(_a);
            if (element) {
                yield actions_1.default.click(element);
            }
        });
    }
    checkValidation(validation) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
        return __awaiter(this, void 0, void 0, function* () {
            const elements = this.getElements();
            if (elements) {
                if (validation.includes('firstName'))
                    yield actions_1.default.isVisible((_a = elements.err_firstName) === null || _a === void 0 ? void 0 : _a.call(elements));
                if (validation.includes('lastName'))
                    yield actions_1.default.isVisible((_b = elements.err_lastName) === null || _b === void 0 ? void 0 : _b.call(elements));
                if (validation.includes('email'))
                    yield actions_1.default.isVisible((_c = elements.err_email) === null || _c === void 0 ? void 0 : _c.call(elements));
                if (validation.includes('emailInvalid'))
                    yield actions_1.default.isVisible((_d = elements.err_email_invalid) === null || _d === void 0 ? void 0 : _d.call(elements));
                if (validation.includes('password'))
                    yield actions_1.default.isVisible((_e = elements.err_password) === null || _e === void 0 ? void 0 : _e.call(elements));
                if (validation.includes('zip'))
                    yield actions_1.default.isVisible((_f = elements.err_zip) === null || _f === void 0 ? void 0 : _f.call(elements));
                if (validation.includes('phone'))
                    yield actions_1.default.isVisible((_g = elements.err_phone) === null || _g === void 0 ? void 0 : _g.call(elements));
                if (validation.includes('birth'))
                    yield actions_1.default.isVisible((_h = elements.err_birth) === null || _h === void 0 ? void 0 : _h.call(elements));
                if (validation.includes('younger'))
                    yield actions_1.default.isVisible((_j = elements.err_birthYoung) === null || _j === void 0 ? void 0 : _j.call(elements));
                yield actions_1.default.isVisible((_k = elements.btn_createAccount_disabled) === null || _k === void 0 ? void 0 : _k.call(elements));
            }
        });
    }
}
exports.default = new JoinPageActions();
