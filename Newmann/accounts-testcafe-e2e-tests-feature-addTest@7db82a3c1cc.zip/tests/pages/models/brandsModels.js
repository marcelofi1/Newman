"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BrandNames = void 0;
var BrandNames;
(function (BrandNames) {
    BrandNames["tg"] = "tg";
    BrandNames["wc"] = "wc";
    BrandNames["lv"] = "lv";
    BrandNames["cbol"] = "cbol";
    BrandNames["csb"] = "csb";
    BrandNames["auxiliar"] = "empty";
    BrandNames["backend"] = "backend";
})(BrandNames = exports.BrandNames || (exports.BrandNames = {}));
