"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rafPageModels = void 0;
class RafPageModel {
    constructor() { }
}
exports.rafPageModels = new RafPageModel();
