class JoinPageModel{
    constructor(){}

    img_brand: Function | undefined;
    lbl_title: Function | undefined;
    in_firstName: Function | undefined;
    in_lastName: Function | undefined;
    in_email: Function | undefined;
    in_password: Function | undefined;
    sel_country: Function | undefined;
    in_zip: Function | undefined;
    sel_codePhone: Function | undefined;
    in_phone: Function | undefined;
    in_birthDate: Function | undefined;
    btn_createAccount_disabled: Function | undefined;
    btn_createAccount_enabled: Function | undefined;

    err_firstName: Function | undefined;
    err_lastName: Function | undefined;
    err_email: Function | undefined;
    err_email_invalid: Function | undefined;
    err_password: Function | undefined;
    err_zip: Function | undefined;
    err_phone: Function | undefined;
    err_birth: Function | undefined;
    err_birthYoung: Function | undefined;

    checkOk_firstName: Function | undefined;
    checkOk_lastName: Function | undefined;
    checkOk_email: Function | undefined;
    checkOk_password: Function | undefined;
    checkOk_zip: Function | undefined;
    checkOk_birth: Function | undefined;
}

export const joinPageModel = new JoinPageModel()