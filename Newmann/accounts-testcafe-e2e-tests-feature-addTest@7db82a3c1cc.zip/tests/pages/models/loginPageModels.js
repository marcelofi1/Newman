"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loginPageModel = void 0;
class LoginPageModel {
    constructor() { }
}
exports.loginPageModel = new LoginPageModel();
