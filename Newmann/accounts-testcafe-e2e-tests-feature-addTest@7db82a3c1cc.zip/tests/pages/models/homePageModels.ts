class HomePageModel{
    constructor(){}
    
    //Header
    img_log: Function | undefined;
    img_badBet: Function | undefined;
    btn_login: Function | undefined;
    btn_register: Function | undefined;

    //Menu
    btn_sports: Function | undefined;
    btn_liveBetting: Function | undefined;
    btn_poker: Function | undefined;
    btn_casino: Function | undefined;
    btn_liveCasino: Function | undefined;
    btn_promotions: Function | undefined;
    btn_cashier: Function | undefined;

    //Footer
    lbl_aboutUs: Function | undefined;
    img_safeSecure: Function | undefined;
    lbl_copyRights: Function | undefined;
    img_gammingTrust: Function | undefined;
    btn_rules: Function | undefined;
    btn_affiliates: Function | undefined;
    btn_contactUs: Function | undefined;
    btn_privacyPolicy: Function | undefined;
    btn_responsibleGaming: Function | undefined;

}

export const homePageModel = new HomePageModel()