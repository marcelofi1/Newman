"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mailsPageModels = void 0;
class MailsPageModel {
    constructor() { }
}
exports.mailsPageModels = new MailsPageModel();
