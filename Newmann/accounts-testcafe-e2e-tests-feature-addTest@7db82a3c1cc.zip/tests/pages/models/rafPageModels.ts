class RafPageModel {
    constructor() { }

    btn_MyAccount: Function | undefined;
    collapse_Raf: Function | undefined;
    btn_Raf: Function | undefined;

    btn_ViewRaf: Function | undefined;
    lbl_QuantityRaf: Function | undefined;
    btn_Sports: Function | undefined;
    lbl_RafLink: Function | undefined;
    btn_ModalRaf: Function | undefined;
    btn_logout: Function | undefined;
    btn_home: Function | undefined;
}

export const rafPageModels = new RafPageModel()