export enum BrandNames{
    tg = "tg",
    wc = "wc",
    lv = "lv",
    cbol = "cbol",
    csb = "csb",
    auxiliar = 'empty',
    backend = 'backend'
}