class LoginPageModel {
    constructor() { }
    
    in_username: Function | undefined;
    in_password: Function | undefined;
    btn_login: Function | undefined;
    btn_loginRaf: Function | undefined;

    btn_forgot: Function | undefined;
    btn_register: Function | undefined;
    lbl_dontHaveAccount: Function | undefined;
    lbl_login: Function | undefined;
    lbl_signIn: Function | undefined;
}

export const loginPageModel = new LoginPageModel()