class MailsPageModel {
    constructor() { }

    in_mailYop: Function | undefined;
    btn_mail: Function | undefined;
    link_Raf: Function | undefined;
    iframe_Mail: Function | undefined;
}

export const mailsPageModels = new MailsPageModel()