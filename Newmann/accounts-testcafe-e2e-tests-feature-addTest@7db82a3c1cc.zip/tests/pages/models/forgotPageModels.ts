class ForgotPageModel{
    constructor(){}

    img_tiggerGamming: Function | undefined;
    lbl_resetPassword: Function | undefined;
    lbl_instructions: Function | undefined;
    in_username: Function | undefined;
    btn_proceed: Function | undefined;
    lbl_needHelp: Function | undefined;

    //Errors
    lbl_attempts: Function | undefined;
    lbl_errorDetails: Function | undefined;

    //exceeded attempts page
    lbl_passwordHelp: Function | undefined;
    lbl_exceeded: Function | undefined;
    lbl_havingDifficulties: Function | undefined;
    btn_contactUs: Function | undefined;
    btn_forgot: Function | undefined;

    //forgot password page
    lbl_titleResetPassword: Function | undefined;
    lbl_linkMail: Function | undefined;
    btn_contactUsOk: Function | undefined;

}

export const forgotPageModel = new ForgotPageModel()