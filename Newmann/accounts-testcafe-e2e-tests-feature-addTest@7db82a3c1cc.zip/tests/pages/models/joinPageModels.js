"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.joinPageModel = void 0;
class JoinPageModel {
    constructor() { }
}
exports.joinPageModel = new JoinPageModel();
