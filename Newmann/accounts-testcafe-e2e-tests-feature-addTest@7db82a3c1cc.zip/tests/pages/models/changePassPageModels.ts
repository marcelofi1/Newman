class ChangePassPageModel{
    constructor(){}

    lbl_changePassword: Function | undefined;
    lbl_instructions: Function | undefined;
    in_newPassord: Function | undefined;
    in_reEnterPass: Function | undefined;
    btn_proceed: Function | undefined;

    //Errors
    lbl_invalid: Function | undefined;
    lbl_notMatchPasswords: Function | undefined;
    lbl_oldPassword: Function | undefined;

    //ValidationOk
    lbl_userIdLogin: Function | undefined;
}

export const changePassPageModels = new ChangePassPageModel()