"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.homePageModel = void 0;
class HomePageModel {
    constructor() { }
}
exports.homePageModel = new HomePageModel();
