"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.changePassPageModels = void 0;
class ChangePassPageModel {
    constructor() { }
}
exports.changePassPageModels = new ChangePassPageModel();
