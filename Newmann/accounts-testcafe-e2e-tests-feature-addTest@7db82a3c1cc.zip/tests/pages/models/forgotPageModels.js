"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.forgotPageModel = void 0;
class ForgotPageModel {
    constructor() { }
}
exports.forgotPageModel = new ForgotPageModel();
