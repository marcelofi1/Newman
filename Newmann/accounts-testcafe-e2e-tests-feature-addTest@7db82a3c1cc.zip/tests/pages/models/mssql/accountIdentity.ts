class AccountIdentity{
    customerID: string | undefined;
    password: string | undefined;
    salt: string | undefined;
    rowCreated: string | undefined;
    rowModified: string | undefined;
}