import { Selector } from 'testcafe';

class JoinPageObjects {
  elementsTg = {
    img_brand: () => Selector('body > div.template__main > a'),
    lbl_title: () => Selector('div.card__header > h1').withText('Let\'s Create Your Account!'),
    in_firstName: () => Selector('#FirstName'),
    in_lastName: () => Selector('#LastName'),
    in_email: () => Selector('#EMail'),
    in_password: () => Selector('#PasswordJ'),
    sel_country: () => Selector('#Country'),
    in_zip: () => Selector('#Zip'),
    sel_codePhone: () => Selector('div.iti.iti--allow-dropdown.iti--separate-dial-code > div'),
    in_phone: () => Selector('#HomePhone'),
    in_birthDate: () => Selector('#BirthDate'),
    btn_createAccount_disabled: () => Selector('#btnsubmit').withAttribute('disabled', 'disabled'),
    btn_createAccount_enabled: () => Selector('#btnsubmit').withAttribute('disabled', 'enabled'),

    err_firstName: () => Selector('#input-FirstName > div > div.invalid-feedback').withText('Please enter your first name'),
    err_lastName: () => Selector('#input-LastName > div > div.invalid-feedback').withText('Please enter your last name'),
    err_email: () => Selector('#input-EMail > div > div.invalid-feedback > span:nth-child(4)').withText('Please enter your email'),
    err_email_invalid: () => Selector('#input-EMail > div > div.invalid-feedback > span:nth-child(4)').withText('Please enter a valid email'),
    err_password: () => Selector('div.password__footer__error').withText('Please enter a valid password'),
    err_zip: () => Selector('#input-Zip > div > div.invalid-feedback > div > span').withText('Please enter a valid zip / postal code'),
    err_phone: () => Selector('div.form-group--phone__error-msg').withText('Please enter a valid phone number'),
    err_birth: () => Selector('#input-BirthDate > div > div.invalid-feedback > span > span').withText('Please enter your date of birth'),
    err_birthYoung: () => Selector('#input-BirthDate > div > div.invalid-feedback > span > span').withText('You must be at least 18 years of age to create an account'),
    
    checkOk_firstName: () => Selector('#input-LastName > div > div.input-group-append > span > svg'),
    checkOk_lastName: () => Selector('#input-LastName > div > div.input-group-append > span > svg'),
    checkOk_email: () => Selector('#input-EMail > div > div.input-group-append > span > svg'),
    checkOk_password: () => Selector('#input-PasswordJ > div > div.input-group-append > span > svg'),
    checkOk_zip: () => Selector('#input-Zip > div > div.input-group-append > span > svg'),
    checkOk_birth: () => Selector('#input-BirthDate > div > div.input-group-append > span > svg')
  }

  elementsCbol = {
    in_firstName: () => Selector('#FirstName'),
    in_lastName: () => Selector('#LastName'),
    in_email: () => Selector('#EMail'),
    in_password: () => Selector('#PasswordJ'),
    sel_country: () => Selector('#Country'),
    in_zip: () => Selector('#Zip'),
    in_phone: () => Selector('#HomePhone'),
    in_birthDate: () => Selector('#BirthDate'),
    btn_createAccount_enabled: () => Selector('#btnsubmit'),

    img_brand: () => Selector('body > div.template__main > a'),
    lbl_title: () => Selector('div.card__header > h1').withText('Let\'s Create Your Account!'),
    sel_codePhone: () => Selector('div.iti.iti--allow-dropdown.iti--separate-dial-code > div'),
    btn_createAccount_disabled: () => Selector('#btnsubmit').withAttribute('disabled', 'disabled'),

    err_firstName: () => Selector('#input-FirstName > div > div.invalid-feedback').withText('Please enter your first name'),
    err_lastName: () => Selector('#input-LastName > div > div.invalid-feedback').withText('Please enter your last name'),
    err_email: () => Selector('#input-EMail > div > div.invalid-feedback > span:nth-child(4)').withText('Please enter your email'),
    err_email_invalid: () => Selector('#input-EMail > div > div.invalid-feedback > span:nth-child(4)').withText('Please enter a valid email'),
    err_password: () => Selector('div.password__footer__error').withText('Please enter a valid password'),
    err_zip: () => Selector('#input-Zip > div > div.invalid-feedback > div > span').withText('Please enter a valid zip / postal code'),
    err_phone: () => Selector('div.form-group--phone__error-msg').withText('Please enter a valid phone number'),
    err_birth: () => Selector('#input-BirthDate > div > div.invalid-feedback > span > span').withText('Please enter your date of birth'),
    err_birthYoung: () => Selector('#input-BirthDate > div > div.invalid-feedback > span > span').withText('You must be at least 18 years of age to create an account'),
    
    checkOk_firstName: () => Selector('#input-LastName > div > div.input-group-append > span > svg'),
    checkOk_lastName: () => Selector('#input-LastName > div > div.input-group-append > span > svg'),
    checkOk_email: () => Selector('#input-EMail > div > div.input-group-append > span > svg'),
    checkOk_password: () => Selector('#input-PasswordJ > div > div.input-group-append > span > svg'),
    checkOk_zip: () => Selector('#input-Zip > div > div.input-group-append > span > svg'),
    checkOk_birth: () => Selector('#input-BirthDate > div > div.input-group-append > span > svg')
  }

  elementsWc = {
    in_username: () => Selector('#username'),
    in_password: () => Selector('#password'),
    btn_login: () => Selector('#send-login'),

    btn_forgot: () => Selector('#login-send a').withText('Forget Login Information ?'),
    btn_register: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_dontHaveAccount: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_login: () => Selector('#login-send span').withText('Log In'),
    lbl_signIn: () => Selector('#main-page-content div').withText('SIGN IN TO YOUR ACCOUNT').nth(3),


    img_brand: () => Selector('body > div.template__main > a'),
    lbl_title: () => Selector('div.card__header > h1').withText('Let\'s Create Your Account!'),
    in_firstName: () => Selector('#FirstName'),
    in_lastName: () => Selector('#LastName'),
    in_email: () => Selector('#EMail'),
    sel_country: () => Selector('#Country'),
    in_zip: () => Selector('#Zip'),
    sel_codePhone: () => Selector('div.iti.iti--allow-dropdown.iti--separate-dial-code > div'),
    in_phone: () => Selector('#HomePhone'),
    in_birthDate: () => Selector('#BirthDate'),
    btn_createAccount_disabled: () => Selector('#btnsubmit').withAttribute('disabled', 'disabled'),
    btn_createAccount_enabled: () => Selector('#btnsubmit').withAttribute('disabled', 'enabled'),

    err_firstName: () => Selector('#input-FirstName > div > div.invalid-feedback').withText('Please enter your first name'),
    err_lastName: () => Selector('#input-LastName > div > div.invalid-feedback').withText('Please enter your last name'),
    err_email: () => Selector('#input-EMail > div > div.invalid-feedback > span:nth-child(4)').withText('Please enter your email'),
    err_email_invalid: () => Selector('#input-EMail > div > div.invalid-feedback > span:nth-child(4)').withText('Please enter a valid email'),
    err_password: () => Selector('div.password__footer__error').withText('Please enter a valid password'),
    err_zip: () => Selector('#input-Zip > div > div.invalid-feedback > div > span').withText('Please enter a valid zip / postal code'),
    err_phone: () => Selector('div.form-group--phone__error-msg').withText('Please enter a valid phone number'),
    err_birth: () => Selector('#input-BirthDate > div > div.invalid-feedback > span > span').withText('Please enter your date of birth'),
    err_birthYoung: () => Selector('#input-BirthDate > div > div.invalid-feedback > span > span').withText('You must be at least 18 years of age to create an account'),
    
    checkOk_firstName: () => Selector('#input-LastName > div > div.input-group-append > span > svg'),
    checkOk_lastName: () => Selector('#input-LastName > div > div.input-group-append > span > svg'),
    checkOk_email: () => Selector('#input-EMail > div > div.input-group-append > span > svg'),
    checkOk_password: () => Selector('#input-PasswordJ > div > div.input-group-append > span > svg'),
    checkOk_zip: () => Selector('#input-Zip > div > div.input-group-append > span > svg'),
    checkOk_birth: () => Selector('#input-BirthDate > div > div.input-group-append > span > svg')
  }

  elementsLv = {
    in_username: () => Selector('#username'),
    in_password: () => Selector('#password'),
    btn_login: () => Selector('#send-login'),

    btn_forgot: () => Selector('#login-send a').withText('Forget Login Information ?'),
    btn_register: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_dontHaveAccount: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_login: () => Selector('#login-send span').withText('Log In'),
    lbl_signIn: () => Selector('#main-page-content div').withText('SIGN IN TO YOUR ACCOUNT').nth(3),

    img_brand: () => Selector('body > div.template__main > a'),
    lbl_title: () => Selector('div.card__header > h1').withText('Let\'s Create Your Account!'),
    in_firstName: () => Selector('#FirstName'),
    in_lastName: () => Selector('#LastName'),
    in_email: () => Selector('#EMail'),
    sel_country: () => Selector('#Country'),
    in_zip: () => Selector('#Zip'),
    sel_codePhone: () => Selector('div.iti.iti--allow-dropdown.iti--separate-dial-code > div'),
    in_phone: () => Selector('#HomePhone'),
    in_birthDate: () => Selector('#BirthDate'),
    btn_createAccount_disabled: () => Selector('#btnsubmit').withAttribute('disabled', 'disabled'),
    btn_createAccount_enabled: () => Selector('#btnsubmit').withAttribute('disabled', 'enabled'),

    err_firstName: () => Selector('#input-FirstName > div > div.invalid-feedback').withText('Please enter your first name'),
    err_lastName: () => Selector('#input-LastName > div > div.invalid-feedback').withText('Please enter your last name'),
    err_email: () => Selector('#input-EMail > div > div.invalid-feedback > span:nth-child(4)').withText('Please enter your email'),
    err_email_invalid: () => Selector('#input-EMail > div > div.invalid-feedback > span:nth-child(4)').withText('Please enter a valid email'),
    err_password: () => Selector('div.password__footer__error').withText('Please enter a valid password'),
    err_zip: () => Selector('#input-Zip > div > div.invalid-feedback > div > span').withText('Please enter a valid zip / postal code'),
    err_phone: () => Selector('div.form-group--phone__error-msg').withText('Please enter a valid phone number'),
    err_birth: () => Selector('#input-BirthDate > div > div.invalid-feedback > span > span').withText('Please enter your date of birth'),
    err_birthYoung: () => Selector('#input-BirthDate > div > div.invalid-feedback > span > span').withText('You must be at least 18 years of age to create an account'),
    
    checkOk_firstName: () => Selector('#input-LastName > div > div.input-group-append > span > svg'),
    checkOk_lastName: () => Selector('#input-LastName > div > div.input-group-append > span > svg'),
    checkOk_email: () => Selector('#input-EMail > div > div.input-group-append > span > svg'),
    checkOk_password: () => Selector('#input-PasswordJ > div > div.input-group-append > span > svg'),
    checkOk_zip: () => Selector('#input-Zip > div > div.input-group-append > span > svg'),
    checkOk_birth: () => Selector('#input-BirthDate > div > div.input-group-append > span > svg')
  }

  elementsCsb = {

    in_username: () => Selector('#username'),
    in_password: () => Selector('#password'),
    btn_login: () => Selector('#send-login'),

    btn_forgot: () => Selector('#login-send a').withText('Forget Login Information ?'),
    btn_register: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_dontHaveAccount: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_login: () => Selector('#login-send span').withText('Log In'),
    lbl_signIn: () => Selector('#main-page-content div').withText('SIGN IN TO YOUR ACCOUNT').nth(3),


    img_brand: () => Selector('body > div.template__main > a'),
    lbl_title: () => Selector('div.card__header > h1').withText('Let\'s Create Your Account!'),
    in_firstName: () => Selector('#FirstName'),
    in_lastName: () => Selector('#LastName'),
    in_email: () => Selector('#EMail'),
    sel_country: () => Selector('#Country'),
    in_zip: () => Selector('#Zip'),
    sel_codePhone: () => Selector('div.iti.iti--allow-dropdown.iti--separate-dial-code > div'),
    in_phone: () => Selector('#HomePhone'),
    in_birthDate: () => Selector('#BirthDate'),
    btn_createAccount_disabled: () => Selector('#btnsubmit').withAttribute('disabled', 'disabled'),
    btn_createAccount_enabled: () => Selector('#btnsubmit').withAttribute('disabled', 'enabled'),

    err_firstName: () => Selector('#input-FirstName > div > div.invalid-feedback').withText('Please enter your first name'),
    err_lastName: () => Selector('#input-LastName > div > div.invalid-feedback').withText('Please enter your last name'),
    err_email: () => Selector('#input-EMail > div > div.invalid-feedback > span:nth-child(4)').withText('Please enter your email'),
    err_email_invalid: () => Selector('#input-EMail > div > div.invalid-feedback > span:nth-child(4)').withText('Please enter a valid email'),
    err_password: () => Selector('div.password__footer__error').withText('Please enter a valid password'),
    err_zip: () => Selector('#input-Zip > div > div.invalid-feedback > div > span').withText('Please enter a valid zip / postal code'),
    err_phone: () => Selector('div.form-group--phone__error-msg').withText('Please enter a valid phone number'),
    err_birth: () => Selector('#input-BirthDate > div > div.invalid-feedback > span > span').withText('Please enter your date of birth'),
    err_birthYoung: () => Selector('#input-BirthDate > div > div.invalid-feedback > span > span').withText('You must be at least 18 years of age to create an account'),
    
    checkOk_firstName: () => Selector('#input-LastName > div > div.input-group-append > span > svg'),
    checkOk_lastName: () => Selector('#input-LastName > div > div.input-group-append > span > svg'),
    checkOk_email: () => Selector('#input-EMail > div > div.input-group-append > span > svg'),
    checkOk_password: () => Selector('#input-PasswordJ > div > div.input-group-append > span > svg'),
    checkOk_zip: () => Selector('#input-Zip > div > div.input-group-append > span > svg'),
    checkOk_birth: () => Selector('#input-BirthDate > div > div.input-group-append > span > svg')
  }
}

export const joinPageObject = new JoinPageObjects()