"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.forgotPageObjects = void 0;
const testcafe_1 = require("testcafe");
let elementsTg;
let elementsBol;
let elementsWc;
let elementsLv;
class ForgotPageObjects {
    constructor() {
        this.elementsTg = {
            img_tiggerGamming: () => (0, testcafe_1.Selector)('#header-image img'),
            lbl_resetPassword: () => (0, testcafe_1.Selector)('#forgotPasswordForm h2').withText('RESET PASSWORD'),
            lbl_instructions: () => (0, testcafe_1.Selector)('#paragraph_content'),
            in_username: () => (0, testcafe_1.Selector)('#username'),
            btn_proceed: () => (0, testcafe_1.Selector)('#tgbtnResetPwd span').withText('Proceed'),
            lbl_needHelp: () => (0, testcafe_1.Selector)('#forgotPasswordForm div').withText('Need Help? Contact Us'),
            //Errors
            lbl_attempts: () => (0, testcafe_1.Selector)('#forgot_passwd_attempts'),
            lbl_errorDetails: () => (0, testcafe_1.Selector)('#forgotpassworderrormessage'),
            //exceeded attempts page
            lbl_passwordHelp: () => (0, testcafe_1.Selector)('#forgotPassword h2').withText('Password Help'),
            lbl_exceeded: () => (0, testcafe_1.Selector)('#forgotPassword p').withText('You Have exceeded the maximum number of allowed at'),
            lbl_havingDifficulties: () => (0, testcafe_1.Selector)('#forgotPassword p').withText('If you continue having difficulties, please Contac'),
            btn_contactUs: () => (0, testcafe_1.Selector)('#forgot_exceeded_links a').withText('Contact Us'),
            btn_forgot: () => (0, testcafe_1.Selector)('#forgot_exceeded_links a').withText('Forgot Password?'),
            //forgot password page
            lbl_titleResetPassword: () => (0, testcafe_1.Selector)('#forgotPasswordForm h2').withText('RESET PASSWORD'),
            lbl_linkMail: () => (0, testcafe_1.Selector)('#forgotpasswordmessage'),
            btn_contactUsOk: () => (0, testcafe_1.Selector)('#forgotPasswordForm a').withText('Contact Us')
        };
        this.elementsCbol = {
            img_tiggerGamming: () => (0, testcafe_1.Selector)('#header-image img'),
            lbl_resetPassword: () => (0, testcafe_1.Selector)('#forgotPasswordForm h2').withText('RESET PASSWORD'),
            lbl_instructions: () => (0, testcafe_1.Selector)('#paragraph_content'),
            in_username: () => (0, testcafe_1.Selector)('#username'),
            btn_proceed: () => (0, testcafe_1.Selector)('#tgbtnResetPwd span').withText('Proceed'),
            lbl_needHelp: () => (0, testcafe_1.Selector)('#forgotPasswordForm div').withText('Need Help? Contact Us'),
            //Errors
            lbl_attempts: () => (0, testcafe_1.Selector)('#forgot_passwd_attempts'),
            lbl_errorDetails: () => (0, testcafe_1.Selector)('#forgotpassworderrormessage'),
            //exceeded attempts page
            lbl_passwordHelp: () => (0, testcafe_1.Selector)('#forgotPassword h2').withText('Password Help'),
            lbl_exceeded: () => (0, testcafe_1.Selector)('#forgotPassword p').withText('You Have exceeded the maximum number of allowed at'),
            lbl_havingDifficulties: () => (0, testcafe_1.Selector)('#forgotPassword p').withText('If you continue having difficulties, please Contac'),
            btn_contactUs: () => (0, testcafe_1.Selector)('#forgot_exceeded_links a').withText('Contact Us'),
            btn_forgot: () => (0, testcafe_1.Selector)('#forgot_exceeded_links a').withText('Forgot Password?'),
            //forgot password page
            lbl_titleResetPassword: () => (0, testcafe_1.Selector)('#forgotPasswordForm h2').withText('RESET PASSWORD'),
            lbl_linkMail: () => (0, testcafe_1.Selector)('#forgotpasswordmessage'),
            btn_contactUsOk: () => (0, testcafe_1.Selector)('#forgotPasswordForm a').withText('Contact Us')
        };
        this.elementsWc = {
            img_tiggerGamming: () => (0, testcafe_1.Selector)('#header-image img'),
            lbl_resetPassword: () => (0, testcafe_1.Selector)('#forgotPasswordForm h2').withText('RESET PASSWORD'),
            lbl_instructions: () => (0, testcafe_1.Selector)('#paragraph_content'),
            in_username: () => (0, testcafe_1.Selector)('#username'),
            btn_proceed: () => (0, testcafe_1.Selector)('#tgbtnResetPwd span').withText('Proceed'),
            lbl_needHelp: () => (0, testcafe_1.Selector)('#forgotPasswordForm div').withText('Need Help? Contact Us'),
            //Errors
            lbl_attempts: () => (0, testcafe_1.Selector)('#forgot_passwd_attempts'),
            lbl_errorDetails: () => (0, testcafe_1.Selector)('#forgotpassworderrormessage'),
            //exceeded attempts page
            lbl_passwordHelp: () => (0, testcafe_1.Selector)('#forgotPassword h2').withText('Password Help'),
            lbl_exceeded: () => (0, testcafe_1.Selector)('#forgotPassword p').withText('You Have exceeded the maximum number of allowed at'),
            lbl_havingDifficulties: () => (0, testcafe_1.Selector)('#forgotPassword p').withText('If you continue having difficulties, please Contac'),
            btn_contactUs: () => (0, testcafe_1.Selector)('#forgot_exceeded_links a').withText('Contact Us'),
            btn_forgot: () => (0, testcafe_1.Selector)('#forgot_exceeded_links a').withText('Forgot Password?'),
            //forgot password page
            lbl_titleResetPassword: () => (0, testcafe_1.Selector)('#forgotPasswordForm h2').withText('RESET PASSWORD'),
            lbl_linkMail: () => (0, testcafe_1.Selector)('#forgotpasswordmessage'),
            btn_contactUsOk: () => (0, testcafe_1.Selector)('#forgotPasswordForm a').withText('Contact Us')
        };
        this.elementsLv = {
            img_tiggerGamming: () => (0, testcafe_1.Selector)('#header-image img'),
            lbl_resetPassword: () => (0, testcafe_1.Selector)('#forgotPasswordForm h2').withText('RESET PASSWORD'),
            lbl_instructions: () => (0, testcafe_1.Selector)('#paragraph_content'),
            in_username: () => (0, testcafe_1.Selector)('#username'),
            btn_proceed: () => (0, testcafe_1.Selector)('#tgbtnResetPwd span').withText('Proceed'),
            lbl_needHelp: () => (0, testcafe_1.Selector)('#forgotPasswordForm div').withText('Need Help? Contact Us'),
            //Errors
            lbl_attempts: () => (0, testcafe_1.Selector)('#forgot_passwd_attempts'),
            lbl_errorDetails: () => (0, testcafe_1.Selector)('#forgotpassworderrormessage'),
            //exceeded attempts page
            lbl_passwordHelp: () => (0, testcafe_1.Selector)('#forgotPassword h2').withText('Password Help'),
            lbl_exceeded: () => (0, testcafe_1.Selector)('#forgotPassword p').withText('You Have exceeded the maximum number of allowed at'),
            lbl_havingDifficulties: () => (0, testcafe_1.Selector)('#forgotPassword p').withText('If you continue having difficulties, please Contac'),
            btn_contactUs: () => (0, testcafe_1.Selector)('#forgot_exceeded_links a').withText('Contact Us'),
            btn_forgot: () => (0, testcafe_1.Selector)('#forgot_exceeded_links a').withText('Forgot Password?'),
            //forgot password page
            lbl_titleResetPassword: () => (0, testcafe_1.Selector)('#forgotPasswordForm h2').withText('RESET PASSWORD'),
            lbl_linkMail: () => (0, testcafe_1.Selector)('#forgotpasswordmessage'),
            btn_contactUsOk: () => (0, testcafe_1.Selector)('#forgotPasswordForm a').withText('Contact Us')
        };
        this.elementsCsb = {
            img_tiggerGamming: () => (0, testcafe_1.Selector)('#header-image img'),
            lbl_resetPassword: () => (0, testcafe_1.Selector)('#forgotPasswordForm h2').withText('RESET PASSWORD'),
            lbl_instructions: () => (0, testcafe_1.Selector)('#paragraph_content'),
            in_username: () => (0, testcafe_1.Selector)('#username'),
            btn_proceed: () => (0, testcafe_1.Selector)('#tgbtnResetPwd span').withText('Proceed'),
            lbl_needHelp: () => (0, testcafe_1.Selector)('#forgotPasswordForm div').withText('Need Help? Contact Us'),
            //Errors
            lbl_attempts: () => (0, testcafe_1.Selector)('#forgot_passwd_attempts'),
            lbl_errorDetails: () => (0, testcafe_1.Selector)('#forgotpassworderrormessage'),
            //exceeded attempts page
            lbl_passwordHelp: () => (0, testcafe_1.Selector)('#forgotPassword h2').withText('Password Help'),
            lbl_exceeded: () => (0, testcafe_1.Selector)('#forgotPassword p').withText('You Have exceeded the maximum number of allowed at'),
            lbl_havingDifficulties: () => (0, testcafe_1.Selector)('#forgotPassword p').withText('If you continue having difficulties, please Contac'),
            btn_contactUs: () => (0, testcafe_1.Selector)('#forgot_exceeded_links a').withText('Contact Us'),
            btn_forgot: () => (0, testcafe_1.Selector)('#forgot_exceeded_links a').withText('Forgot Password?'),
            //forgot password page
            lbl_titleResetPassword: () => (0, testcafe_1.Selector)('#forgotPasswordForm h2').withText('RESET PASSWORD'),
            lbl_linkMail: () => (0, testcafe_1.Selector)('#forgotpasswordmessage'),
            btn_contactUsOk: () => (0, testcafe_1.Selector)('#forgotPasswordForm a').withText('Contact Us')
        };
    }
}
exports.forgotPageObjects = new ForgotPageObjects();
