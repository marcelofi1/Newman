"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.changePassPageObjects = void 0;
const testcafe_1 = require("testcafe");
let elementsTg;
let elementsBol;
let elementsWc;
let elementsLv;
class ChangePassObjects {
    constructor() {
        this.elementsTg = {
            img_tiggerGamming: () => (0, testcafe_1.Selector)('#header-image img'),
            lbl_changePassword: () => (0, testcafe_1.Selector)('#changePasswordForm h1').withText('CHANGE PASSWORD'),
            lbl_instructions: () => (0, testcafe_1.Selector)('#changePasswordForm label').withText('Your password must be between 8 and 60 characters'),
            in_newPassord: () => (0, testcafe_1.Selector)('#password1'),
            in_reEnterPass: () => (0, testcafe_1.Selector)('#password2'),
            btn_proceed: () => (0, testcafe_1.Selector)('#btnChangePassword'),
            //Errors
            lbl_invalid: () => (0, testcafe_1.Selector)('#change_passwd div').withText('Enter a valid password'),
            lbl_notMatchPasswords: () => (0, testcafe_1.Selector)('#change_passwd div').withText('Make sure your passwords match!'),
            lbl_oldPassword: () => (0, testcafe_1.Selector)('#change_passwd div').withText('You can\'t reuse an old password, please select a'),
            //ValidationOK
            lbl_userIdLogin: () => (0, testcafe_1.Selector)('#userIdent_tg')
        };
        this.elementsCbol = {
            img_tiggerGamming: () => (0, testcafe_1.Selector)('#header-image img'),
            lbl_changePassword: () => (0, testcafe_1.Selector)('#changePasswordForm h1').withText('CHANGE PASSWORD'),
            lbl_instructions: () => (0, testcafe_1.Selector)('#changePasswordForm label').withText('Your password must be between 8 and 60 characters'),
            in_newPassord: () => (0, testcafe_1.Selector)('#password1'),
            in_reEnterPass: () => (0, testcafe_1.Selector)('#password2'),
            btn_proceed: () => (0, testcafe_1.Selector)('#btnChangePassword'),
            //Errors
            lbl_invalid: () => (0, testcafe_1.Selector)('#change_passwd div').withText('Enter a valid password'),
            lbl_notMatchPasswords: () => (0, testcafe_1.Selector)('#change_passwd div').withText('Make sure your passwords match!'),
            lbl_oldPassword: () => (0, testcafe_1.Selector)('#change_passwd div').withText('You can\'t reuse an old password, please select a'),
            //ValidationOK
            lbl_userIdLogin: () => (0, testcafe_1.Selector)('#userIdent_tg')
        };
        this.elementsWc = {
            img_tiggerGamming: () => (0, testcafe_1.Selector)('#header-image img'),
            lbl_changePassword: () => (0, testcafe_1.Selector)('#changePasswordForm h1').withText('CHANGE PASSWORD'),
            lbl_instructions: () => (0, testcafe_1.Selector)('#changePasswordForm label').withText('Your password must be between 8 and 60 characters'),
            in_newPassord: () => (0, testcafe_1.Selector)('#password1'),
            in_reEnterPass: () => (0, testcafe_1.Selector)('#password2'),
            btn_proceed: () => (0, testcafe_1.Selector)('#btnChangePassword'),
            //Errors
            lbl_invalid: () => (0, testcafe_1.Selector)('#change_passwd div').withText('Enter a valid password'),
            lbl_notMatchPasswords: () => (0, testcafe_1.Selector)('#change_passwd div').withText('Make sure your passwords match!'),
            lbl_oldPassword: () => (0, testcafe_1.Selector)('#change_passwd div').withText('You can\'t reuse an old password, please select a'),
            //ValidationOK
            lbl_userIdLogin: () => (0, testcafe_1.Selector)('#userIdent_tg')
        };
        this.elementsLv = {
            img_tiggerGamming: () => (0, testcafe_1.Selector)('#header-image img'),
            lbl_changePassword: () => (0, testcafe_1.Selector)('#changePasswordForm h1').withText('CHANGE PASSWORD'),
            lbl_instructions: () => (0, testcafe_1.Selector)('#changePasswordForm label').withText('Your password must be between 8 and 60 characters'),
            in_newPassord: () => (0, testcafe_1.Selector)('#password1'),
            in_reEnterPass: () => (0, testcafe_1.Selector)('#password2'),
            btn_proceed: () => (0, testcafe_1.Selector)('#btnChangePassword'),
            //Errors
            lbl_invalid: () => (0, testcafe_1.Selector)('#change_passwd div').withText('Enter a valid password'),
            lbl_notMatchPasswords: () => (0, testcafe_1.Selector)('#change_passwd div').withText('Make sure your passwords match!'),
            lbl_oldPassword: () => (0, testcafe_1.Selector)('#change_passwd div').withText('You can\'t reuse an old password, please select a'),
            //ValidationOK
            lbl_userIdLogin: () => (0, testcafe_1.Selector)('#userIdent_tg')
        };
        this.elementsCsb = {
            img_tiggerGamming: () => (0, testcafe_1.Selector)('#header-image img'),
            lbl_changePassword: () => (0, testcafe_1.Selector)('#changePasswordForm h1').withText('CHANGE PASSWORD'),
            lbl_instructions: () => (0, testcafe_1.Selector)('#changePasswordForm label').withText('Your password must be between 8 and 60 characters'),
            in_newPassord: () => (0, testcafe_1.Selector)('#password1'),
            in_reEnterPass: () => (0, testcafe_1.Selector)('#password2'),
            btn_proceed: () => (0, testcafe_1.Selector)('#btnChangePassword'),
            //Errors
            lbl_invalid: () => (0, testcafe_1.Selector)('#change_passwd div').withText('Enter a valid password'),
            lbl_notMatchPasswords: () => (0, testcafe_1.Selector)('#change_passwd div').withText('Make sure your passwords match!'),
            lbl_oldPassword: () => (0, testcafe_1.Selector)('#change_passwd div').withText('You can\'t reuse an old password, please select a'),
            //ValidationOK
            lbl_userIdLogin: () => (0, testcafe_1.Selector)('#userIdent_tg')
        };
    }
}
exports.changePassPageObjects = new ChangePassObjects();
