"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loginPageObject = void 0;
const testcafe_1 = require("testcafe");
class LoginPageObjects {
    constructor() {
        this.elementsTg = {
            in_username: () => (0, testcafe_1.Selector)('#username'),
            in_password: () => (0, testcafe_1.Selector)('#password'),
            btn_login: () => (0, testcafe_1.Selector)('#send-login'),
            btn_loginRaf: () => (0, testcafe_1.Selector)('#button-submit'),
            btn_forgot: () => (0, testcafe_1.Selector)('#login-send a').withText('Forget Login Information ?'),
            btn_register: () => (0, testcafe_1.Selector)('#main-page-content a').withText('REGISTER'),
            lbl_dontHaveAccount: () => (0, testcafe_1.Selector)('#main-page-content a').withText('REGISTER'),
            lbl_login: () => (0, testcafe_1.Selector)('#login-send span').withText('Log In'),
            lbl_signIn: () => (0, testcafe_1.Selector)('#main-page-content div').withText('SIGN IN TO YOUR ACCOUNT').nth(3),
        };
        this.elementsCbol = {
            in_username: () => (0, testcafe_1.Selector)('#CustomerID'),
            in_password: () => (0, testcafe_1.Selector)('#Password'),
            btn_login: () => (0, testcafe_1.Selector)('#button-submit-login'),
            btn_loginRaf: () => (0, testcafe_1.Selector)('#button-submit'),
            btn_forgot: () => (0, testcafe_1.Selector)('#RemoveForgot > a'),
            btn_register: () => (0, testcafe_1.Selector)('#join-now-button'),
            lbl_dontHaveAccount: () => (0, testcafe_1.Selector)('#homePage > div.mainColl > div > div.signIn.col_3c.right > div > img'),
            lbl_login: () => (0, testcafe_1.Selector)('#button-submit-login'),
            lbl_signIn: () => (0, testcafe_1.Selector)('#RemoveForgot'),
        };
        this.elementsWc = {
            in_username: () => (0, testcafe_1.Selector)('#username'),
            in_password: () => (0, testcafe_1.Selector)('#password'),
            btn_login: () => (0, testcafe_1.Selector)('#send-login'),
            btn_loginRaf: () => (0, testcafe_1.Selector)('#button-submit'),
            btn_forgot: () => (0, testcafe_1.Selector)('#login-send a').withText('Forget Login Information ?'),
            btn_register: () => (0, testcafe_1.Selector)('#main-page-content a').withText('REGISTER'),
            lbl_dontHaveAccount: () => (0, testcafe_1.Selector)('#main-page-content a').withText('REGISTER'),
            lbl_login: () => (0, testcafe_1.Selector)('#login-send span').withText('Log In'),
            lbl_signIn: () => (0, testcafe_1.Selector)('#main-page-content div').withText('SIGN IN TO YOUR ACCOUNT').nth(3),
        };
        this.elementsLv = {
            in_username: () => (0, testcafe_1.Selector)('#username'),
            in_password: () => (0, testcafe_1.Selector)('#password'),
            btn_login: () => (0, testcafe_1.Selector)('#send-login'),
            btn_loginRaf: () => (0, testcafe_1.Selector)('#button-submit'),
            btn_forgot: () => (0, testcafe_1.Selector)('#login-send a').withText('Forget Login Information ?'),
            btn_register: () => (0, testcafe_1.Selector)('#main-page-content a').withText('REGISTER'),
            lbl_dontHaveAccount: () => (0, testcafe_1.Selector)('#main-page-content a').withText('REGISTER'),
            lbl_login: () => (0, testcafe_1.Selector)('#login-send span').withText('Log In'),
            lbl_signIn: () => (0, testcafe_1.Selector)('#main-page-content div').withText('SIGN IN TO YOUR ACCOUNT').nth(3),
        };
        this.elementsCsb = {
            in_username: () => (0, testcafe_1.Selector)('#CustomerID'),
            in_password: () => (0, testcafe_1.Selector)('#Password'),
            btn_login: () => (0, testcafe_1.Selector)('#button-submit-login'),
            btn_loginRaf: () => (0, testcafe_1.Selector)('#button-submit'),
            btn_forgot: () => (0, testcafe_1.Selector)('#RemoveForgot > a'),
            btn_register: () => (0, testcafe_1.Selector)('#join-now-button'),
            lbl_dontHaveAccount: () => (0, testcafe_1.Selector)('#homePage > div.mainColl > div > div.signIn.col_3c.right > div > img'),
            lbl_login: () => (0, testcafe_1.Selector)('#button-submit-login'),
            lbl_signIn: () => (0, testcafe_1.Selector)('#RemoveForgot'),
        };
    }
}
exports.loginPageObject = new LoginPageObjects();
