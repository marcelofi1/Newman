import { Selector } from 'testcafe';

let elementsTg;
let elementsBol;
let elementsWc;
let elementsLv;

class MMyAccountsPageObjects {
  elementsTg = {

    //Header
    btn_menu: () => Selector('#limenu'),
    img_log: () => Selector('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
    img_badBet: () => Selector('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
    btn_login: () => Selector('#header a').withText('LOG IN'),
    btn_register: () => Selector('#header a').withText('REGISTER'),

    //Menu
    btn_sports: () => Selector('#sports_top_menu span').withText('SPORTS'),
    btn_liveBetting: () => Selector('#livebetting_top_menu span').withText('LIVE BETTING'),
    btn_poker: () => Selector('#poker_top_menu span').withText('POKER'),
    btn_casino: () => Selector('#casino_top_menu span').withText('CASINO'),
    btn_liveCasino: () => Selector('#livedealer_top_menu span').withText('LIVE CASINO'),
    btn_promotions: () => Selector('#promotions_top_menu span').withText('PROMOTIONS'),
    btn_cashier: () => Selector('#bank_top_menu span').withText('CASHIER'),

    //Footer
    lbl_aboutUs: () => Selector('footer div').withText('ABOUT US').nth(3),
    img_safeSecure: () => Selector('footer div').withText('SAFE & SECURE').nth(5),
    lbl_copyRights: () => Selector('footer span').withText('Copyright © 2021 TigerGaming.com All rights reserv'),
    img_gammingTrust: () => Selector('footer div div div').nth(9).find('div div div').nth(1).find('img'),
    btn_rules: () => Selector('footer a').withText('RULES'),
    btn_affiliates: () => Selector('footer a').withText('AFFILIATES'),
    btn_contactUs: () => Selector('footer a').withText('CONTACT US'),
    btn_privacyPolicy: () => Selector('footer a').withText('PRIVACY POLICY'),
    btn_responsibleGaming: () => Selector('footer a').withText('RESPONSIBLE GAMING'),
  }

  elementsCbol = {
    //Header
    img_log: () => Selector('#bet-logo'),
    img_badBet: () => Selector('#switching_container'),//switch new page
    btn_login: () => Selector('#button-submit-login'),
    btn_register: () => Selector('#join-now-button'),

    //Menu
    btn_sports: () => Selector('#navSite > li:nth-child(2) > a').withText('SPORTS'),
    btn_liveBetting: () => Selector('#navSite > li.level3 > a').withText('LIVE BETTING'),
    btn_poker: () => Selector('#navSite > li:nth-child(7) > a').withText('POKER'),
    btn_casino: () => Selector('#navSite > li:nth-child(4) > a').withText('CASINO'),
    btn_liveCasino: () => Selector('#navSite > li:nth-child(5) > div > button').withText('LIVE CASINO'),
    btn_promotions: () => Selector('#navSite > li:nth-child(10) > a').withText('PROMOTIONS'),
    btn_cashier: () => Selector('#navSite > li:nth-child(11) > a').withText('CASHIER'),

    //Footer
    lbl_aboutUs: () => Selector('#doc4 > center > div.footer-sports-optional > div.footerEndContactInfo > p:nth-child(2) > a:nth-child(1)').withText('About Us'),
    img_safeSecure: () => Selector('#doc4 > center > div.footer-sports-optional > div.footerMenuCtn > div.footerMenu.first > h3').withText('SAFE & SECURE'),
    lbl_copyRights: () => Selector('#doc4 > center > div.footer-sports-optional > div.footerEndContactInfo > p.copyright'),
    img_gammingTrust: () => Selector('#doc4 > center > div.footer-sports-optional > div.footerMenuCtn > div.footerMenu.first > p:nth-child(5) > img'),
    btn_rules: () => Selector('#doc4 > center > div.footer-sports-optional > div.footerMenuCtn > div:nth-child(2) > ul:nth-child(4) > li:nth-child(2) > a').withText('Rules'),
    btn_affiliates: () => Selector('#doc4 > center > div.footer-sports-optional > div.footerMenuCtn > div:nth-child(2) > ul:nth-child(2) > li:nth-child(7) > a').withText('Affiliate Program'),
    btn_contactUs: () => Selector('#doc4 > center > div.footer-sports-optional > div.footerEndContactInfo > p:nth-child(2) > a:nth-child(2)').withText('Contact Us'),
    btn_privacyPolicy: () => Selector('#doc4 > center > div.footer-sports-optional > div.footerEndContactInfo > p:nth-child(2) > a:nth-child(4)').withText('Privacy Policy'),
    btn_responsibleGaming: () => Selector('#doc4 > center > div.footer-sports-optional > div.footerEndContactInfo > p:nth-child(2) > a:nth-child(5)').withText('Responsible Gaming'),
  }

  elementsWc = {
    //Header
    img_log: () => Selector('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
    img_badBet: () => Selector('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
    btn_login: () => Selector('#header a').withText('LOG IN'),
    btn_register: () => Selector('#header a').withText('REGISTER'),

    //Menu
    btn_sports: () => Selector('#sports_top_menu span').withText('SPORTS'),
    btn_liveBetting: () => Selector('#livebetting_top_menu span').withText('LIVE BETTING'),
    btn_poker: () => Selector('#poker_top_menu span').withText('POKER'),
    btn_casino: () => Selector('#casino_top_menu span').withText('CASINO'),
    btn_liveCasino: () => Selector('#livedealer_top_menu span').withText('LIVE CASINO'),
    btn_promotions: () => Selector('#promotions_top_menu span').withText('PROMOTIONS'),
    btn_cashier: () => Selector('#bank_top_menu span').withText('CASHIER'),

    //Footer
    lbl_aboutUs: () => Selector('footer div').withText('ABOUT US').nth(3),
    img_safeSecure: () => Selector('footer div').withText('SAFE & SECURE').nth(5),
    lbl_copyRights: () => Selector('footer span').withText('Copyright © 2021 TigerGaming.com All rights reserv'),
    img_gammingTrust: () => Selector('footer div div div').nth(9).find('div div div').nth(1).find('img'),
    btn_rules: () => Selector('footer a').withText('RULES'),
    btn_affiliates: () => Selector('footer a').withText('AFFILIATES'),
    btn_contactUs: () => Selector('footer a').withText('CONTACT US'),
    btn_privacyPolicy: () => Selector('footer a').withText('PRIVACY POLICY'),
    btn_responsibleGaming: () => Selector('footer a').withText('RESPONSIBLE GAMING'),
  }

  elementsLv = {
    //Header
    img_log: () => Selector('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
    img_badBet: () => Selector('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
    btn_login: () => Selector('#header a').withText('LOG IN'),
    btn_register: () => Selector('#header a').withText('REGISTER'),

    //Menu
    btn_sports: () => Selector('#sports_top_menu span').withText('SPORTS'),
    btn_liveBetting: () => Selector('#livebetting_top_menu span').withText('LIVE BETTING'),
    btn_poker: () => Selector('#poker_top_menu span').withText('POKER'),
    btn_casino: () => Selector('#casino_top_menu span').withText('CASINO'),
    btn_liveCasino: () => Selector('#livedealer_top_menu span').withText('LIVE CASINO'),
    btn_promotions: () => Selector('#promotions_top_menu span').withText('PROMOTIONS'),
    btn_cashier: () => Selector('#bank_top_menu span').withText('CASHIER'),

    //Footer
    lbl_aboutUs: () => Selector('footer div').withText('ABOUT US').nth(3),
    img_safeSecure: () => Selector('footer div').withText('SAFE & SECURE').nth(5),
    lbl_copyRights: () => Selector('footer span').withText('Copyright © 2021 TigerGaming.com All rights reserv'),
    img_gammingTrust: () => Selector('footer div div div').nth(9).find('div div div').nth(1).find('img'),
    btn_rules: () => Selector('footer a').withText('RULES'),
    btn_affiliates: () => Selector('footer a').withText('AFFILIATES'),
    btn_contactUs: () => Selector('footer a').withText('CONTACT US'),
    btn_privacyPolicy: () => Selector('footer a').withText('PRIVACY POLICY'),
    btn_responsibleGaming: () => Selector('footer a').withText('RESPONSIBLE GAMING'),
  }

  elementsCsb = {

    //Header
    img_log: () => Selector('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
    img_badBet: () => Selector('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
    btn_login: () => Selector('#header a').withText('LOG IN'),
    btn_register: () => Selector('#header a').withText('REGISTER'),

    //Menu
    btn_sports: () => Selector('#sports_top_menu span').withText('SPORTS'),
    btn_liveBetting: () => Selector('#livebetting_top_menu span').withText('LIVE BETTING'),
    btn_poker: () => Selector('#poker_top_menu span').withText('POKER'),
    btn_casino: () => Selector('#casino_top_menu span').withText('CASINO'),
    btn_liveCasino: () => Selector('#livedealer_top_menu span').withText('LIVE CASINO'),
    btn_promotions: () => Selector('#promotions_top_menu span').withText('PROMOTIONS'),
    btn_cashier: () => Selector('#bank_top_menu span').withText('CASHIER'),

    //Footer
    lbl_aboutUs: () => Selector('footer div').withText('ABOUT US').nth(3),
    img_safeSecure: () => Selector('footer div').withText('SAFE & SECURE').nth(5),
    lbl_copyRights: () => Selector('footer span').withText('Copyright © 2021 TigerGaming.com All rights reserv'),
    img_gammingTrust: () => Selector('footer div div div').nth(9).find('div div div').nth(1).find('img'),
    btn_rules: () => Selector('footer a').withText('RULES'),
    btn_affiliates: () => Selector('footer a').withText('AFFILIATES'),
    btn_contactUs: () => Selector('footer a').withText('CONTACT US'),
    btn_privacyPolicy: () => Selector('footer a').withText('PRIVACY POLICY'),
    btn_responsibleGaming: () => Selector('footer a').withText('RESPONSIBLE GAMING'),
  }
}

export const mmyAccountPageObjects = new MMyAccountsPageObjects()