"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.homePageObject = void 0;
const testcafe_1 = require("testcafe");
let elementsTg;
let elementsBol;
let elementsWc;
let elementsLv;
class HomePageObjects {
    constructor() {
        this.elementsTg = {
            //Header
            img_log: () => (0, testcafe_1.Selector)('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
            img_badBet: () => (0, testcafe_1.Selector)('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
            btn_login: () => (0, testcafe_1.Selector)('#header a').withText('LOG IN'),
            btn_register: () => (0, testcafe_1.Selector)('#header a').withText('REGISTER'),
            //Menu
            btn_sports: () => (0, testcafe_1.Selector)('#sports_top_menu span').withText('SPORTS'),
            btn_liveBetting: () => (0, testcafe_1.Selector)('#livebetting_top_menu span').withText('LIVE BETTING'),
            btn_poker: () => (0, testcafe_1.Selector)('#poker_top_menu span').withText('POKER'),
            btn_casino: () => (0, testcafe_1.Selector)('#casino_top_menu span').withText('CASINO'),
            btn_liveCasino: () => (0, testcafe_1.Selector)('#livedealer_top_menu span').withText('LIVE CASINO'),
            btn_promotions: () => (0, testcafe_1.Selector)('#promotions_top_menu span').withText('PROMOTIONS'),
            btn_cashier: () => (0, testcafe_1.Selector)('#bank_top_menu span').withText('CASHIER'),
            //Footer
            lbl_aboutUs: () => (0, testcafe_1.Selector)('footer div').withText('ABOUT US').nth(3),
            img_safeSecure: () => (0, testcafe_1.Selector)('footer div').withText('SAFE & SECURE').nth(5),
            lbl_copyRights: () => (0, testcafe_1.Selector)('footer span').withText('Copyright © 2021 TigerGaming.com All rights reserv'),
            img_gammingTrust: () => (0, testcafe_1.Selector)('footer div div div').nth(9).find('div div div').nth(1).find('img'),
            btn_rules: () => (0, testcafe_1.Selector)('footer a').withText('RULES'),
            btn_affiliates: () => (0, testcafe_1.Selector)('footer a').withText('AFFILIATES'),
            btn_contactUs: () => (0, testcafe_1.Selector)('footer a').withText('CONTACT US'),
            btn_privacyPolicy: () => (0, testcafe_1.Selector)('footer a').withText('PRIVACY POLICY'),
            btn_responsibleGaming: () => (0, testcafe_1.Selector)('footer a').withText('RESPONSIBLE GAMING'),
        };
        this.elementsCbol = {
            //Header
            img_log: () => (0, testcafe_1.Selector)('#bet-logo'),
            img_badBet: () => (0, testcafe_1.Selector)('#switching_container'),
            btn_login: () => (0, testcafe_1.Selector)('#button-submit-login'),
            btn_register: () => (0, testcafe_1.Selector)('#join-now-button'),
            //Menu
            btn_sports: () => (0, testcafe_1.Selector)('#navSite > li:nth-child(2) > a').withText('SPORTS'),
            btn_liveBetting: () => (0, testcafe_1.Selector)('#navSite > li.level3 > a').withText('LIVE BETTING'),
            btn_poker: () => (0, testcafe_1.Selector)('#navSite > li:nth-child(7) > a').withText('POKER'),
            btn_casino: () => (0, testcafe_1.Selector)('#navSite > li:nth-child(4) > a').withText('CASINO'),
            btn_liveCasino: () => (0, testcafe_1.Selector)('#navSite > li:nth-child(5) > div > button').withText('LIVE CASINO'),
            btn_promotions: () => (0, testcafe_1.Selector)('#navSite > li:nth-child(10) > a').withText('PROMOTIONS'),
            btn_cashier: () => (0, testcafe_1.Selector)('#navSite > li:nth-child(11) > a').withText('CASHIER'),
            //Footer
            lbl_aboutUs: () => (0, testcafe_1.Selector)('#doc4 > center > div.footer-sports-optional > div.footerEndContactInfo > p:nth-child(2) > a:nth-child(1)').withText('About Us'),
            img_safeSecure: () => (0, testcafe_1.Selector)('#doc4 > center > div.footer-sports-optional > div.footerMenuCtn > div.footerMenu.first > h3').withText('SAFE & SECURE'),
            lbl_copyRights: () => (0, testcafe_1.Selector)('#doc4 > center > div.footer-sports-optional > div.footerEndContactInfo > p.copyright'),
            img_gammingTrust: () => (0, testcafe_1.Selector)('#doc4 > center > div.footer-sports-optional > div.footerMenuCtn > div.footerMenu.first > p:nth-child(5) > img'),
            btn_rules: () => (0, testcafe_1.Selector)('#doc4 > center > div.footer-sports-optional > div.footerMenuCtn > div:nth-child(2) > ul:nth-child(4) > li:nth-child(2) > a').withText('Rules'),
            btn_affiliates: () => (0, testcafe_1.Selector)('#doc4 > center > div.footer-sports-optional > div.footerMenuCtn > div:nth-child(2) > ul:nth-child(2) > li:nth-child(7) > a').withText('Affiliate Program'),
            btn_contactUs: () => (0, testcafe_1.Selector)('#doc4 > center > div.footer-sports-optional > div.footerEndContactInfo > p:nth-child(2) > a:nth-child(2)').withText('Contact Us'),
            btn_privacyPolicy: () => (0, testcafe_1.Selector)('#doc4 > center > div.footer-sports-optional > div.footerEndContactInfo > p:nth-child(2) > a:nth-child(4)').withText('Privacy Policy'),
            btn_responsibleGaming: () => (0, testcafe_1.Selector)('#doc4 > center > div.footer-sports-optional > div.footerEndContactInfo > p:nth-child(2) > a:nth-child(5)').withText('Responsible Gaming'),
        };
        this.elementsWc = {
            //Header
            img_log: () => (0, testcafe_1.Selector)('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
            img_badBet: () => (0, testcafe_1.Selector)('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
            btn_login: () => (0, testcafe_1.Selector)('#header a').withText('LOG IN'),
            btn_register: () => (0, testcafe_1.Selector)('#header a').withText('REGISTER'),
            //Menu
            btn_sports: () => (0, testcafe_1.Selector)('#sports_top_menu span').withText('SPORTS'),
            btn_liveBetting: () => (0, testcafe_1.Selector)('#livebetting_top_menu span').withText('LIVE BETTING'),
            btn_poker: () => (0, testcafe_1.Selector)('#poker_top_menu span').withText('POKER'),
            btn_casino: () => (0, testcafe_1.Selector)('#casino_top_menu span').withText('CASINO'),
            btn_liveCasino: () => (0, testcafe_1.Selector)('#livedealer_top_menu span').withText('LIVE CASINO'),
            btn_promotions: () => (0, testcafe_1.Selector)('#promotions_top_menu span').withText('PROMOTIONS'),
            btn_cashier: () => (0, testcafe_1.Selector)('#bank_top_menu span').withText('CASHIER'),
            //Footer
            lbl_aboutUs: () => (0, testcafe_1.Selector)('footer div').withText('ABOUT US').nth(3),
            img_safeSecure: () => (0, testcafe_1.Selector)('footer div').withText('SAFE & SECURE').nth(5),
            lbl_copyRights: () => (0, testcafe_1.Selector)('footer span').withText('Copyright © 2021 TigerGaming.com All rights reserv'),
            img_gammingTrust: () => (0, testcafe_1.Selector)('footer div div div').nth(9).find('div div div').nth(1).find('img'),
            btn_rules: () => (0, testcafe_1.Selector)('footer a').withText('RULES'),
            btn_affiliates: () => (0, testcafe_1.Selector)('footer a').withText('AFFILIATES'),
            btn_contactUs: () => (0, testcafe_1.Selector)('footer a').withText('CONTACT US'),
            btn_privacyPolicy: () => (0, testcafe_1.Selector)('footer a').withText('PRIVACY POLICY'),
            btn_responsibleGaming: () => (0, testcafe_1.Selector)('footer a').withText('RESPONSIBLE GAMING'),
        };
        this.elementsLv = {
            //Header
            img_log: () => (0, testcafe_1.Selector)('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
            img_badBet: () => (0, testcafe_1.Selector)('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
            btn_login: () => (0, testcafe_1.Selector)('#header a').withText('LOG IN'),
            btn_register: () => (0, testcafe_1.Selector)('#header a').withText('REGISTER'),
            //Menu
            btn_sports: () => (0, testcafe_1.Selector)('#sports_top_menu span').withText('SPORTS'),
            btn_liveBetting: () => (0, testcafe_1.Selector)('#livebetting_top_menu span').withText('LIVE BETTING'),
            btn_poker: () => (0, testcafe_1.Selector)('#poker_top_menu span').withText('POKER'),
            btn_casino: () => (0, testcafe_1.Selector)('#casino_top_menu span').withText('CASINO'),
            btn_liveCasino: () => (0, testcafe_1.Selector)('#livedealer_top_menu span').withText('LIVE CASINO'),
            btn_promotions: () => (0, testcafe_1.Selector)('#promotions_top_menu span').withText('PROMOTIONS'),
            btn_cashier: () => (0, testcafe_1.Selector)('#bank_top_menu span').withText('CASHIER'),
            //Footer
            lbl_aboutUs: () => (0, testcafe_1.Selector)('footer div').withText('ABOUT US').nth(3),
            img_safeSecure: () => (0, testcafe_1.Selector)('footer div').withText('SAFE & SECURE').nth(5),
            lbl_copyRights: () => (0, testcafe_1.Selector)('footer span').withText('Copyright © 2021 TigerGaming.com All rights reserv'),
            img_gammingTrust: () => (0, testcafe_1.Selector)('footer div div div').nth(9).find('div div div').nth(1).find('img'),
            btn_rules: () => (0, testcafe_1.Selector)('footer a').withText('RULES'),
            btn_affiliates: () => (0, testcafe_1.Selector)('footer a').withText('AFFILIATES'),
            btn_contactUs: () => (0, testcafe_1.Selector)('footer a').withText('CONTACT US'),
            btn_privacyPolicy: () => (0, testcafe_1.Selector)('footer a').withText('PRIVACY POLICY'),
            btn_responsibleGaming: () => (0, testcafe_1.Selector)('footer a').withText('RESPONSIBLE GAMING'),
        };
        this.elementsCsb = {
            //Header
            img_log: () => (0, testcafe_1.Selector)('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
            img_badBet: () => (0, testcafe_1.Selector)('#header .p-0.col-lg-3.col-sm-4.col-md-4.header-logo'),
            btn_login: () => (0, testcafe_1.Selector)('#header a').withText('LOG IN'),
            btn_register: () => (0, testcafe_1.Selector)('#header a').withText('REGISTER'),
            //Menu
            btn_sports: () => (0, testcafe_1.Selector)('#sports_top_menu span').withText('SPORTS'),
            btn_liveBetting: () => (0, testcafe_1.Selector)('#livebetting_top_menu span').withText('LIVE BETTING'),
            btn_poker: () => (0, testcafe_1.Selector)('#poker_top_menu span').withText('POKER'),
            btn_casino: () => (0, testcafe_1.Selector)('#casino_top_menu span').withText('CASINO'),
            btn_liveCasino: () => (0, testcafe_1.Selector)('#livedealer_top_menu span').withText('LIVE CASINO'),
            btn_promotions: () => (0, testcafe_1.Selector)('#promotions_top_menu span').withText('PROMOTIONS'),
            btn_cashier: () => (0, testcafe_1.Selector)('#bank_top_menu span').withText('CASHIER'),
            //Footer
            lbl_aboutUs: () => (0, testcafe_1.Selector)('footer div').withText('ABOUT US').nth(3),
            img_safeSecure: () => (0, testcafe_1.Selector)('footer div').withText('SAFE & SECURE').nth(5),
            lbl_copyRights: () => (0, testcafe_1.Selector)('footer span').withText('Copyright © 2021 TigerGaming.com All rights reserv'),
            img_gammingTrust: () => (0, testcafe_1.Selector)('footer div div div').nth(9).find('div div div').nth(1).find('img'),
            btn_rules: () => (0, testcafe_1.Selector)('footer a').withText('RULES'),
            btn_affiliates: () => (0, testcafe_1.Selector)('footer a').withText('AFFILIATES'),
            btn_contactUs: () => (0, testcafe_1.Selector)('footer a').withText('CONTACT US'),
            btn_privacyPolicy: () => (0, testcafe_1.Selector)('footer a').withText('PRIVACY POLICY'),
            btn_responsibleGaming: () => (0, testcafe_1.Selector)('footer a').withText('RESPONSIBLE GAMING'),
        };
    }
}
exports.homePageObject = new HomePageObjects();
