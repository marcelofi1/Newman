import { Selector } from 'testcafe';

let elementsTg;
let elementsBol;
let elementsWc;
let elementsLv;

class ChangePassObjects {
  elementsTg = {

      img_tiggerGamming: () => Selector('#header-image img'),
      lbl_changePassword: () => Selector('#changePasswordForm h1').withText('CHANGE PASSWORD'),
      lbl_instructions: () => Selector('#changePasswordForm label').withText('Your password must be between 8 and 60 characters'),
      in_newPassord: () => Selector('#password1'),
      in_reEnterPass: () => Selector('#password2'),
      btn_proceed: () => Selector('#btnChangePassword'),

      //Errors
      lbl_invalid: () => Selector('#change_passwd div').withText('Enter a valid password'),
      lbl_notMatchPasswords: () => Selector('#change_passwd div').withText('Make sure your passwords match!'),
      lbl_oldPassword: () => Selector('#change_passwd div').withText('You can\'t reuse an old password, please select a'),

      //ValidationOK
      lbl_userIdLogin:() => Selector('#userIdent_tg')
  }

  elementsCbol = {
    img_tiggerGamming: () => Selector('#header-image img'),
    lbl_changePassword: () => Selector('#changePasswordForm h1').withText('CHANGE PASSWORD'),
    lbl_instructions: () => Selector('#changePasswordForm label').withText('Your password must be between 8 and 60 characters'),
    in_newPassord: () => Selector('#password1'),
    in_reEnterPass: () => Selector('#password2'),
    btn_proceed: () => Selector('#btnChangePassword'),

    //Errors
    lbl_invalid: () => Selector('#change_passwd div').withText('Enter a valid password'),
    lbl_notMatchPasswords: () => Selector('#change_passwd div').withText('Make sure your passwords match!'),
    lbl_oldPassword: () => Selector('#change_passwd div').withText('You can\'t reuse an old password, please select a'),

    //ValidationOK
    lbl_userIdLogin:() => Selector('#userIdent_tg')
  }

  elementsWc = {
    img_tiggerGamming: () => Selector('#header-image img'),
    lbl_changePassword: () => Selector('#changePasswordForm h1').withText('CHANGE PASSWORD'),
    lbl_instructions: () => Selector('#changePasswordForm label').withText('Your password must be between 8 and 60 characters'),
    in_newPassord: () => Selector('#password1'),
    in_reEnterPass: () => Selector('#password2'),
    btn_proceed: () => Selector('#btnChangePassword'),

    //Errors
    lbl_invalid: () => Selector('#change_passwd div').withText('Enter a valid password'),
    lbl_notMatchPasswords: () => Selector('#change_passwd div').withText('Make sure your passwords match!'),
    lbl_oldPassword: () => Selector('#change_passwd div').withText('You can\'t reuse an old password, please select a'),

    //ValidationOK
    lbl_userIdLogin:() => Selector('#userIdent_tg')
  }

  elementsLv = {
    img_tiggerGamming: () => Selector('#header-image img'),
    lbl_changePassword: () => Selector('#changePasswordForm h1').withText('CHANGE PASSWORD'),
    lbl_instructions: () => Selector('#changePasswordForm label').withText('Your password must be between 8 and 60 characters'),
    in_newPassord: () => Selector('#password1'),
    in_reEnterPass: () => Selector('#password2'),
    btn_proceed: () => Selector('#btnChangePassword'),

    //Errors
    lbl_invalid: () => Selector('#change_passwd div').withText('Enter a valid password'),
    lbl_notMatchPasswords: () => Selector('#change_passwd div').withText('Make sure your passwords match!'),
    lbl_oldPassword: () => Selector('#change_passwd div').withText('You can\'t reuse an old password, please select a'),

    //ValidationOK
    lbl_userIdLogin:() => Selector('#userIdent_tg')
  }

  elementsCsb = {

    img_tiggerGamming: () => Selector('#header-image img'),
    lbl_changePassword: () => Selector('#changePasswordForm h1').withText('CHANGE PASSWORD'),
    lbl_instructions: () => Selector('#changePasswordForm label').withText('Your password must be between 8 and 60 characters'),
    in_newPassord: () => Selector('#password1'),
    in_reEnterPass: () => Selector('#password2'),
    btn_proceed: () => Selector('#btnChangePassword'),

    //Errors
    lbl_invalid: () => Selector('#change_passwd div').withText('Enter a valid password'),
    lbl_notMatchPasswords: () => Selector('#change_passwd div').withText('Make sure your passwords match!'),
    lbl_oldPassword: () => Selector('#change_passwd div').withText('You can\'t reuse an old password, please select a'),

    //ValidationOK
    lbl_userIdLogin:() => Selector('#userIdent_tg')
  }
}

export const changePassPageObjects = new ChangePassObjects()