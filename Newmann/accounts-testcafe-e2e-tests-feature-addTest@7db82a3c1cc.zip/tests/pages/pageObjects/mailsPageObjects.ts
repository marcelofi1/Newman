import { Selector } from 'testcafe';

class MailsPageObjects {
  elementsTg = {
    //Yopmail Page
    in_mailYop: () => Selector('#login'),
    btn_mail: () => Selector('#refreshbut > button'),
    iframe_Mail: () => Selector('#ifmail'),
    link_Raf: () => Selector('#mail > div > table > tbody > tr > td > div:nth-child(3) > div > div > div > div > div > div > div > p:nth-child(5) > span:nth-child(3) > span > a'),
  }

  elementsCbol = {
    //Yopmail Page
    in_mailYop: () => Selector('#login'),
    btn_mail: () => Selector('#refreshbut > button'),
    iframe_Mail: () => Selector('#ifmail'),
    link_Raf: () => Selector('#mail > div > table > tbody > tr > td > div:nth-child(3) > div > div > div > div > div > div > div > p:nth-child(5) > span:nth-child(3) > span > a'),
  }

  elementsWc = {
    //Yopmail Page
    in_mailYop: () => Selector('#login'),
    btn_mail: () => Selector('#refreshbut > button'),
    iframe_Mail: () => Selector('#ifmail'),
    link_Raf: () => Selector('#mail > div > table > tbody > tr > td > div:nth-child(3) > div > div > div > div > div > div > div > p:nth-child(5) > span:nth-child(3) > span > a'),
  }

  elementsLv = {
    //Yopmail Page
    in_mailYop: () => Selector('#login'),
    btn_mail: () => Selector('#refreshbut > button'),
    iframe_Mail: () => Selector('#ifmail'),
    link_Raf: () => Selector('#mail > div > table > tbody > tr > td > div:nth-child(3) > div > div > div > div > div > div > div > p:nth-child(5) > span:nth-child(3) > span > a'),
  }

  elementsCsb = {
    //Yopmail Page
    in_mailYop: () => Selector('#login'),
    btn_mail: () => Selector('#refreshbut > button'),
    iframe_Mail: () => Selector('#ifmail'),
    link_Raf: () => Selector('#mail > div > table > tbody > tr > td > div:nth-child(3) > div > div > div > div > div > div > div > p:nth-child(5) > span:nth-child(3) > span > a'),
  }
}

export const mailsPageObject = new MailsPageObjects()