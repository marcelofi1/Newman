import { Selector } from 'testcafe';

class LoginPageObjects {
  elementsTg = {
    in_username: () => Selector('#username'),
    in_password: () => Selector('#password'),
    btn_login: () => Selector('#send-login'),
    btn_loginRaf: () => Selector('#button-submit'),

    btn_forgot: () => Selector('#login-send a').withText('Forget Login Information ?'),
    btn_register: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_dontHaveAccount: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_login: () => Selector('#login-send span').withText('Log In'),
    lbl_signIn: () => Selector('#main-page-content div').withText('SIGN IN TO YOUR ACCOUNT').nth(3),
  }

  elementsCbol = {
    in_username: () => Selector('#CustomerID'),
    in_password: () => Selector('#Password'),
    btn_login: () => Selector('#button-submit-login'),
    btn_loginRaf: () => Selector('#button-submit'),

    btn_forgot: () => Selector('#RemoveForgot > a'),
    btn_register: () => Selector('#join-now-button'),
    lbl_dontHaveAccount: () => Selector('#homePage > div.mainColl > div > div.signIn.col_3c.right > div > img'),
    lbl_login: () => Selector('#button-submit-login'),
    lbl_signIn: () => Selector('#RemoveForgot'),
  }

  elementsWc = {
    in_username: () => Selector('#username'),
    in_password: () => Selector('#password'),
    btn_login: () => Selector('#send-login'),
    btn_loginRaf: () => Selector('#button-submit'),

    btn_forgot: () => Selector('#login-send a').withText('Forget Login Information ?'),
    btn_register: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_dontHaveAccount: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_login: () => Selector('#login-send span').withText('Log In'),
    lbl_signIn: () => Selector('#main-page-content div').withText('SIGN IN TO YOUR ACCOUNT').nth(3),
  }

  elementsLv = {
    in_username: () => Selector('#username'),
    in_password: () => Selector('#password'),
    btn_login: () => Selector('#send-login'),
    btn_loginRaf: () => Selector('#button-submit'),

    btn_forgot: () => Selector('#login-send a').withText('Forget Login Information ?'),
    btn_register: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_dontHaveAccount: () => Selector('#main-page-content a').withText('REGISTER'),
    lbl_login: () => Selector('#login-send span').withText('Log In'),
    lbl_signIn: () => Selector('#main-page-content div').withText('SIGN IN TO YOUR ACCOUNT').nth(3),
  }

  elementsCsb = {
    in_username: () => Selector('#CustomerID'),
    in_password: () => Selector('#Password'),
    btn_login: () => Selector('#button-submit-login'),
    btn_loginRaf: () => Selector('#button-submit'),

    btn_forgot: () => Selector('#RemoveForgot > a'),
    btn_register: () => Selector('#join-now-button'),
    lbl_dontHaveAccount: () => Selector('#homePage > div.mainColl > div > div.signIn.col_3c.right > div > img'),
    lbl_login: () => Selector('#button-submit-login'),
    lbl_signIn: () => Selector('#RemoveForgot'),
  }
}

export const loginPageObject = new LoginPageObjects()