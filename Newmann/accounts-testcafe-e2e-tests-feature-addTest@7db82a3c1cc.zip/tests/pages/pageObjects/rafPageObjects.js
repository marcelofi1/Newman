"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rafPageObject = void 0;
const testcafe_1 = require("testcafe");
let elementsTg;
let elementsBol;
let elementsWc;
let elementsLv;
class RafPageObjects {
    constructor() {
        this.elementsTg = {
            //MyAccuount Section
            btn_MyAccount: () => (0, testcafe_1.Selector)('#myaccount-option'),
            collapse_Raf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > span > span'),
            btn_Raf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(1) > a'),
            btn_ViewRaf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(2) > a'),
            lbl_QuantityRaf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.mainContent > div > div.bd > div:nth-child(5) > table.record > tbody > tr:nth-child(1) > td:nth-child(3) > span'),
            btn_Sports: () => (0, testcafe_1.Selector)('#formSelectedButton > ul > li:nth-child(1) > label').withText('Sports'),
            lbl_RafLink: () => (0, testcafe_1.Selector)('#raflink'),
            btn_logout: () => (0, testcafe_1.Selector)('#logoutBtn'),
            btn_ModalRaf: () => (0, testcafe_1.Selector)('#modalNickName > div > div > div > button'),
            btn_home: () => (0, testcafe_1.Selector)('#bet-logo2 > a > img'),
        };
        this.elementsCbol = {
            //MyAccuount Section
            btn_MyAccount: () => (0, testcafe_1.Selector)('#myaccount-option'),
            collapse_Raf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > span > span'),
            btn_Raf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(1) > a'),
            btn_ViewRaf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(2) > a'),
            lbl_QuantityRaf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.mainContent > div > div.bd > div:nth-child(5) > table.record > tbody > tr:nth-child(1) > td:nth-child(3) > span'),
            btn_Sports: () => (0, testcafe_1.Selector)('#formSelectedButton > ul > li:nth-child(1) > label').withText('Sports'),
            lbl_RafLink: () => (0, testcafe_1.Selector)('#raflink'),
            btn_ModalRaf: () => (0, testcafe_1.Selector)('#modalNickName > div > div > div > button'),
            btn_logout: () => (0, testcafe_1.Selector)('#button-logout'),
            btn_home: () => (0, testcafe_1.Selector)('#bet-logo2 > a > img'),
        };
        this.elementsWc = {
            //MyAccuount Section
            btn_MyAccount: () => (0, testcafe_1.Selector)('#myaccount-option'),
            collapse_Raf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > span > span'),
            btn_Raf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(1) > a'),
            btn_ViewRaf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(2) > a'),
            lbl_QuantityRaf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.mainContent > div > div.bd > div:nth-child(5) > table.record > tbody > tr:nth-child(1) > td:nth-child(3) > span'),
            btn_Sports: () => (0, testcafe_1.Selector)('#formSelectedButton > ul > li:nth-child(1) > label').withText('Sports'),
            lbl_RafLink: () => (0, testcafe_1.Selector)('#raflink'),
            btn_logout: () => (0, testcafe_1.Selector)('#logoutBtn'),
            btn_ModalRaf: () => (0, testcafe_1.Selector)('#modalNickName > div > div > div > button'),
            btn_home: () => (0, testcafe_1.Selector)('#bet-logo2 > a > img'),
        };
        this.elementsLv = {
            //MyAccuount Section
            btn_MyAccount: () => (0, testcafe_1.Selector)('#myaccount-option'),
            collapse_Raf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > span > span'),
            btn_Raf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(1) > a'),
            btn_ViewRaf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(2) > a'),
            lbl_QuantityRaf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.mainContent > div > div.bd > div:nth-child(5) > table.record > tbody > tr:nth-child(1) > td:nth-child(3) > span'),
            btn_Sports: () => (0, testcafe_1.Selector)('#formSelectedButton > ul > li:nth-child(1) > label').withText('Sports'),
            lbl_RafLink: () => (0, testcafe_1.Selector)('#raflink'),
            btn_logout: () => (0, testcafe_1.Selector)('#logoutBtn'),
            btn_ModalRaf: () => (0, testcafe_1.Selector)('#modalNickName > div > div > div > button'),
            btn_home: () => (0, testcafe_1.Selector)('#bet-logo2 > a > img'),
        };
        this.elementsCsb = {
            //MyAccuount Section
            btn_MyAccount: () => (0, testcafe_1.Selector)('#myaccount-option'),
            collapse_Raf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > span > span'),
            btn_Raf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(1) > a'),
            btn_ViewRaf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(2) > a'),
            lbl_QuantityRaf: () => (0, testcafe_1.Selector)('#myAcwwwcount > div > div.mainContent > div > div.bd > div:nth-child(5) > table.record > tbody > tr:nth-child(1) > td:nth-child(3) > span'),
            btn_Sports: () => (0, testcafe_1.Selector)('#formSelectedButton > ul > li:nth-child(1) > label').withText('Sports'),
            lbl_RafLink: () => (0, testcafe_1.Selector)('#raflink'),
            btn_logout: () => (0, testcafe_1.Selector)('#logoutBtn'),
            btn_ModalRaf: () => (0, testcafe_1.Selector)('#modalNickName > div > div > div > button'),
            btn_home: () => (0, testcafe_1.Selector)('#bet-logo2 > a > img'),
        };
    }
}
exports.rafPageObject = new RafPageObjects();
