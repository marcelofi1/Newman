"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mailsPageObject = void 0;
const testcafe_1 = require("testcafe");
class MailsPageObjects {
    constructor() {
        this.elementsTg = {
            //Yopmail Page
            in_mailYop: () => (0, testcafe_1.Selector)('#login'),
            btn_mail: () => (0, testcafe_1.Selector)('#refreshbut > button'),
            iframe_Mail: () => (0, testcafe_1.Selector)('#ifmail'),
            link_Raf: () => (0, testcafe_1.Selector)('#mail > div > table > tbody > tr > td > div:nth-child(3) > div > div > div > div > div > div > div > p:nth-child(5) > span:nth-child(3) > span > a'),
        };
        this.elementsCbol = {
            //Yopmail Page
            in_mailYop: () => (0, testcafe_1.Selector)('#login'),
            btn_mail: () => (0, testcafe_1.Selector)('#refreshbut > button'),
            iframe_Mail: () => (0, testcafe_1.Selector)('#ifmail'),
            link_Raf: () => (0, testcafe_1.Selector)('#mail > div > table > tbody > tr > td > div:nth-child(3) > div > div > div > div > div > div > div > p:nth-child(5) > span:nth-child(3) > span > a'),
        };
        this.elementsWc = {
            //Yopmail Page
            in_mailYop: () => (0, testcafe_1.Selector)('#login'),
            btn_mail: () => (0, testcafe_1.Selector)('#refreshbut > button'),
            iframe_Mail: () => (0, testcafe_1.Selector)('#ifmail'),
            link_Raf: () => (0, testcafe_1.Selector)('#mail > div > table > tbody > tr > td > div:nth-child(3) > div > div > div > div > div > div > div > p:nth-child(5) > span:nth-child(3) > span > a'),
        };
        this.elementsLv = {
            //Yopmail Page
            in_mailYop: () => (0, testcafe_1.Selector)('#login'),
            btn_mail: () => (0, testcafe_1.Selector)('#refreshbut > button'),
            iframe_Mail: () => (0, testcafe_1.Selector)('#ifmail'),
            link_Raf: () => (0, testcafe_1.Selector)('#mail > div > table > tbody > tr > td > div:nth-child(3) > div > div > div > div > div > div > div > p:nth-child(5) > span:nth-child(3) > span > a'),
        };
        this.elementsCsb = {
            //Yopmail Page
            in_mailYop: () => (0, testcafe_1.Selector)('#login'),
            btn_mail: () => (0, testcafe_1.Selector)('#refreshbut > button'),
            iframe_Mail: () => (0, testcafe_1.Selector)('#ifmail'),
            link_Raf: () => (0, testcafe_1.Selector)('#mail > div > table > tbody > tr > td > div:nth-child(3) > div > div > div > div > div > div > div > p:nth-child(5) > span:nth-child(3) > span > a'),
        };
    }
}
exports.mailsPageObject = new MailsPageObjects();
