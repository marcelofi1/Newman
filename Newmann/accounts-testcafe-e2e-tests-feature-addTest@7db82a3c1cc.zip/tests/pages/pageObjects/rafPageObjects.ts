import { Selector } from 'testcafe';

let elementsTg;
let elementsBol;
let elementsWc;
let elementsLv;

class RafPageObjects {
  elementsTg = {
    //MyAccuount Section
    btn_MyAccount: () => Selector('#myaccount-option'),
    collapse_Raf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > span > span'),
    btn_Raf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(1) > a'),
    btn_ViewRaf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(2) > a'),
    lbl_QuantityRaf: () => Selector('#myAcwwwcount > div > div.mainContent > div > div.bd > div:nth-child(5) > table.record > tbody > tr:nth-child(1) > td:nth-child(3) > span'),
    btn_Sports: () => Selector('#formSelectedButton > ul > li:nth-child(1) > label').withText('Sports'),
    lbl_RafLink: () => Selector('#raflink'),
    btn_logout: () => Selector('#logoutBtn'),


    btn_ModalRaf: () => Selector('#modalNickName > div > div > div > button'),
    btn_home: () => Selector('#bet-logo2 > a > img'),
  }

  elementsCbol = {
    //MyAccuount Section
    btn_MyAccount: () => Selector('#myaccount-option'),
    collapse_Raf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > span > span'),
    btn_Raf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(1) > a'),
    btn_ViewRaf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(2) > a'),
    lbl_QuantityRaf: () => Selector('#myAcwwwcount > div > div.mainContent > div > div.bd > div:nth-child(5) > table.record > tbody > tr:nth-child(1) > td:nth-child(3) > span'),
    btn_Sports: () => Selector('#formSelectedButton > ul > li:nth-child(1) > label').withText('Sports'),
    lbl_RafLink: () => Selector('#raflink'),
    btn_ModalRaf: () => Selector('#modalNickName > div > div > div > button'),
    btn_logout: () => Selector('#button-logout'),
    btn_home: () => Selector('#bet-logo2 > a > img'),
}

  elementsWc = {
//MyAccuount Section
    btn_MyAccount: () => Selector('#myaccount-option'),
    collapse_Raf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > span > span'),
    btn_Raf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(1) > a'),
    btn_ViewRaf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(2) > a'),
    lbl_QuantityRaf: () => Selector('#myAcwwwcount > div > div.mainContent > div > div.bd > div:nth-child(5) > table.record > tbody > tr:nth-child(1) > td:nth-child(3) > span'),
    btn_Sports: () => Selector('#formSelectedButton > ul > li:nth-child(1) > label').withText('Sports'),
    lbl_RafLink: () => Selector('#raflink'),
    btn_logout: () => Selector('#logoutBtn'),


    btn_ModalRaf: () => Selector('#modalNickName > div > div > div > button'),
    btn_home: () => Selector('#bet-logo2 > a > img'),
  }

  elementsLv = {
    //MyAccuount Section
    btn_MyAccount: () => Selector('#myaccount-option'),
    collapse_Raf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > span > span'),
    btn_Raf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(1) > a'),
    btn_ViewRaf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(2) > a'),
    lbl_QuantityRaf: () => Selector('#myAcwwwcount > div > div.mainContent > div > div.bd > div:nth-child(5) > table.record > tbody > tr:nth-child(1) > td:nth-child(3) > span'),
    btn_Sports: () => Selector('#formSelectedButton > ul > li:nth-child(1) > label').withText('Sports'),
    lbl_RafLink: () => Selector('#raflink'),
    btn_logout: () => Selector('#logoutBtn'),


    btn_ModalRaf: () => Selector('#modalNickName > div > div > div > button'),
    btn_home: () => Selector('#bet-logo2 > a > img'),
  }

  elementsCsb = {
    //MyAccuount Section
    btn_MyAccount: () => Selector('#myaccount-option'),
    collapse_Raf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > span > span'),
    btn_Raf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(1) > a'),
    btn_ViewRaf: () => Selector('#myAcwwwcount > div > div.nav > ul:nth-child(2) > li:nth-child(10) > ul > li:nth-child(2) > a'),
    lbl_QuantityRaf: () => Selector('#myAcwwwcount > div > div.mainContent > div > div.bd > div:nth-child(5) > table.record > tbody > tr:nth-child(1) > td:nth-child(3) > span'),
    btn_Sports: () => Selector('#formSelectedButton > ul > li:nth-child(1) > label').withText('Sports'),
    lbl_RafLink: () => Selector('#raflink'),
    btn_logout: () => Selector('#logoutBtn'),

    
    btn_ModalRaf: () => Selector('#modalNickName > div > div > div > button'),
    btn_home: () => Selector('#bet-logo2 > a > img'),
  }
}

export const rafPageObject = new RafPageObjects()