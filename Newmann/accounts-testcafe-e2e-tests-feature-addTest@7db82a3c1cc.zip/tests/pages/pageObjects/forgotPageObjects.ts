import { Selector } from 'testcafe';

let elementsTg;
let elementsBol;
let elementsWc;
let elementsLv;

class ForgotPageObjects {
  elementsTg = {

    img_tiggerGamming: () => Selector('#header-image img'),
    lbl_resetPassword: () => Selector('#forgotPasswordForm h2').withText('RESET PASSWORD'),
    lbl_instructions: () => Selector('#paragraph_content'),
    in_username: () => Selector('#username'),
    btn_proceed: () => Selector('#tgbtnResetPwd span').withText('Proceed'),
    lbl_needHelp: () => Selector('#forgotPasswordForm div').withText('Need Help? Contact Us'),

    //Errors
    lbl_attempts: () => Selector('#forgot_passwd_attempts'),
    lbl_errorDetails: () => Selector('#forgotpassworderrormessage'),

    //exceeded attempts page
    lbl_passwordHelp: () => Selector('#forgotPassword h2').withText('Password Help'),
    lbl_exceeded: () => Selector('#forgotPassword p').withText('You Have exceeded the maximum number of allowed at'),
    lbl_havingDifficulties: () => Selector('#forgotPassword p').withText('If you continue having difficulties, please Contac'),
    btn_contactUs: () => Selector('#forgot_exceeded_links a').withText('Contact Us'),
    btn_forgot: () => Selector('#forgot_exceeded_links a').withText('Forgot Password?'),

    //forgot password page
    lbl_titleResetPassword: () => Selector('#forgotPasswordForm h2').withText('RESET PASSWORD'),
    lbl_linkMail: () => Selector('#forgotpasswordmessage'),
    btn_contactUsOk: () => Selector('#forgotPasswordForm a').withText('Contact Us')
  }

  elementsCbol = {
    img_tiggerGamming: () => Selector('#header-image img'),
    lbl_resetPassword: () => Selector('#forgotPasswordForm h2').withText('RESET PASSWORD'),
    lbl_instructions: () => Selector('#paragraph_content'),
    in_username: () => Selector('#username'),
    btn_proceed: () => Selector('#tgbtnResetPwd span').withText('Proceed'),
    lbl_needHelp: () => Selector('#forgotPasswordForm div').withText('Need Help? Contact Us'),

    //Errors
    lbl_attempts: () => Selector('#forgot_passwd_attempts'),
    lbl_errorDetails: () => Selector('#forgotpassworderrormessage'),

    //exceeded attempts page
    lbl_passwordHelp: () => Selector('#forgotPassword h2').withText('Password Help'),
    lbl_exceeded: () => Selector('#forgotPassword p').withText('You Have exceeded the maximum number of allowed at'),
    lbl_havingDifficulties: () => Selector('#forgotPassword p').withText('If you continue having difficulties, please Contac'),
    btn_contactUs: () => Selector('#forgot_exceeded_links a').withText('Contact Us'),
    btn_forgot: () => Selector('#forgot_exceeded_links a').withText('Forgot Password?'),

    //forgot password page
    lbl_titleResetPassword: () => Selector('#forgotPasswordForm h2').withText('RESET PASSWORD'),
    lbl_linkMail: () => Selector('#forgotpasswordmessage'),
    btn_contactUsOk: () => Selector('#forgotPasswordForm a').withText('Contact Us')
  }

  elementsWc = {
    img_tiggerGamming: () => Selector('#header-image img'),
    lbl_resetPassword: () => Selector('#forgotPasswordForm h2').withText('RESET PASSWORD'),
    lbl_instructions: () => Selector('#paragraph_content'),
    in_username: () => Selector('#username'),
    btn_proceed: () => Selector('#tgbtnResetPwd span').withText('Proceed'),
    lbl_needHelp: () => Selector('#forgotPasswordForm div').withText('Need Help? Contact Us'),

    //Errors
    lbl_attempts: () => Selector('#forgot_passwd_attempts'),
    lbl_errorDetails: () => Selector('#forgotpassworderrormessage'),

    //exceeded attempts page
    lbl_passwordHelp: () => Selector('#forgotPassword h2').withText('Password Help'),
    lbl_exceeded: () => Selector('#forgotPassword p').withText('You Have exceeded the maximum number of allowed at'),
    lbl_havingDifficulties: () => Selector('#forgotPassword p').withText('If you continue having difficulties, please Contac'),
    btn_contactUs: () => Selector('#forgot_exceeded_links a').withText('Contact Us'),
    btn_forgot: () => Selector('#forgot_exceeded_links a').withText('Forgot Password?'),

    //forgot password page
    lbl_titleResetPassword: () => Selector('#forgotPasswordForm h2').withText('RESET PASSWORD'),
    lbl_linkMail: () => Selector('#forgotpasswordmessage'),
    btn_contactUsOk: () => Selector('#forgotPasswordForm a').withText('Contact Us')
  }

  elementsLv = {
    img_tiggerGamming: () => Selector('#header-image img'),
    lbl_resetPassword: () => Selector('#forgotPasswordForm h2').withText('RESET PASSWORD'),
    lbl_instructions: () => Selector('#paragraph_content'),
    in_username: () => Selector('#username'),
    btn_proceed: () => Selector('#tgbtnResetPwd span').withText('Proceed'),
    lbl_needHelp: () => Selector('#forgotPasswordForm div').withText('Need Help? Contact Us'),

    //Errors
    lbl_attempts: () => Selector('#forgot_passwd_attempts'),
    lbl_errorDetails: () => Selector('#forgotpassworderrormessage'),

    //exceeded attempts page
    lbl_passwordHelp: () => Selector('#forgotPassword h2').withText('Password Help'),
    lbl_exceeded: () => Selector('#forgotPassword p').withText('You Have exceeded the maximum number of allowed at'),
    lbl_havingDifficulties: () => Selector('#forgotPassword p').withText('If you continue having difficulties, please Contac'),
    btn_contactUs: () => Selector('#forgot_exceeded_links a').withText('Contact Us'),
    btn_forgot: () => Selector('#forgot_exceeded_links a').withText('Forgot Password?'),

    //forgot password page
    lbl_titleResetPassword: () => Selector('#forgotPasswordForm h2').withText('RESET PASSWORD'),
    lbl_linkMail: () => Selector('#forgotpasswordmessage'),
    btn_contactUsOk: () => Selector('#forgotPasswordForm a').withText('Contact Us')
  }

  elementsCsb = {

    img_tiggerGamming: () => Selector('#header-image img'),
    lbl_resetPassword: () => Selector('#forgotPasswordForm h2').withText('RESET PASSWORD'),
    lbl_instructions: () => Selector('#paragraph_content'),
    in_username: () => Selector('#username'),
    btn_proceed: () => Selector('#tgbtnResetPwd span').withText('Proceed'),
    lbl_needHelp: () => Selector('#forgotPasswordForm div').withText('Need Help? Contact Us'),

    //Errors
    lbl_attempts: () => Selector('#forgot_passwd_attempts'),
    lbl_errorDetails: () => Selector('#forgotpassworderrormessage'),

    //exceeded attempts page
    lbl_passwordHelp: () => Selector('#forgotPassword h2').withText('Password Help'),
    lbl_exceeded: () => Selector('#forgotPassword p').withText('You Have exceeded the maximum number of allowed at'),
    lbl_havingDifficulties: () => Selector('#forgotPassword p').withText('If you continue having difficulties, please Contac'),
    btn_contactUs: () => Selector('#forgot_exceeded_links a').withText('Contact Us'),
    btn_forgot: () => Selector('#forgot_exceeded_links a').withText('Forgot Password?'),

    //forgot password page
    lbl_titleResetPassword: () => Selector('#forgotPasswordForm h2').withText('RESET PASSWORD'),
    lbl_linkMail: () => Selector('#forgotpasswordmessage'),
    btn_contactUsOk: () => Selector('#forgotPasswordForm a').withText('Contact Us')
  }
}

export const forgotPageObjects = new ForgotPageObjects()