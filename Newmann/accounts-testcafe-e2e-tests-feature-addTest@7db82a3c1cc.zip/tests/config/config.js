"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getConfig = exports.getEnv = void 0;
const environmentVariableName = 'env';
const defaultEnvironmentName = 'qa';
const environmentConfigurationFileName = 'environments.json';
const getArgOrEnv = (argName, defaultValue) => {
    var _a, _b;
    const arg1 = process.argv.find(arg => arg.startsWith(`--${argName}=`));
    return ((_b = (_a = arg1 === null || arg1 === void 0 ? void 0 : arg1.split('=')[1]) !== null && _a !== void 0 ? _a : process.env[environmentVariableName]) !== null && _b !== void 0 ? _b : defaultValue);
};
const getEnv = () => getArgOrEnv(environmentVariableName, defaultEnvironmentName);
exports.getEnv = getEnv;
const getConfig = () => {
    const fs = require('fs');
    const env = (0, exports.getEnv)();
    return JSON.parse(fs.readFileSync(__dirname + '/' + environmentConfigurationFileName, 'utf8'))[env];
};
exports.getConfig = getConfig;
