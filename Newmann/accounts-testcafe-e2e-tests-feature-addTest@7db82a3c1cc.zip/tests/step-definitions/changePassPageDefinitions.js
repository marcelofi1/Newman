"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cucumber_1 = require("@cucumber/cucumber");
const changePassPageActions_1 = __importDefault(require("../pages/pageActions/changePassPageActions"));
const helper_1 = require("../utils/helper");
(0, cucumber_1.When)('user go to forgot link', (t) => __awaiter(void 0, void 0, void 0, function* () {
    const brand = (0, helper_1.getBrand)();
    if (brand && brand.urlForgot) {
        yield t.navigateTo(brand.urlForgot);
        yield changePassPageActions_1.default.elementsAreVisibles();
    }
    else {
        console.log("Error: URL olvidada no disponible");
    }
}));
(0, cucumber_1.When)('user complete fields new password and re enter password with valid values', (t) => __awaiter(void 0, void 0, void 0, function* () {
    const password = yield changePassPageActions_1.default.getPassword();
    if (password !== undefined) {
        yield changePassPageActions_1.default.completeNewPass(password);
        yield changePassPageActions_1.default.completeReEnterPass(password);
        yield changePassPageActions_1.default.clickProceedBtn();
    }
    else {
        console.log('Error: Password is undefined');
    }
}));
(0, cucumber_1.When)('user complete fields new password and re enter password with invalid values', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.completeNewPass("invalid");
    yield changePassPageActions_1.default.completeReEnterPass("invalid");
    yield changePassPageActions_1.default.clickProceedBtn();
}));
(0, cucumber_1.When)('user complete fields new password and re enter password with invalid characters', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.completeNewPass("InvalidCharactrs ");
    yield changePassPageActions_1.default.completeReEnterPass("InvalidCharactrs ");
    yield changePassPageActions_1.default.clickProceedBtn();
}));
(0, cucumber_1.When)('user complete fields new password and re enter password with olds values', (t) => __awaiter(void 0, void 0, void 0, function* () {
    const oldPassword = (0, helper_1.getBrand)().passwordNoCredit;
    if (oldPassword !== undefined) {
        yield changePassPageActions_1.default.completeNewPass(oldPassword);
        yield changePassPageActions_1.default.completeReEnterPass(oldPassword);
        yield changePassPageActions_1.default.clickProceedBtn();
    }
    else {
        console.log('Error: Old password is undefined');
    }
}));
(0, cucumber_1.When)('user complete fields new password and re enter password with diferents values', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.completeNewPass("DiferentPass1!");
    yield changePassPageActions_1.default.completeReEnterPass("DiferentPass2!");
    yield changePassPageActions_1.default.clickProceedBtn();
}));
(0, cucumber_1.When)('user only complete field new password', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.completeNewPass("OnlyNewPass1!");
    yield changePassPageActions_1.default.clickProceedBtn();
}));
(0, cucumber_1.When)('user only complete field re enter password', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.completeReEnterPass("OnlyReEnterPass1!");
    yield changePassPageActions_1.default.clickProceedBtn();
}));
(0, cucumber_1.When)('user complete fields username and password with diferents values', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.completeNewPass("DiferentPass1!");
    yield changePassPageActions_1.default.completeReEnterPass("DiferentPass2!");
    yield changePassPageActions_1.default.clickProceedBtn();
}));
(0, cucumber_1.Then)('user valid change password', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.validChangePass();
}));
(0, cucumber_1.Then)('user see message for old password', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.validOldPassword();
}));
(0, cucumber_1.Then)('user see message for new password and re enter password not match', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.validNotMatchPasswords();
}));
(0, cucumber_1.Then)('password is not changed because new password field is empty', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.validEmptyNewPass();
}));
(0, cucumber_1.Then)('password is not changed because re enter password field is empty', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.validEmptyReEnterPass();
}));
(0, cucumber_1.Then)('user see message error', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield changePassPageActions_1.default.validErrorPass();
}));
