import { After, Before, BeforeAll } from "@cucumber/cucumber";
import { ClientFunction, RequestLogger, t } from "testcafe";
import homePageActions from "../pages/pageActions/homePageActions";
import actions from "../utils/actions";
import { getBrand } from "../utils/helper";
import { jiraTrackingAfteEach, jiraTrackingBeforeAll } from "../utils/jira";


var cookies;

BeforeAll(async () => {
    //console.log("URL: " + brand.siteUrl);
    await jiraTrackingBeforeAll();
        
});

Before(async () => {
    const brand = getBrand();
    if (brand && !brand.name?.includes('backend') && brand.siteUrl) {
        await t.navigateTo(brand.siteUrl);
    }
});

After(async t => {
    await jiraTrackingAfteEach(t);
    await t.eval(() => localStorage.clear());
});