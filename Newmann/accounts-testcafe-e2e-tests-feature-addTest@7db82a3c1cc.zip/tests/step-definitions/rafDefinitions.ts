import { Then, When } from '@cucumber/cucumber';
import actions from '../utils/actions';
import rafPageActions from '../pages/pageActions/rafPageActions';
import joinPageActions from '../pages/pageActions/joinPageActions';
import mailsPageActions from '../pages/pageActions/mailsPageActions';
import loginPageActions from '../pages/pageActions/loginPageActions';
import { getBrand } from '../utils/helper';
const brand = getBrand();
let quantity: number;
let linkRaf: string;
let rafCode: string;
let mail: string;
const numEmail = Math.floor(Math.random() * 1000000);

When('user go to Refer a Friend page', async t => {
    await rafPageActions.clickBtnMyAccount();
    await rafPageActions.clickBtnViewRaf();
});

When('I view the joined quantity', async (t: TestController) => {
    const value = await rafPageActions.getValueRaf();
    if (value !== null) {
        quantity = +value;
    } else {
        console.log('Error: Joined quantity is null');
    }
});

When('I refer a new friend to sport by email', async (t: TestController) => {
    await rafPageActions.clickBtnRaf();
    await rafPageActions.closeModalRaf();
    const value = await rafPageActions.getValueLinkRaf();
    if (value !== null) {
        linkRaf = value;
        rafCode = linkRaf.split('RAF=')[1];
    } else {
        console.log('Error: Link RAF is null');
    }
    await rafPageActions.clickBtnLogout();
});

When('My friend go to link RAF', async (t: TestController) => {
    if (linkRaf !== null) {
        await t.navigateTo(linkRaf);
        await rafPageActions.validateURLRaf(linkRaf);
    } else {
        console.log('Error: Link RAF is null');
    }
});

When('the user create account as RAF', async (t: TestController) => {
    mail = 'n.rioseco' + numEmail + '@yopmail.com';
    await joinPageActions.completeFirstName('Nico');
    await joinPageActions.completeLastName('RafAccounts');
    await joinPageActions.completeEmail(mail);
    await joinPageActions.completePassword('Elchavot1');
    await joinPageActions.completeZip('32003');
    await joinPageActions.completePhone('2494281960');
    await joinPageActions.completeBirth('05171990');
});

When('the user valid account', async (t: TestController) => {
    await t.wait(10000)
    await t.navigateTo('https://yopmail.com?' + mail);
    await t.wait(2000)
    if (linkRaf !== null) {
        await t.navigateTo('https://yopmail.com?' + mail);
        await t.wait(2000);
        const value = await mailsPageActions.getLinkRaf();
        if (value !== null) {
            linkRaf = value;
            await t.switchToMainWindow();
            await t.navigateTo(linkRaf);
        } else {
            console.log('Error: Link RAF from email is null');
        }
    } else {
        console.log('Error: Link RAF is null');
    }

    if (mail !== undefined) {
        await loginPageActions.completeUsername(mail);
        await loginPageActions.completePassword('Elchavot1');
        await loginPageActions.clickBtnLoginRaf();
    } else {
        console.log('Error: Mail is undefined');
    }
});

Then('the user verify that the account is created as RAF', async (t: TestController) => {
    await rafPageActions.clickBtnHome();
    await t.wait(3000);

    if (brand.domain !== undefined) {
        const { name, value } = await actions.getSpecifcCookie('RAF', brand.domain);
        if (value !== null) {
            await t
                .expect(name).eql('RAF')
                .expect(value).eql(rafCode);
        } else {
            console.log('Error: Cookie value is null');
        }
    } else {
        console.log('Error: Brand domain is undefined');
    }

    await rafPageActions.clickBtnLogout();
});

Then('I return to Refer a Friend page for valid joined quantity', async (t: TestController) => {
    
    if (brand.siteUrl !== undefined){
        await t.navigateTo(brand.siteUrl);
    } else {
        console.log('Error: SiteUrl is undefined');
    }
    if (brand.usernameWithCredit !== undefined && brand.passwordWithCredit !== undefined) {
        await loginPageActions.completeUsername(brand.usernameWithCredit);
        await loginPageActions.completePassword(brand.passwordWithCredit);
        await loginPageActions.clickBtnLogin();
    } else {
        console.log('Error: Username or password with credit is undefined');
    }

    await rafPageActions.clickBtnMyAccount();
    await rafPageActions.clickBtnViewRaf();

    const value = await rafPageActions.getValueRaf();
    if (value !== null) {
        const newQuantity: number = +value;
        await t.expect(newQuantity).gte(quantity);
    } else {
        console.log('Error: Joined quantity is null');
    }
});
