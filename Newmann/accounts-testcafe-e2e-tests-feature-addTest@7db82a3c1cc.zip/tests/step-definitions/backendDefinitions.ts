import { Then, When } from '@cucumber/cucumber';
import { getToken, refreshToken, getMessage, getLocation } from '../utils/backend';
import { ClientFunction } from 'testcafe';

let token: string | any[];
let tokenRefresh: string | any[];
let status: string | any[];

interface MessageBody {
    Messages: any[];
    TotalCountUnreadMessage: number;
    TotalCountMessage: number;
    Subject: string | null;
    UserInitials: string;
    UserName: string;
    IsValidModel: boolean;
    ModelErrorMessage: string | null;
    RedirectTo: string | null;
    TokenJwt: string;
    TokensJwt: any[];
    IsError: boolean;
    CustomerAlias: string | null;
  }

let body: MessageBody;

Then('post login', async (t: TestController) => {
    //token = await refreshToken(tokenRefresh);
    [status, body] = await getMessage(token);
    await t.expect(status).ok()
        .expect(status.toString().includes('200')).ok('Status code is not 200')
    
    await t.expect(body).ok()
        .expect(typeof body.TotalCountMessage === 'number' && body.TotalCountMessage === 0)
        .ok('No se muestran los mensajes correctos');
});

When('get cookie', async (t: TestController) => {
    [token, tokenRefresh] = await getToken();
});


When('get location', async (t: TestController) => {
    await getLocation('https://sb.qa.pposervices.local/sportsbook');
    
    await t.wait(80000);
});