"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cucumber_1 = require("@cucumber/cucumber");
const forgotPageActions_1 = __importDefault(require("../pages/pageActions/forgotPageActions"));
const loginPageActions_1 = __importDefault(require("../pages/pageActions/loginPageActions"));
const helper_1 = require("../utils/helper");
(0, cucumber_1.When)('user complete username and password - without credit', (t) => __awaiter(void 0, void 0, void 0, function* () {
    const username = (0, helper_1.getBrand)().emailNoCredit;
    const password = (0, helper_1.getBrand)().passwordNoCredit;
    if (username !== undefined && password !== undefined) {
        yield loginPageActions_1.default.completeUsername(username);
        yield loginPageActions_1.default.completePassword(password);
    }
    else {
        console.log('Error: Username or password for without credit is undefined');
    }
}));
(0, cucumber_1.When)('user complete username and password - with credit', (t) => __awaiter(void 0, void 0, void 0, function* () {
    const username = (0, helper_1.getBrand)().usernameWithCredit;
    const password = (0, helper_1.getBrand)().passwordWithCredit;
    if (username !== undefined && password !== undefined) {
        yield loginPageActions_1.default.completeUsername(username);
        yield loginPageActions_1.default.completePassword(password);
    }
    else {
        console.log('Error: Username or password for with credit is undefined');
    }
}));
(0, cucumber_1.When)('user complete username and password - invalid', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield loginPageActions_1.default.completeUsername('invalid');
    yield loginPageActions_1.default.completePassword('invalid');
}));
(0, cucumber_1.When)('user only complete username', (t) => __awaiter(void 0, void 0, void 0, function* () {
    const username = (0, helper_1.getBrand)().emailNoCredit;
    if (username !== undefined) {
        yield loginPageActions_1.default.completeUsername(username);
    }
    else {
        console.log('Error: Username is undefined');
    }
}));
(0, cucumber_1.When)('user only complete password', (t) => __awaiter(void 0, void 0, void 0, function* () {
    const password = (0, helper_1.getBrand)().passwordNoCredit;
    if (password !== undefined) {
        yield loginPageActions_1.default.completePassword(password);
    }
    else {
        console.log('Error: Password is undefined');
    }
}));
(0, cucumber_1.When)('user press on Login button', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield loginPageActions_1.default.clickBtnLogin();
}));
(0, cucumber_1.When)('user press on Forgot button', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield loginPageActions_1.default.clickBtnForgot();
    yield forgotPageActions_1.default.elementsAreVisibles();
}));
