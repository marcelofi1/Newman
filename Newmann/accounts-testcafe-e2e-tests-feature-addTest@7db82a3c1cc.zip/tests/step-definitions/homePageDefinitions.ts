import { Given, When } from '@cucumber/cucumber';
import homePageActions from '../pages/pageActions/homePageActions';
import joinPageActions from '../pages/pageActions/joinPageActions';
import loginPageActions from '../pages/pageActions/loginPageActions';
import actions from '../utils/actions';
import { brand } from '../utils/brand';
//import { Database } from '../utils/mssql';

Given('I open the brand page', async t => {
  //const database = new Database("Accounts");
  //database.query('select count(*) as count FROM [AccountIdentity]')
  await homePageActions.urlIsDisplayed();
  await homePageActions.headerIsVisible();
  await homePageActions.menuIsVisible();
  await homePageActions.footerIsVisible();
});

When('user clicks Login button', async (t: TestController) => {
  await homePageActions.clickLoginBtn();
  await loginPageActions.elementsAreVisible();
})

When('user clicks Join button', async (t: TestController) => {
  await homePageActions.clickJoinBtn();
  //await joinPageActions.elementsAreVisible();
})
