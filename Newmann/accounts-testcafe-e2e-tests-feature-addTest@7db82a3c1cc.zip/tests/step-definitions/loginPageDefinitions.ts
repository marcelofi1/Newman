import { When } from '@cucumber/cucumber';
import forgotPageActions from '../pages/pageActions/forgotPageActions';
import loginPageActions from '../pages/pageActions/loginPageActions';
import { getBrand } from '../utils/helper';

When('user complete username and password - without credit', async (t: TestController) => {
    const username = getBrand().emailNoCredit;
    const password = getBrand().passwordNoCredit;
    if (username !== undefined && password !== undefined) {
        await loginPageActions.completeUsername(username);
        await loginPageActions.completePassword(password);
    } else {
        console.log('Error: Username or password for without credit is undefined');
    }
})

When('user complete username and password - with credit', async (t: TestController) => {
    const username = getBrand().usernameWithCredit;
    const password = getBrand().passwordWithCredit;
    if (username !== undefined && password !== undefined) {
        await loginPageActions.completeUsername(username);
        await loginPageActions.completePassword(password);
    } else {
        console.log('Error: Username or password for with credit is undefined');
    }
})

When('user complete username and password - invalid', async (t: TestController) => {
    await loginPageActions.completeUsername('invalid');
    await loginPageActions.completePassword('invalid');
})

When('user only complete username', async (t: TestController) => {
    const username = getBrand().emailNoCredit;
    if (username !== undefined) {
        await loginPageActions.completeUsername(username);
    } else {
        console.log('Error: Username is undefined');
    }
})

When('user only complete password', async (t: TestController) => {
    const password = getBrand().passwordNoCredit;
    if (password !== undefined) {
        await loginPageActions.completePassword(password);
    } else {
        console.log('Error: Password is undefined');
    }
})

When('user press on Login button', async (t: TestController) => {
    await loginPageActions.clickBtnLogin();
})

When('user press on Forgot button', async (t: TestController) => {
    await loginPageActions.clickBtnForgot();
    await forgotPageActions.elementsAreVisibles();
})
