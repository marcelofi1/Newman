"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const cucumber_1 = require("@cucumber/cucumber");
const testcafe_1 = require("testcafe");
const helper_1 = require("../utils/helper");
const jira_1 = require("../utils/jira");
var cookies;
(0, cucumber_1.BeforeAll)(() => __awaiter(void 0, void 0, void 0, function* () {
    //console.log("URL: " + brand.siteUrl);
    yield (0, jira_1.jiraTrackingBeforeAll)();
}));
(0, cucumber_1.Before)(() => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const brand = (0, helper_1.getBrand)();
    if (brand && !((_a = brand.name) === null || _a === void 0 ? void 0 : _a.includes('backend')) && brand.siteUrl) {
        yield testcafe_1.t.navigateTo(brand.siteUrl);
    }
}));
(0, cucumber_1.After)((t) => __awaiter(void 0, void 0, void 0, function* () {
    yield (0, jira_1.jiraTrackingAfteEach)(t);
    yield t.eval(() => localStorage.clear());
}));
