import { Then, When } from '@cucumber/cucumber';
import forgotPageActions from '../pages/pageActions/forgotPageActions';
import { getBrand } from '../utils/helper';

When('user complete username for forgot', async (t: TestController) => {
    const username = getBrand().emailForgot;
    if (username !== undefined) {
        await forgotPageActions.completeUsername(username);
    } else {
        console.log('Error: Username for forgot is undefined');
    }
})

When('user press on Proceed button', async (t: TestController) => {
    await forgotPageActions.clickBtnProceed();
})

Then('user see the validations of error', async (t: TestController) => {
    await forgotPageActions.errorElementsAreVisibles();
})

Then('user see the notfication for email sended', async (t: TestController) => {
    await forgotPageActions.linkElementsAreVisibles();
})

Then('user see the notfication for excedeed attempts', async (t: TestController) => {
    await forgotPageActions.attemptsElementsAreVisibles();
})
