import { Then, When } from '@cucumber/cucumber';
import changePassPageActions from '../pages/pageActions/changePassPageActions';
import { getBrand } from '../utils/helper';

When('user go to forgot link', async (t: TestController) => {
    const brand = getBrand();
    if (brand && brand.urlForgot) {
        await t.navigateTo(brand.urlForgot);
        await changePassPageActions.elementsAreVisibles();
    } else {
        console.log("Error: URL olvidada no disponible");
    }
})

When('user complete fields new password and re enter password with valid values', async (t: TestController) => {

    const password = await changePassPageActions.getPassword();
    if (password !== undefined) {
        await changePassPageActions.completeNewPass(password);
        await changePassPageActions.completeReEnterPass(password);
        await changePassPageActions.clickProceedBtn();
    } else {
        console.log('Error: Password is undefined');
    }
})

When('user complete fields new password and re enter password with invalid values', async (t: TestController) => {
    await changePassPageActions.completeNewPass("invalid");
    await changePassPageActions.completeReEnterPass("invalid");
    await changePassPageActions.clickProceedBtn();
})

When('user complete fields new password and re enter password with invalid characters', async (t: TestController) => {
    await changePassPageActions.completeNewPass("InvalidCharactrs ");
    await changePassPageActions.completeReEnterPass("InvalidCharactrs ");
    await changePassPageActions.clickProceedBtn();
})

When('user complete fields new password and re enter password with olds values', async (t: TestController) => {
    const oldPassword = getBrand().passwordNoCredit;
    if (oldPassword !== undefined) {
        await changePassPageActions.completeNewPass(oldPassword);
        await changePassPageActions.completeReEnterPass(oldPassword);
        await changePassPageActions.clickProceedBtn();
    } else {
        console.log('Error: Old password is undefined');
    }
})

When('user complete fields new password and re enter password with diferents values', async (t: TestController) => {
    await changePassPageActions.completeNewPass("DiferentPass1!");
    await changePassPageActions.completeReEnterPass("DiferentPass2!");
    await changePassPageActions.clickProceedBtn();
})

When('user only complete field new password', async (t: TestController) => {
    await changePassPageActions.completeNewPass("OnlyNewPass1!");
    await changePassPageActions.clickProceedBtn();
})

When('user only complete field re enter password', async (t: TestController) => {
    await changePassPageActions.completeReEnterPass("OnlyReEnterPass1!");
    await changePassPageActions.clickProceedBtn();
})

When('user complete fields username and password with diferents values', async (t: TestController) => {
    await changePassPageActions.completeNewPass("DiferentPass1!");
    await changePassPageActions.completeReEnterPass("DiferentPass2!");
    await changePassPageActions.clickProceedBtn();
})

Then('user valid change password', async (t: TestController) => {
    await changePassPageActions.validChangePass();
})

Then('user see message for old password', async (t: TestController) => {
    await changePassPageActions.validOldPassword();
})

Then('user see message for new password and re enter password not match', async (t: TestController) => {
    await changePassPageActions.validNotMatchPasswords();
})

Then('password is not changed because new password field is empty', async (t: TestController) => {
    await changePassPageActions.validEmptyNewPass();
})

Then('password is not changed because re enter password field is empty', async (t: TestController) => {
    await changePassPageActions.validEmptyReEnterPass();
})

Then('user see message error', async (t: TestController) => {
    await changePassPageActions.validErrorPass();
})
