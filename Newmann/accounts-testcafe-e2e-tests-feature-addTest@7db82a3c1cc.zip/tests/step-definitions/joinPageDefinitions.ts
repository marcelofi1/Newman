import { Then, When } from '@cucumber/cucumber';
import joinPageActions from '../pages/pageActions/joinPageActions';
import { getBrand } from '../utils/helper';


When('complete the account fields with null First Name', async (t: TestController) => {
    await joinPageActions.completeFirstName('NULL');
    await joinPageActions.completeLastName('Rioseco');
    await joinPageActions.completeEmail('tandilqaauto@grr.la');
    await joinPageActions.completePassword('PtyPass2!');
    await joinPageActions.completeZip('A2A2A2');
    await joinPageActions.completePhone('4137876313');
    await joinPageActions.completeBirth('05171990');
})

When('complete the account fields with null Last Name', async (t: TestController) => {
    await joinPageActions.completeFirstName('Nicolas');
    await joinPageActions.completeLastName('NULL');
    await joinPageActions.completeEmail('tandilqaauto@grr.la');
    await joinPageActions.completePassword('PtyPass2!');
    await joinPageActions.completeZip('A2A2A2');
    await joinPageActions.completePhone('4137876313');
    await joinPageActions.completeBirth('05171990');
})

When('complete the account fields with invalid Email', async (t: TestController) => {
    await joinPageActions.completeFirstName('Nicolas');
    await joinPageActions.completeLastName('Rioseco');
    await joinPageActions.completeEmail('tandilqaautogrr.la');
    await joinPageActions.completePassword('PtyPass2!');
    await joinPageActions.completeZip('A2A2A2');
    await joinPageActions.completePhone('4137876313');
    await joinPageActions.completeBirth('05171990');
})

When('complete the account fields with null Email', async (t: TestController) => {
    await joinPageActions.completeFirstName('Nicolas');
    await joinPageActions.completeLastName('Rioseco');
    await joinPageActions.completeEmail('NULL');
    await joinPageActions.completePassword('PtyPass2!');
    await joinPageActions.completeZip('A2A2A2');
    await joinPageActions.completePhone('4137876313');
    await joinPageActions.completeBirth('05171990');
})

When('complete the account fields with null Password', async (t: TestController) => {
    await joinPageActions.completeFirstName('Nicolas');
    await joinPageActions.completeLastName('Rioseco');
    await joinPageActions.completeEmail('tandilqaauto@grr.la');
    await joinPageActions.completePassword('NULL');
    await joinPageActions.completeZip('A2A2A2');
    await joinPageActions.completePhone('4137876313');
    await joinPageActions.completeBirth('05171990');
})

When('complete the account fields with invalid Password', async (t: TestController) => {
    await joinPageActions.completeFirstName('Nicolas');
    await joinPageActions.completeLastName('Rioseco');
    await joinPageActions.completeEmail('tandilqaauto@grr.la');
    await joinPageActions.completePassword('Invalid');
    await joinPageActions.completeZip('A2A2A2');
    await joinPageActions.completePhone('6477002435');
    await joinPageActions.completeBirth('05171990');
})

When('complete the account fields with null Zip', async (t: TestController) => {
    await joinPageActions.completeFirstName('Nicolas');
    await joinPageActions.completeLastName('Rioseco');
    await joinPageActions.completeEmail('tandilqaauto@grr.la');
    await joinPageActions.completePassword('PtyPass2!');
    await joinPageActions.completeZip('NULL');
    await joinPageActions.completePhone('6477002435');
    await joinPageActions.completeBirth('05171990');
})

When('complete the account fields with null Phone', async (t: TestController) => {
    await joinPageActions.completeFirstName('Nicolas');
    await joinPageActions.completeLastName('Rioseco');
    await joinPageActions.completeEmail('tandilqaauto@grr.la');
    await joinPageActions.completePassword('PtyPass2!');
    await joinPageActions.completeZip('A2A2A2');
    await joinPageActions.completePhone('NULL');
    await joinPageActions.completeBirth('05171990');
})

When('complete the account fields with null Birth', async (t: TestController) => {
    await joinPageActions.completeFirstName('Nicolas');
    await joinPageActions.completeLastName('Rioseco');
    await joinPageActions.completeEmail('tandilqaauto@grr.la');
    await joinPageActions.completePassword('PtyPass2!');
    await joinPageActions.completeZip('A2A2A2');
    await joinPageActions.completePhone('6477002435');
    await joinPageActions.completeBirth('NULL');
})

When('complete the account fields with younger date', async (t: TestController) => {
    await joinPageActions.completeFirstName('Nicolas');
    await joinPageActions.completeLastName('Rioseco');
    await joinPageActions.completeEmail('tandilqaauto@grr.la');
    await joinPageActions.completePassword('PtyPass2!');
    await joinPageActions.completeZip('A2A2A2');
    await joinPageActions.completePhone('6477002435');
    await joinPageActions.completeBirth('05172012');
})

When('complete the account fields with correctly values', async (t: TestController) => {
    await joinPageActions.completeFirstName('Nicolas');
    await joinPageActions.completeLastName('Rioseco');
    await joinPageActions.completeEmail('tandilqaauto@grr.la');
    await joinPageActions.completePassword('PtyPass2!');
    await joinPageActions.completeZip('A2A2A2');
    await joinPageActions.completePhone('6477002435');
    await joinPageActions.completeBirth('05171990');
})

When('press on Register', async (t: TestController) => {
    await joinPageActions.clickBtnCreateAccounut();
})

Then('verify that First Name validation is correct', async (t: TestController, ) => {
    await joinPageActions.checkValidation("firstName");
})

Then('verify that Last Name validation is correct', async (t: TestController, ) => {
    await joinPageActions.checkValidation("lastName");
})

Then('verify that Email validation is correct', async (t: TestController, ) => {
    await joinPageActions.checkValidation("femail");
})

Then('verify that Password validation is correct', async (t: TestController, ) => {
    await joinPageActions.checkValidation("passsword");
})

Then('verify that Zip validation is correct', async (t: TestController, ) => {
    await joinPageActions.checkValidation("zip");
})

Then('verify that Phone validation is correct', async (t: TestController, ) => {
    await joinPageActions.checkValidation("phone");
})

Then('verify that Birth validation is correct', async (t: TestController, ) => {
    await joinPageActions.checkValidation("birth");
})

Then('verify that Younger validation is correct', async (t: TestController, ) => {
    await joinPageActions.checkValidation("younger");
})

Then('verify that the account is created', async (t: TestController, ) => {
    console.log('Created succefull')
})

