"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cucumber_1 = require("@cucumber/cucumber");
const joinPageActions_1 = __importDefault(require("../pages/pageActions/joinPageActions"));
(0, cucumber_1.When)('complete the account fields with null First Name', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.completeFirstName('NULL');
    yield joinPageActions_1.default.completeLastName('Rioseco');
    yield joinPageActions_1.default.completeEmail('tandilqaauto@grr.la');
    yield joinPageActions_1.default.completePassword('PtyPass2!');
    yield joinPageActions_1.default.completeZip('A2A2A2');
    yield joinPageActions_1.default.completePhone('4137876313');
    yield joinPageActions_1.default.completeBirth('05171990');
}));
(0, cucumber_1.When)('complete the account fields with null Last Name', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.completeFirstName('Nicolas');
    yield joinPageActions_1.default.completeLastName('NULL');
    yield joinPageActions_1.default.completeEmail('tandilqaauto@grr.la');
    yield joinPageActions_1.default.completePassword('PtyPass2!');
    yield joinPageActions_1.default.completeZip('A2A2A2');
    yield joinPageActions_1.default.completePhone('4137876313');
    yield joinPageActions_1.default.completeBirth('05171990');
}));
(0, cucumber_1.When)('complete the account fields with invalid Email', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.completeFirstName('Nicolas');
    yield joinPageActions_1.default.completeLastName('Rioseco');
    yield joinPageActions_1.default.completeEmail('tandilqaautogrr.la');
    yield joinPageActions_1.default.completePassword('PtyPass2!');
    yield joinPageActions_1.default.completeZip('A2A2A2');
    yield joinPageActions_1.default.completePhone('4137876313');
    yield joinPageActions_1.default.completeBirth('05171990');
}));
(0, cucumber_1.When)('complete the account fields with null Email', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.completeFirstName('Nicolas');
    yield joinPageActions_1.default.completeLastName('Rioseco');
    yield joinPageActions_1.default.completeEmail('NULL');
    yield joinPageActions_1.default.completePassword('PtyPass2!');
    yield joinPageActions_1.default.completeZip('A2A2A2');
    yield joinPageActions_1.default.completePhone('4137876313');
    yield joinPageActions_1.default.completeBirth('05171990');
}));
(0, cucumber_1.When)('complete the account fields with null Password', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.completeFirstName('Nicolas');
    yield joinPageActions_1.default.completeLastName('Rioseco');
    yield joinPageActions_1.default.completeEmail('tandilqaauto@grr.la');
    yield joinPageActions_1.default.completePassword('NULL');
    yield joinPageActions_1.default.completeZip('A2A2A2');
    yield joinPageActions_1.default.completePhone('4137876313');
    yield joinPageActions_1.default.completeBirth('05171990');
}));
(0, cucumber_1.When)('complete the account fields with invalid Password', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.completeFirstName('Nicolas');
    yield joinPageActions_1.default.completeLastName('Rioseco');
    yield joinPageActions_1.default.completeEmail('tandilqaauto@grr.la');
    yield joinPageActions_1.default.completePassword('Invalid');
    yield joinPageActions_1.default.completeZip('A2A2A2');
    yield joinPageActions_1.default.completePhone('6477002435');
    yield joinPageActions_1.default.completeBirth('05171990');
}));
(0, cucumber_1.When)('complete the account fields with null Zip', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.completeFirstName('Nicolas');
    yield joinPageActions_1.default.completeLastName('Rioseco');
    yield joinPageActions_1.default.completeEmail('tandilqaauto@grr.la');
    yield joinPageActions_1.default.completePassword('PtyPass2!');
    yield joinPageActions_1.default.completeZip('NULL');
    yield joinPageActions_1.default.completePhone('6477002435');
    yield joinPageActions_1.default.completeBirth('05171990');
}));
(0, cucumber_1.When)('complete the account fields with null Phone', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.completeFirstName('Nicolas');
    yield joinPageActions_1.default.completeLastName('Rioseco');
    yield joinPageActions_1.default.completeEmail('tandilqaauto@grr.la');
    yield joinPageActions_1.default.completePassword('PtyPass2!');
    yield joinPageActions_1.default.completeZip('A2A2A2');
    yield joinPageActions_1.default.completePhone('NULL');
    yield joinPageActions_1.default.completeBirth('05171990');
}));
(0, cucumber_1.When)('complete the account fields with null Birth', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.completeFirstName('Nicolas');
    yield joinPageActions_1.default.completeLastName('Rioseco');
    yield joinPageActions_1.default.completeEmail('tandilqaauto@grr.la');
    yield joinPageActions_1.default.completePassword('PtyPass2!');
    yield joinPageActions_1.default.completeZip('A2A2A2');
    yield joinPageActions_1.default.completePhone('6477002435');
    yield joinPageActions_1.default.completeBirth('NULL');
}));
(0, cucumber_1.When)('complete the account fields with younger date', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.completeFirstName('Nicolas');
    yield joinPageActions_1.default.completeLastName('Rioseco');
    yield joinPageActions_1.default.completeEmail('tandilqaauto@grr.la');
    yield joinPageActions_1.default.completePassword('PtyPass2!');
    yield joinPageActions_1.default.completeZip('A2A2A2');
    yield joinPageActions_1.default.completePhone('6477002435');
    yield joinPageActions_1.default.completeBirth('05172012');
}));
(0, cucumber_1.When)('complete the account fields with correctly values', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.completeFirstName('Nicolas');
    yield joinPageActions_1.default.completeLastName('Rioseco');
    yield joinPageActions_1.default.completeEmail('tandilqaauto@grr.la');
    yield joinPageActions_1.default.completePassword('PtyPass2!');
    yield joinPageActions_1.default.completeZip('A2A2A2');
    yield joinPageActions_1.default.completePhone('6477002435');
    yield joinPageActions_1.default.completeBirth('05171990');
}));
(0, cucumber_1.When)('press on Register', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.clickBtnCreateAccounut();
}));
(0, cucumber_1.Then)('verify that First Name validation is correct', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.checkValidation("firstName");
}));
(0, cucumber_1.Then)('verify that Last Name validation is correct', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.checkValidation("lastName");
}));
(0, cucumber_1.Then)('verify that Email validation is correct', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.checkValidation("femail");
}));
(0, cucumber_1.Then)('verify that Password validation is correct', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.checkValidation("passsword");
}));
(0, cucumber_1.Then)('verify that Zip validation is correct', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.checkValidation("zip");
}));
(0, cucumber_1.Then)('verify that Phone validation is correct', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.checkValidation("phone");
}));
(0, cucumber_1.Then)('verify that Birth validation is correct', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.checkValidation("birth");
}));
(0, cucumber_1.Then)('verify that Younger validation is correct', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield joinPageActions_1.default.checkValidation("younger");
}));
(0, cucumber_1.Then)('verify that the account is created', (t) => __awaiter(void 0, void 0, void 0, function* () {
    console.log('Created succefull');
}));
