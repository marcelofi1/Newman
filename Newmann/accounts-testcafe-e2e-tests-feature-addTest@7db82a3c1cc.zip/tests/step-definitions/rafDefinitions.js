"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cucumber_1 = require("@cucumber/cucumber");
const actions_1 = __importDefault(require("../utils/actions"));
const rafPageActions_1 = __importDefault(require("../pages/pageActions/rafPageActions"));
const joinPageActions_1 = __importDefault(require("../pages/pageActions/joinPageActions"));
const mailsPageActions_1 = __importDefault(require("../pages/pageActions/mailsPageActions"));
const loginPageActions_1 = __importDefault(require("../pages/pageActions/loginPageActions"));
const helper_1 = require("../utils/helper");
const brand = (0, helper_1.getBrand)();
let quantity;
let linkRaf;
let rafCode;
let mail;
const numEmail = Math.floor(Math.random() * 1000000);
(0, cucumber_1.When)('user go to Refer a Friend page', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield rafPageActions_1.default.clickBtnMyAccount();
    yield rafPageActions_1.default.clickBtnViewRaf();
}));
(0, cucumber_1.When)('I view the joined quantity', (t) => __awaiter(void 0, void 0, void 0, function* () {
    const value = yield rafPageActions_1.default.getValueRaf();
    if (value !== null) {
        quantity = +value;
    }
    else {
        console.log('Error: Joined quantity is null');
    }
}));
(0, cucumber_1.When)('I refer a new friend to sport by email', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield rafPageActions_1.default.clickBtnRaf();
    yield rafPageActions_1.default.closeModalRaf();
    const value = yield rafPageActions_1.default.getValueLinkRaf();
    if (value !== null) {
        linkRaf = value;
        rafCode = linkRaf.split('RAF=')[1];
    }
    else {
        console.log('Error: Link RAF is null');
    }
    yield rafPageActions_1.default.clickBtnLogout();
}));
(0, cucumber_1.When)('My friend go to link RAF', (t) => __awaiter(void 0, void 0, void 0, function* () {
    if (linkRaf !== null) {
        yield t.navigateTo(linkRaf);
        yield rafPageActions_1.default.validateURLRaf(linkRaf);
    }
    else {
        console.log('Error: Link RAF is null');
    }
}));
(0, cucumber_1.When)('the user create account as RAF', (t) => __awaiter(void 0, void 0, void 0, function* () {
    mail = 'n.rioseco' + numEmail + '@yopmail.com';
    yield joinPageActions_1.default.completeFirstName('Nico');
    yield joinPageActions_1.default.completeLastName('RafAccounts');
    yield joinPageActions_1.default.completeEmail(mail);
    yield joinPageActions_1.default.completePassword('Elchavot1');
    yield joinPageActions_1.default.completeZip('32003');
    yield joinPageActions_1.default.completePhone('2494281960');
    yield joinPageActions_1.default.completeBirth('05171990');
}));
(0, cucumber_1.When)('the user valid account', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield t.wait(10000);
    yield t.navigateTo('https://yopmail.com?' + mail);
    yield t.wait(2000);
    if (linkRaf !== null) {
        yield t.navigateTo('https://yopmail.com?' + mail);
        yield t.wait(2000);
        const value = yield mailsPageActions_1.default.getLinkRaf();
        if (value !== null) {
            linkRaf = value;
            yield t.switchToMainWindow();
            yield t.navigateTo(linkRaf);
        }
        else {
            console.log('Error: Link RAF from email is null');
        }
    }
    else {
        console.log('Error: Link RAF is null');
    }
    if (mail !== undefined) {
        yield loginPageActions_1.default.completeUsername(mail);
        yield loginPageActions_1.default.completePassword('Elchavot1');
        yield loginPageActions_1.default.clickBtnLoginRaf();
    }
    else {
        console.log('Error: Mail is undefined');
    }
}));
(0, cucumber_1.Then)('the user verify that the account is created as RAF', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield rafPageActions_1.default.clickBtnHome();
    yield t.wait(3000);
    if (brand.domain !== undefined) {
        const { name, value } = yield actions_1.default.getSpecifcCookie('RAF', brand.domain);
        if (value !== null) {
            yield t
                .expect(name).eql('RAF')
                .expect(value).eql(rafCode);
        }
        else {
            console.log('Error: Cookie value is null');
        }
    }
    else {
        console.log('Error: Brand domain is undefined');
    }
    yield rafPageActions_1.default.clickBtnLogout();
}));
(0, cucumber_1.Then)('I return to Refer a Friend page for valid joined quantity', (t) => __awaiter(void 0, void 0, void 0, function* () {
    if (brand.siteUrl !== undefined) {
        yield t.navigateTo(brand.siteUrl);
    }
    else {
        console.log('Error: SiteUrl is undefined');
    }
    if (brand.usernameWithCredit !== undefined && brand.passwordWithCredit !== undefined) {
        yield loginPageActions_1.default.completeUsername(brand.usernameWithCredit);
        yield loginPageActions_1.default.completePassword(brand.passwordWithCredit);
        yield loginPageActions_1.default.clickBtnLogin();
    }
    else {
        console.log('Error: Username or password with credit is undefined');
    }
    yield rafPageActions_1.default.clickBtnMyAccount();
    yield rafPageActions_1.default.clickBtnViewRaf();
    const value = yield rafPageActions_1.default.getValueRaf();
    if (value !== null) {
        const newQuantity = +value;
        yield t.expect(newQuantity).gte(quantity);
    }
    else {
        console.log('Error: Joined quantity is null');
    }
}));
