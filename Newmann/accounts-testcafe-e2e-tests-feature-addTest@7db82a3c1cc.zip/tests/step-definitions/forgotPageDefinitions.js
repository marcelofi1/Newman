"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cucumber_1 = require("@cucumber/cucumber");
const forgotPageActions_1 = __importDefault(require("../pages/pageActions/forgotPageActions"));
const helper_1 = require("../utils/helper");
(0, cucumber_1.When)('user complete username for forgot', (t) => __awaiter(void 0, void 0, void 0, function* () {
    const username = (0, helper_1.getBrand)().emailForgot;
    if (username !== undefined) {
        yield forgotPageActions_1.default.completeUsername(username);
    }
    else {
        console.log('Error: Username for forgot is undefined');
    }
}));
(0, cucumber_1.When)('user press on Proceed button', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield forgotPageActions_1.default.clickBtnProceed();
}));
(0, cucumber_1.Then)('user see the validations of error', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield forgotPageActions_1.default.errorElementsAreVisibles();
}));
(0, cucumber_1.Then)('user see the notfication for email sended', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield forgotPageActions_1.default.linkElementsAreVisibles();
}));
(0, cucumber_1.Then)('user see the notfication for excedeed attempts', (t) => __awaiter(void 0, void 0, void 0, function* () {
    yield forgotPageActions_1.default.attemptsElementsAreVisibles();
}));
