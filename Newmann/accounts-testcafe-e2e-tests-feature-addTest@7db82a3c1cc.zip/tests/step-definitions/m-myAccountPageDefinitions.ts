import { Given, When } from '@cucumber/cucumber';
import mmyAccountPageActions from '../pages/pageActions/m-myAccountPageActions';
import actions from '../utils/actions';
import { brand } from '../utils/brand';
//import { Database } from '../utils/mssql';

Given('I open the brand page on mobile', async t => {
  //const database = new Database("Accounts");
  //database.query('select count(*) as count FROM [AccountIdentity]')
  await mmyAccountPageActions.urlIsDisplayed();
  await mmyAccountPageActions.headerIsVisible();
  await mmyAccountPageActions.footerIsVisible();
});

When('I press on Login and I complete log in fields', async (t: TestController) => {
  await mmyAccountPageActions.clickLoginBtn();
})

When('I verify that I am logged in', async (t: TestController) => {
  await mmyAccountPageActions.clickJoinBtn();
  //await joinPageActions.elementsAreVisible();
})
