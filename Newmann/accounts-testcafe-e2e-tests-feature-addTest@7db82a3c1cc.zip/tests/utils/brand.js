"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.brand = void 0;
class Brand {
    constructor() { }
}
exports.brand = new Brand();
