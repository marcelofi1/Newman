import 'crypto-js';
//import SHA256 from 'crypto-js/sha256';
import { enc, SHA256 } from 'crypto-js';

export function generateCodeVerifier() {
  var code_verifier = generateRandomString(128);
  return code_verifier;
}

export function generateRandomString(length: number) {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";
  for (var i = 0; i < length; i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
}

export function generateCodeChallenge(code_verifier: string) {
  let code_challenge = SHA256(code_verifier).toString(enc.Base64);
  code_challenge = code_challenge.replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  return code_challenge;
}