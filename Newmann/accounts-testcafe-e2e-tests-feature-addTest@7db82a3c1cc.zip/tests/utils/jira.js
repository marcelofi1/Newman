"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.jiraTrackingAfteEach = exports.jiraTrackingBeforeAll = void 0;
const library_jira_1 = require("library-jira");
const helper_1 = require("../utils/helper");
function jiraTrackingBeforeAll() {
    return __awaiter(this, void 0, void 0, function* () {
        if ((0, helper_1.getStateOfJiraIsActive)()) {
            if ((0, helper_1.getTestPlan)() == undefined) {
                //Create test plan
                //Set global var test plan id
                (0, helper_1.setTestPlan)(yield (0, library_jira_1.createIssueTestPlan)('Test Plan automation').then((response) => {
                    return response.data.key;
                }));
                console.log('Test plan id: ' + (0, helper_1.getTestPlan)());
                //Set IN PROGRESS test plan state
                yield (0, library_jira_1.setStateIssue)((0, helper_1.getTestPlan)(), 21);
                //Create test execution
                //Set global var test execution id
                (0, helper_1.setTestExecution)(yield (0, library_jira_1.createIssueExecutionTest)('Test execution automation - Test plan ' + (0, helper_1.getTestPlan)()).then((testExecution) => {
                    return testExecution.data.key;
                }));
                //Set IN PROGRESS test execution state
                yield (0, library_jira_1.setStateIssue)((0, helper_1.getTestExecution)(), 21);
            }
            ;
            console.log('You could see the Test Plan -> https://jira.itspty.com/browse/' + (0, helper_1.getTestPlan)());
            console.log('You could see the Test Execution -> https://jira.itspty.com/browse/' + (0, helper_1.getTestExecution)());
            //link test plan to test execution
            yield (0, library_jira_1.linkTestPlanToTestExecution)((0, helper_1.getTestPlan)(), (0, helper_1.getTestExecution)());
        }
        ;
    });
}
exports.jiraTrackingBeforeAll = jiraTrackingBeforeAll;
function getState(result) {
    return result.errs.length === 0 ? 'passed' : 'failed';
}
function jiraTrackingAfteEach(t) {
    return __awaiter(this, void 0, void 0, function* () {
        //Validate tracking to Jira is activate
        if ((0, helper_1.getStateOfJiraIsActive)()) {
            var stateResultTest;
            var testTitle;
            //@ts-ignore
            const result = yield t.testRun;
            testTitle = result.test.meta.tags.replace('@', '').split(',')[0];
            //Set state result of test
            stateResultTest = getState(result);
            //link test case to test plan
            yield (0, library_jira_1.linkTestCaseToTestPlan)(testTitle, (0, helper_1.getTestPlan)());
            //link test case to test execution
            yield (0, library_jira_1.linkTestCaseToTestExecution)(testTitle, (0, helper_1.getTestExecution)());
            //update state of test case of execution
            yield (0, library_jira_1.updateTestCaseExecution)(testTitle, (0, helper_1.getTestExecution)(), (0, helper_1.getTestPlan)(), stateResultTest);
        }
        ;
    });
}
exports.jiraTrackingAfteEach = jiraTrackingAfteEach;
