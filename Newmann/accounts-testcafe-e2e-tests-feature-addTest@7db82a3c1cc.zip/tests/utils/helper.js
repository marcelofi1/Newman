"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDataBase = exports.getBrand = exports.getStateOfJiraIsActive = exports.getTestExecution = exports.setTestExecution = exports.getTestPlan = exports.setTestPlan = void 0;
const config_1 = require("../config/config");
const config = (0, config_1.getConfig)();
var testPlan;
var testExecution;
function setTestPlan(id) {
    return (testPlan = id);
}
exports.setTestPlan = setTestPlan;
function getTestPlan() {
    return testPlan;
}
exports.getTestPlan = getTestPlan;
function setTestExecution(id) {
    testExecution = id;
}
exports.setTestExecution = setTestExecution;
function getTestExecution() {
    return testExecution;
}
exports.getTestExecution = getTestExecution;
function getStateOfJiraIsActive() {
    return process.env.isJiraActive === 'true';
}
exports.getStateOfJiraIsActive = getStateOfJiraIsActive;
function getBrand() {
    if (process.env.brand === "gc")
        return config.gc;
    if (process.env.brand === "tg")
        return config.tg;
    if (process.env.brand === "cbol")
        return config.cbol;
    if (process.env.brand === "csb")
        return config.csb;
    if (process.env.brand === "backend")
        return config.backend;
    return config.auxiliar;
}
exports.getBrand = getBrand;
function getDataBase() {
    return config.db;
}
exports.getDataBase = getDataBase;
