class Brand{
    constructor(){}

    name: string | undefined;
    siteUrl: string | undefined;
    domain: string | undefined;
    emailNoCredit: string | undefined;
    userIdNoCredit: string | undefined;
    passwordNoCredit: string | undefined;
    usernameWithCredit: string | undefined;
    passwordWithCredit: string | undefined;
    emailForgot: string | undefined;
    urlForgot: string | undefined;
}

export const brand = new Brand()