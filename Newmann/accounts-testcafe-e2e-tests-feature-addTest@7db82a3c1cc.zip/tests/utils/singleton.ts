type Constructor<T = {}> = new (...args: any[]) => T;

function singleton<T extends Constructor>(Target: T) {
  let instance: InstanceType<T> | null = null;

  return class extends Target {
    constructor(...args: any[]) {
      super(...args);

      if (!instance) {
        instance = this as InstanceType<T>;
      }

      return instance as any;
    }
  };
}

export default singleton;

class MyClass {
  constructor() {
    // Constructor de clase
  }
}

const SingletonMyClass = singleton(MyClass);

const instance1 = new SingletonMyClass(); // Primera instancia
const instance2 = new SingletonMyClass(); // Se obtiene la misma instancia

console.log(instance1 === instance2); // true, ambas instancias son iguales
