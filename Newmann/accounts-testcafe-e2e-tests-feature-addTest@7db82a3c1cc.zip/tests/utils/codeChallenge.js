"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateCodeChallenge = exports.generateRandomString = exports.generateCodeVerifier = void 0;
require("crypto-js");
//import SHA256 from 'crypto-js/sha256';
const crypto_js_1 = require("crypto-js");
function generateCodeVerifier() {
    var code_verifier = generateRandomString(128);
    return code_verifier;
}
exports.generateCodeVerifier = generateCodeVerifier;
function generateRandomString(length) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";
    for (var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}
exports.generateRandomString = generateRandomString;
function generateCodeChallenge(code_verifier) {
    let code_challenge = (0, crypto_js_1.SHA256)(code_verifier).toString(crypto_js_1.enc.Base64);
    code_challenge = code_challenge.replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
    return code_challenge;
}
exports.generateCodeChallenge = generateCodeChallenge;
