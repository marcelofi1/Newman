import { getConfig } from "../config/config";
import { brand } from "./brand";
const config = getConfig();
var testPlan: string;
var testExecution: string;

function setTestPlan(id: string): string {
    return (testPlan = id);
}

function getTestPlan(): string {
    return testPlan;
}

function setTestExecution(id: string) {
    testExecution = id;
}

function getTestExecution(): string {
    return testExecution;
}

function getStateOfJiraIsActive(): boolean{
    return process.env.isJiraActive === 'true';
}

function getBrand(): typeof brand {
    if(process.env.brand === "gc") return config.gc
    if(process.env.brand === "tg") return config.tg
    if(process.env.brand === "cbol") return config.cbol
    if(process.env.brand === "csb") return config.csb
    if(process.env.brand === "backend") return config.backend

    return config.auxiliar
}

function getDataBase(): typeof brand {
    return config.db
}

export { setTestPlan, getTestPlan, setTestExecution, getTestExecution, getStateOfJiraIsActive, getBrand, getDataBase };