"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function singleton(Target) {
    let instance = null;
    return class extends Target {
        constructor(...args) {
            super(...args);
            if (!instance) {
                instance = this;
            }
            return instance;
        }
    };
}
exports.default = singleton;
class MyClass {
    constructor() {
        // Constructor de clase
    }
}
const SingletonMyClass = singleton(MyClass);
const instance1 = new SingletonMyClass(); // Primera instancia
const instance2 = new SingletonMyClass(); // Se obtiene la misma instancia
console.log(instance1 === instance2); // true, ambas instancias son iguales
