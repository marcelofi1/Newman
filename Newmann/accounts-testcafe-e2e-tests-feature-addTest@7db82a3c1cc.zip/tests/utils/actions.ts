import { Selector as NativeSelector, ClientFunction } from 'gherkin-testcafe';
import { Selector, t } from 'testcafe';

class Actions {

  selector(selector: Selector, t: TestController) {
    return NativeSelector(selector).with({ boundTestRun: t });
  }

  getCurrentUrl() {
    return document.location.href;
  }

  getUrl() {
    return ClientFunction(() => document.location.href);
  }

  async urlIsDisplayed(url: string) {
    const clientfunction = ClientFunction(() => document.location.href);
    await this.containText(this.getUrl(), url, t);
  }

  async containText(selector: ClientFunction, texto: String, t: TestController) {
    await t.expect(selector()).eql(texto);
  }

  async eql(selector: Selector, valueToEql: string, t: TestController) {
    await t.expect(selector).eql(Selector(valueToEql));
  }

  async match(selector: Selector, valueToMatch: string, t: TestController) {
    await t.expect(selector).match(new RegExp(valueToMatch));
  }

  async click(element: Selector) {
    await t.click(element);
  }

  async select(element: Selector, option: string) {
    const optionElement = element.find('option');
    await t
        .click(element)
        .click(optionElement.withText(option));
  }

  async hover(element: Selector) {
    await t.hover(element);
  }

  async sendKeys(element: Selector, text: string) {
    await t.typeText(element, text);
  }

  async isVisible(element: Selector) {
    await t.expect(element.with({ visibilityCheck: true }).exists).ok({ timeout: 30000 });
  }

  async areVisible(elements: Array<Selector>) {
    for (let index = 0; index < elements.length; index++) {
      const element = elements[index];
      await this.isVisible(element);
    }
  }

  async isElementNotDisplayed(element: Selector) {
    await t.expect(element.visible).notOk({ timeout: 25000 });
  }

  async getValue(element: Selector){
    const text = await element.innerText;
    return text;
  }

  async getAtributte(element: Selector, atributte: string){
    const text = await element.getAttribute(atributte);
    return text;
  }

  async getSpecifcCookie(cookieName: string, domainName: string){
    const cookies = await t.getCookies({ domain: domainName, name: cookieName });
    return cookies[0];
  }

  async switchIFrame(iframe: Selector){
    await this.isVisible(iframe);
    await t.switchToIframe(iframe);
  } 
}

export default new Actions();