"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const gherkin_testcafe_1 = require("gherkin-testcafe");
const testcafe_1 = require("testcafe");
class Actions {
    selector(selector, t) {
        return (0, gherkin_testcafe_1.Selector)(selector).with({ boundTestRun: t });
    }
    getCurrentUrl() {
        return document.location.href;
    }
    getUrl() {
        return (0, gherkin_testcafe_1.ClientFunction)(() => document.location.href);
    }
    urlIsDisplayed(url) {
        return __awaiter(this, void 0, void 0, function* () {
            const clientfunction = (0, gherkin_testcafe_1.ClientFunction)(() => document.location.href);
            yield this.containText(this.getUrl(), url, testcafe_1.t);
        });
    }
    containText(selector, texto, t) {
        return __awaiter(this, void 0, void 0, function* () {
            yield t.expect(selector()).eql(texto);
        });
    }
    eql(selector, valueToEql, t) {
        return __awaiter(this, void 0, void 0, function* () {
            yield t.expect(selector).eql((0, testcafe_1.Selector)(valueToEql));
        });
    }
    match(selector, valueToMatch, t) {
        return __awaiter(this, void 0, void 0, function* () {
            yield t.expect(selector).match(new RegExp(valueToMatch));
        });
    }
    click(element) {
        return __awaiter(this, void 0, void 0, function* () {
            yield testcafe_1.t.click(element);
        });
    }
    select(element, option) {
        return __awaiter(this, void 0, void 0, function* () {
            const optionElement = element.find('option');
            yield testcafe_1.t
                .click(element)
                .click(optionElement.withText(option));
        });
    }
    hover(element) {
        return __awaiter(this, void 0, void 0, function* () {
            yield testcafe_1.t.hover(element);
        });
    }
    sendKeys(element, text) {
        return __awaiter(this, void 0, void 0, function* () {
            yield testcafe_1.t.typeText(element, text);
        });
    }
    isVisible(element) {
        return __awaiter(this, void 0, void 0, function* () {
            yield testcafe_1.t.expect(element.with({ visibilityCheck: true }).exists).ok({ timeout: 30000 });
        });
    }
    areVisible(elements) {
        return __awaiter(this, void 0, void 0, function* () {
            for (let index = 0; index < elements.length; index++) {
                const element = elements[index];
                yield this.isVisible(element);
            }
        });
    }
    isElementNotDisplayed(element) {
        return __awaiter(this, void 0, void 0, function* () {
            yield testcafe_1.t.expect(element.visible).notOk({ timeout: 25000 });
        });
    }
    getValue(element) {
        return __awaiter(this, void 0, void 0, function* () {
            const text = yield element.innerText;
            return text;
        });
    }
    getAtributte(element, atributte) {
        return __awaiter(this, void 0, void 0, function* () {
            const text = yield element.getAttribute(atributte);
            return text;
        });
    }
    getSpecifcCookie(cookieName, domainName) {
        return __awaiter(this, void 0, void 0, function* () {
            const cookies = yield testcafe_1.t.getCookies({ domain: domainName, name: cookieName });
            return cookies[0];
        });
    }
    switchIFrame(iframe) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.isVisible(iframe);
            yield testcafe_1.t.switchToIframe(iframe);
        });
    }
}
exports.default = new Actions();
