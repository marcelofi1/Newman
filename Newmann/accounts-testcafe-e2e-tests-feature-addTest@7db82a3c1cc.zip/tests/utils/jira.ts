import { createIssueExecutionTest, createIssueTestPlan, linkTestCaseToTestExecution, linkTestCaseToTestPlan, linkTestPlanToTestExecution, setStateIssue, updateTestCaseExecution, } from "library-jira";
import { getStateOfJiraIsActive, getTestExecution, getTestPlan, setTestExecution, setTestPlan } from "../utils/helper";

export async function jiraTrackingBeforeAll() {
    if (getStateOfJiraIsActive()) {
        if (getTestPlan() == undefined) {
            //Create test plan
            //Set global var test plan id
            setTestPlan(await createIssueTestPlan('Test Plan automation').then((response) => {
                return response.data.key;
            }));
            console.log('Test plan id: ' + getTestPlan());
            //Set IN PROGRESS test plan state
            await setStateIssue(getTestPlan(), 21);
            //Create test execution
            //Set global var test execution id
            setTestExecution(await createIssueExecutionTest('Test execution automation - Test plan ' + getTestPlan()).then((testExecution) => {
                return testExecution.data.key;
            }));
            //Set IN PROGRESS test execution state
            await setStateIssue(getTestExecution(), 21);
        };
        console.log('You could see the Test Plan -> https://jira.itspty.com/browse/' + getTestPlan());
        console.log('You could see the Test Execution -> https://jira.itspty.com/browse/' + getTestExecution());

        //link test plan to test execution
        await linkTestPlanToTestExecution(getTestPlan(), getTestExecution());
    };
}

function getState(result: any): string {
    return result.errs.length === 0 ? 'passed' : 'failed';
}

export async function jiraTrackingAfteEach(t: TestController) {
    //Validate tracking to Jira is activate
    if (getStateOfJiraIsActive()) {

        var stateResultTest: string;
        var testTitle: string;

        //@ts-ignore
        const result = await t.testRun;
        testTitle = result.test.meta.tags.replace('@', '').split(',')[0];
        //Set state result of test
        stateResultTest = getState(result);

        //link test case to test plan
        await linkTestCaseToTestPlan(testTitle, getTestPlan());
        //link test case to test execution
        await linkTestCaseToTestExecution(testTitle, getTestExecution());
        //update state of test case of execution
        await updateTestCaseExecution(testTitle, getTestExecution(), getTestPlan(), stateResultTest);
    };
}