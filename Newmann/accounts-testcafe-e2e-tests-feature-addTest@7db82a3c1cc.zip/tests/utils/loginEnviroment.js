"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sbRedirectUriCreator = exports.tokenRedirectUriCreator = exports.clientIdCreator = exports.sbHostCreator = exports.hostCreator = exports.environmentCreator = void 0;
const config_1 = require("../config/config");
function environmentCreator(codeChallenge) {
    var data = sbEnvCreator((0, config_1.getEnv)());
    var getFormUrl = `${data[0]}/protocol/openid-connect/auth?client_id=${data[1]}&redirect_uri=${data[2]}&state=${data[3]}&response_mode=${data[4]}&response_type=${data[5]}&scope=${data[6]}&nonce=${data[7]}&code_challenge=${codeChallenge}&code_challenge_method=${data[9]}`;
    return getFormUrl;
}
exports.environmentCreator = environmentCreator;
function sbEnvCreator(environment) {
    var host;
    var clientId;
    var redirectUri;
    var state;
    var responseMode;
    var responseType;
    var scope;
    var nonce;
    var codeChallenge;
    var codeChallengeMethod;
    //------ SPORTS BETTING
    switch (environment) {
        case 'dev':
            host = 'https://sb-api.dev.pposervices.local/api/auth/realms/dev-sportsbetting';
            clientId = 'sportsbetting-web';
            redirectUri = 'https%3A%2F%2Fsb.dev.pposervices.local%2F';
            state = 'c125078f-a484-49c2-8283-59859c78290a';
            responseMode = 'fragment';
            responseType = 'code';
            scope = 'openid';
            nonce = 'f3969078-ed8c-48a1-8f4e-ac673bd65ed8';
            codeChallenge = 'IFnAmiKDJ8JI3z1NU7CNnDsDTRQ1IhRdxiB4PKW--b8';
            codeChallengeMethod = 'S256';
            break;
        case 'qa':
            host = 'https://sb-api.qa.pposervices.local/api/auth/realms/qa-sportsbetting';
            clientId = 'sportsbetting-web';
            redirectUri = 'https%3A%2F%2Fsb.qa.pposervices.local%2F';
            state = '5a5419a0-38e7-4dc4-8c9f-e07dc4e57b10';
            responseMode = 'fragment';
            responseType = 'code';
            scope = 'openid';
            nonce = '51c95d76-d741-4d8c-8a55-b04386b99f54';
            codeChallenge = 'gzyhi3TqbCQ8TQmp99ugPeOPQlKjUhzjIGqTRYs3WwI';
            codeChallengeMethod = 'S256';
            break;
        case 'ppd':
            host = 'https://sb-api.ppd.pposervices.local/api/auth/realms/ppd-sportsbetting';
            clientId = 'sportsbetting-web';
            redirectUri = 'https%3A%2F%2Fsb.ppd.pposervices.local%2F';
            state = '8618f43b-e2fd-4d8b-8446-6f2d6aa91e59';
            responseMode = 'fragment';
            responseType = 'code';
            scope = 'openid';
            nonce = 'd436a6bb-6374-4a89-9f93-d1da6bb60877';
            codeChallenge = 'FwSZDvBLK7UFfngfHJAMmVbHGZwAdFNYfT_k_e4RD1g4';
            codeChallengeMethod = 'S256';
            break;
        default:
            console.log('Environment null');
            break;
    }
    var data = [host, clientId, redirectUri, state, responseMode, responseType, scope, nonce, codeChallenge, codeChallengeMethod];
    return data;
}
function hostCreator() {
    var host = sbHostCreator();
    return host;
}
exports.hostCreator = hostCreator;
function sbHostCreator() {
    var host;
    //set the environment variable DEV - QA - PPD
    switch ((0, config_1.getEnv)()) {
        case 'dev':
            host = 'https://sb-api.dev.pposervices.local/api/auth/realms/dev-sportsbetting';
            break;
        case 'qa':
            host = 'https://sb-api.qa.pposervices.local/api/auth/realms/qa-sportsbetting';
            break;
        case 'ppd':
            host = 'https://sb-api.ppd.pposervices.local/api/auth/realms/ppd-sportsbetting';
            break;
        default:
            console.log('Environment null');
            break;
    }
    //build the get join form url
    return host;
}
exports.sbHostCreator = sbHostCreator;
function clientIdCreator() {
    var clientId = 'sportsbetting-web';
    return clientId;
}
exports.clientIdCreator = clientIdCreator;
function tokenRedirectUriCreator() {
    var redirectUri = sbRedirectUriCreator();
    return redirectUri;
}
exports.tokenRedirectUriCreator = tokenRedirectUriCreator;
function sbRedirectUriCreator() {
    let redirectUri;
    // set the environment variable DEV - QA - PPD
    switch ((0, config_1.getEnv)()) {
        case 'dev':
            redirectUri = 'https://sb.dev.pposervices.local/';
            break;
        case 'qa':
            redirectUri = 'https://sb.qa.pposervices.local/';
            break;
        case 'ppd':
            redirectUri = 'https://ppd.sportsbetting.ag/';
            break;
        default:
            console.log('Environment null');
            redirectUri = ''; // Asignar un valor predeterminado en caso de que ningún caso del switch se cumpla
            break;
    }
    // build the get join form url
    return redirectUri;
}
exports.sbRedirectUriCreator = sbRedirectUriCreator;
