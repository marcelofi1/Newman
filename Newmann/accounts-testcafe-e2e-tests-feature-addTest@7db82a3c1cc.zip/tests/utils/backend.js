"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLocation = exports.getMessage = exports.refreshToken = exports.getToken = void 0;
/* eslint-disable */
const gherkin_testcafe_1 = require("gherkin-testcafe");
const cheerio = require('cheerio');
//import axios, { AxiosResponse } from 'axios';
const request = require('superagent');
const loginEnviroment_1 = require("./loginEnviroment");
const codeChallenge_1 = require("./codeChallenge");
const { URL } = require('url');
const https = require('https');
const fs = require('fs');
var tokenCode = 'asd';
var sessionCode;
var execution;
var clientId;
var tabId;
function getToken() {
    var _a;
    return __awaiter(this, void 0, void 0, function* () {
        let accessToken = '';
        let valueRefreshToken = '';
        var codeVerifier = (0, codeChallenge_1.generateCodeVerifier)();
        var codeCha = (0, codeChallenge_1.generateCodeChallenge)(codeVerifier);
        try {
            // Deshabilitar la verificación del certificado utilizando .ca()
            process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
            const response1 = yield request.get((0, loginEnviroment_1.environmentCreator)(codeCha)).redirects(1);
            const cookieJar = response1.header['set-cookie'];
            const responseData = response1.text;
            let reg1 = /authenticate\?session_code=([^.]*)&amp;execution=([^.]*)&amp;client_id=([^.]*)&amp;tab_id=([^.]*)"\s/;
            const myArray = reg1.exec(responseData);
            if (myArray !== null) {
                sessionCode = myArray[1];
                execution = myArray[2];
                clientId = myArray[3];
                tabId = myArray[4];
            }
            const url = (0, loginEnviroment_1.hostCreator)() + `/login-actions/authenticate?session_code=${sessionCode}&execution=${execution}&client_id=${clientId}&tab_id=${tabId}`;
            const joinPayload = {
                'username': 'SB1455106',
                'password': 'Qwer1234',
            };
            let response2;
            try {
                response2 = yield request
                    .post(url)
                    .redirects(0)
                    .set('Content-Type', 'application/x-www-form-urlencoded')
                    .set('Cookie', cookieJar.join('; '))
                    .send(joinPayload);
            }
            catch (error) {
                const typedError = error;
                if (typedError.response && typedError.response.status === 302) {
                    const location = (_a = typedError.response.headers) === null || _a === void 0 ? void 0 : _a.location;
                    if (location) {
                        reg1 = /&code=(.*)/;
                        const tokenCodeReg = reg1.exec(location);
                        tokenCode = tokenCodeReg && tokenCodeReg[1];
                    }
                }
                else {
                    console.error(error);
                }
            }
        }
        catch (err) {
            console.log(err);
        }
        try {
            const tokenJoinPayload = {
                code: tokenCode,
                grant_type: 'authorization_code',
                client_id: (0, loginEnviroment_1.clientIdCreator)(),
                redirect_uri: (0, loginEnviroment_1.tokenRedirectUriCreator)(),
                code_verifier: codeVerifier,
            };
            const tokenHeader = {
                'Content-Type': 'application/x-www-form-urlencoded',
            };
            const response = yield request
                .post((0, loginEnviroment_1.hostCreator)() + '/protocol/openid-connect/token')
                .set(tokenHeader)
                .send(tokenJoinPayload);
            const jsonToken = response.body;
            accessToken = jsonToken.access_token;
            valueRefreshToken = jsonToken.refresh_token;
        }
        catch (error) {
            console.error(error);
        }
        return [accessToken, valueRefreshToken];
    });
}
exports.getToken = getToken;
function refreshToken(refreshToken) {
    return __awaiter(this, void 0, void 0, function* () {
        const tokenJoinPayload = {
            'grant_type': 'refresh_token',
            'refresh_token': refreshToken,
            'client_id': (0, loginEnviroment_1.clientIdCreator)(),
        };
        const tokenHeader = {
            'Content-Type': 'application/x-www-form-urlencoded',
        };
        const tokensession_res = yield request
            .post((0, loginEnviroment_1.hostCreator)() + '/protocol/openid-connect/token')
            .set(tokenHeader)
            .send(tokenJoinPayload);
        // Tomar el token de acceso
        const jsonToken = tokensession_res.body;
        const accessToken = jsonToken.access_token;
        refreshToken = jsonToken.refresh_token;
        return [accessToken, refreshToken];
    });
}
exports.refreshToken = refreshToken;
function getMessage(validToken) {
    return __awaiter(this, void 0, void 0, function* () {
        let status;
        let body;
        var baseUrl = 'https://sb-api.qa.pposervices.local/api/customer/get-messages';
        const getMessageJoinPayload = {
            StartDate: "2023-05-31T00:00:00.000Z",
            EndDate: "2023-06-01T19:52:58.727Z",
            StartPosition: 0,
            TotalPerPage: 25,
            FreePlayStatusCode: "Status"
        };
        const getMessageHeader = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${validToken}`,
            'gsetting': 'sbnasite'
        };
        try {
            const getMessage_res = yield request
                .post(baseUrl)
                .set(getMessageHeader)
                .send(getMessageJoinPayload);
            status = getMessage_res.status;
            body = getMessage_res.body;
        }
        catch (err) {
            console.log(err);
        }
        return [status, body];
    });
}
exports.getMessage = getMessage;
function getLocation(targetUrl) {
    return __awaiter(this, void 0, void 0, function* () {
        let sessionCode = '';
        let execution = '';
        let clientId = '';
        let tabId = '';
        var codeVerifier = (0, codeChallenge_1.generateCodeVerifier)();
        var codeCha = (0, codeChallenge_1.generateCodeChallenge)(codeVerifier);
        try {
            // Deshabilitar la verificación del certificado utilizando .ca()
            process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
            const response1 = yield request.get((0, loginEnviroment_1.environmentCreator)(codeCha)).redirects(1);
            const cookieJar = response1.header['set-cookie'];
            console.log('cookieJar:', cookieJar);
            const responseData = response1.text;
            let reg1 = /authenticate\?session_code=([^.]*)&amp;execution=([^.]*)&amp;client_id=([^.]*)&amp;tab_id=([^.]*)"\s/;
            const myArray = reg1.exec(responseData);
            if (myArray !== null) {
                sessionCode = myArray[1];
                execution = myArray[2];
                clientId = myArray[3];
                tabId = myArray[4];
            }
            const url = (0, loginEnviroment_1.hostCreator)() + `/login-actions/authenticate?session_code=${sessionCode}&execution=${execution}&client_id=${clientId}&tab_id=${tabId}`;
            const agent = request.agent(); // Crear una instancia de superagent con jar
            const joinPayload = {
                username: 'SB1455106',
                password: 'Qwer1234',
            };
            try {
                let response2;
                // Seguir los redirects manualmente para obtener las cookies adicionales
                while (true) {
                    try {
                        response2 = yield agent
                            .post(url)
                            .redirects(0)
                            .set('Content-Type', 'application/x-www-form-urlencoded')
                            .set('Cookie', cookieJar.join('; '))
                            .send(joinPayload);
                        break; // Romper el bucle si no se lanza una excepción
                    }
                    catch (err) {
                        if (err.response && err.response.status === 302) {
                            const redirectUrl = err.response.headers.location;
                            const response = yield agent.get(redirectUrl).redirects(0);
                            const setCookieHeader = response.headers['set-cookie'];
                            if (Array.isArray(setCookieHeader)) {
                                setCookieHeader.forEach(cookie => {
                                    agent.jar.setCookie(cookie, targetUrl); // Almacenar cada cookie en el jar
                                });
                            }
                            else if (typeof setCookieHeader === 'string') {
                                agent.jar.setCookie(setCookieHeader, targetUrl); // Almacenar la cookie en el jar
                            }
                        }
                        else {
                            throw err; // Lanzar la excepción si no es una redirección
                        }
                    }
                }
                // Utilizar TestCafe para navegar a la página deseada
                const navigateToTargetUrl = (0, gherkin_testcafe_1.ClientFunction)((url) => {
                    window.location.href = url;
                });
                yield navigateToTargetUrl(targetUrl);
            }
            catch (err) {
                console.error('Error al iniciar sesión:', err);
            }
        }
        catch (err) {
            console.log(err);
        }
    });
}
exports.getLocation = getLocation;
