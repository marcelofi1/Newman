# Automation with Testcafe

This project pretends to bring an archetype for those teams wanting to start with TestCafe.
The structure of the framework was made by QA Experts Team. The implementation is based on Avengers Team's project

## Pre-requisites
- NodeJS https://nodejs.org/en/download/ (With Admin account)
- TestCafe `npm i -g testcafe`
- Gherkin-Testcafe and Cucumber/Cucumber `npm i gherkin-testcafe @cucumber/cucumber`

## Environments

List of environments in use.
- DEV: https://wc.dev.pposervices.local
- QA: https://wc.qa.pposervices.local
- PPD: https://ppd.wildcasino.ag/
- PROD: https://ppd.wildcasino.ag/

## Run different test cases

To run the different test cases you have to create the following script in the `package.json` file

`npx gherkin-testcafe chrome tests/features/homePage.feature tests/step-definitions/homePage.ts --env=qa`

- ### Script explanation

  - `npx` is how the framework could be executed

  - `gherkin-testcafe chrome` call to the gherkin-testcafe framework and it is possible to change the browser `chrome`, `firefox`,`safari`

  - `features/homePage.feature` indicates which feature will be executed

  - `step-definitions/homePage.ts` indicates which file contains the definition for the feature

  - `--env` Select the environment url where the test cases is going to run, the urls are located in `environments.json` file this could be `qa`,`dev` or `ppd`

### Integration with Browserstack

It requires the execution of the following command:
`npm i -g testcafe-browser-provider-browserstack`

To run the integration with Browserstack you have to do the following steps:

1. Set the local environment variables in the machine
   BROWSERSTACK_ACCESS_KEY this key should be copied from the Browserstack user
   BROWSERSTACK_USERNAME
2. Set the System environment variables in the machine
   BROWSERSTACK_ACCESS_KEY this key should be copied from the Browserstack user
   BROWSERSTACK_USERNAME
3. Run this command to verify the connection with Browserstack
   `npx testcafe -b browserstack`
   This command list all the devices that are avilable in Browserstack.

## Gherkin Integration with Browserstack

### Run all or some test cases in browserstack with a custom list of devices

Bash script (runTestInDevices.sh) was created for this kind of test.
The following devices were included in this script:

- browserstack:iPhone 11 Pro Max@13
- browserstack:iPhone XS Max@12
- browserstack:iPhone 11@13
- browserstack:iPhone XR@12
- browserstack:iPhone 13 Pro@15
- browserstack:iPhone 12@14
- browserstack:Samsung Galaxy S21 Plus@11.0
- browserstack:Samsung Galaxy S21 Ultra@11.0

The environments where to run the script are:

- dev
- qa
- ppd
- prod

The way to run this script is:

if you would like to run against the dev environment you type this command in the terminal
`npm run "browserStack:dev"`
if you would like to run against the qa environment you type this command in the terminal
`npm run "browserStack:qa"`
if you would like to run against the ppd environment you type this command in the terminal
`npm run "browserStack:ppd"`
if you would like to run against the prod environment you type this command in the terminal
`npm run "browserStack:prod"`

### Jira implementation

Add into environments files the next config env vars to use tracking on Jira/Xray

Example:

Set into config/environments.json the next var:

`isJiraActive:` is boolean to set active o desativate tracking on Jira.

```shell
$ export JIRA_SERVER=https://example.com
$ export JIRA_PROJECT_ID=xxxxx
$ export JIRA_USERNAME=username_credential
$ export JIRA_PASSWORD=password_credential
```
`JIRA_SERVER:` is the jira server company.
`JIRA_PROJECT_ID:` is the number of Jira used on your project that you must tracked the automated execution.
`JIRA_USERNAME:` is the username used to logged in on Jira.
`JIRA_PASSWORD:` is the password used to logged in on Jira.